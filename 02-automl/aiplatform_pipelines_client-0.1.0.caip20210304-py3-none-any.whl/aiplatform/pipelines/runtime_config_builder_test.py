# Copyright 2020 Google LLC. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Tests for google3.cloud.ml.pipelines.sdk.python.aiplatform_pipelines_client.aiplatform.pipelines.runtime_config_builder."""

import unittest

import frozendict

from aiplatform.pipelines import runtime_config_builder


class RuntimeConfigBuilderTest(unittest.TestCase):

  SAMPLE_RUNTIME_CONFIG = frozendict.frozendict({
      'gcsOutputDirectory': 'path/to/my/root',
      'parameters': {
          'string_param': {
              'stringValue': 'test-string'
          },
          'int_param': {
              'intValue': 42
          },
          'float_param': {
              'doubleValue': 3.14
          },
      }
  })

  def testBuildRuntimeConfigFromIndividualValues(self):
    my_builder = runtime_config_builder.RuntimeConfigBuilder(
        pipeline_root='path/to/my/root',
        parameter_values={
            'string_param': 'test-string',
            'int_param': 42,
            'float_param': 3.14
        })
    actual_runtime_config = my_builder.build()

    expected_runtime_config = self.SAMPLE_RUNTIME_CONFIG
    self.assertEqual(expected_runtime_config, actual_runtime_config)

  def testBuildRuntimeConfigFromRuntimeConfigJson(self):
    my_builder = (
        runtime_config_builder.RuntimeConfigBuilder.from_runtime_config_json(
            self.SAMPLE_RUNTIME_CONFIG))
    actual_runtime_config = my_builder.build()

    expected_runtime_config = self.SAMPLE_RUNTIME_CONFIG
    self.assertEqual(expected_runtime_config, actual_runtime_config)

  def testBuildRuntimeConfigWithNoopUpdates(self):
    my_builder = (
        runtime_config_builder.RuntimeConfigBuilder.from_runtime_config_json(
            self.SAMPLE_RUNTIME_CONFIG))
    my_builder.update_pipeline_root(None)
    my_builder.update_runtime_parameters(None)
    actual_runtime_config = my_builder.build()

    expected_runtime_config = self.SAMPLE_RUNTIME_CONFIG
    self.assertEqual(expected_runtime_config, actual_runtime_config)

  def testBuildRuntimeConfigWithMergeUpdates(self):
    my_builder = (
        runtime_config_builder.RuntimeConfigBuilder.from_runtime_config_json(
            self.SAMPLE_RUNTIME_CONFIG))
    my_builder.update_pipeline_root('path/to/my/new/root')
    my_builder.update_runtime_parameters({
        'int_param': 888,
        'new_param': 'new-string'
    })
    actual_runtime_config = my_builder.build()

    expected_runtime_config = {
        'gcsOutputDirectory': 'path/to/my/new/root',
        'parameters': {
            'string_param': {
                'stringValue': 'test-string'
            },
            'int_param': {
                'intValue': 888
            },
            'float_param': {
                'doubleValue': 3.14
            },
            'new_param': {
                'stringValue': 'new-string'
            },
        }
    }
    self.assertEqual(expected_runtime_config, actual_runtime_config)

  def testParseRuntimeParameters(self):
    expected_runtime_parameters = {
        'string_param': 'test-string',
        'int_param': 42,
        'float_param': 3.14,
    }
    actual_runtime_parameters = (
        runtime_config_builder._parse_runtime_parameters(
            self.SAMPLE_RUNTIME_CONFIG))
    self.assertEqual(expected_runtime_parameters, actual_runtime_parameters)


if __name__ == '__main__':
  unittest.main()
