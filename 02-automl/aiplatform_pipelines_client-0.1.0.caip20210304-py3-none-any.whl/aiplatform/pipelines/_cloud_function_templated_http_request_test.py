"""Tests for google3.cloud.ml.pipelines.sdk.python.client._cloud_function_create_pipeline_job."""

import datetime
import json
import os

from aiplatform.pipelines import _cloud_function_templated_http_request
from google3.testing.pybase import googletest


class CloudFunctionCreatePipelineJobTest(googletest.TestCase):

  def test_preprocess(self):
    test_data_path = os.path.join(
        os.path.dirname(__file__),
        'testdata',
    )
    function_request_path = os.path.join(
        test_data_path,
        'pipeline1_request_body.json',
    )
    expected_pipeline_request_path = os.path.join(
        test_data_path,
        'pipeline1_request_body_final.json',
    )

    with open(function_request_path, 'rb') as f:
      function_request = f.read()

    with open(expected_pipeline_request_path, 'r') as f:
      expected_pipeline_request = json.load(f)

    (_, _, resolved_request_body
    ) = _cloud_function_templated_http_request._preprocess_request_body(
        function_request, time=datetime.datetime(2020, 8, 1, 12, 34))
    actual_pipeline_request = json.loads(resolved_request_body)
    self.assertEqual(actual_pipeline_request, expected_pipeline_request)


if __name__ == '__main__':
  googletest.main()
