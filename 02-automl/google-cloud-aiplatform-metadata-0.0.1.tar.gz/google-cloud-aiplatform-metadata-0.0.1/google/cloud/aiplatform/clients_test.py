# Lint as: python3
"""Tests for google3.cloud.aiplatform.clients.

NOTE: Any test added to this module to test the client should most likely be
adapted and added to the root level SDK tests:
google3.cloud.aiplatform.aiplatform_test.py
"""
import importlib
import unittest
from unittest import mock

from ml_metadata import metadata_store
from ml_metadata.proto import metadata_store_pb2
import pandas as pd
from google.cloud.aiplatform import clients
from google.cloud.aiplatform.types import artifacts
from google.cloud.aiplatform.types import contexts
from google.cloud.aiplatform.types import executions
from google.cloud.aiplatform.utils import test_utils

_EXPERIMENT_NAME = 'test_experiment'
_OTHER_EXPERIMENT_NAME = 'other_test_experiment'
_TEST_METRIC_NAME_1 = 'test_metric_1'
_TEST_METRIC_NAME_2 = 'test_metric_2'
_TEST_METRIC_NAME_3 = 'test_metric_3'
_TEST_METRIC_VALUE_1 = 1.0
_TEST_METRIC_VALUE_2 = -10.0
_TEST_METRIC_VALUE_3 = 0.5
_TEST_MODEL_NAME_1 = 'test_model_1'
_TEST_MODEL_NAME_2 = 'test_model_2'
_TEST_MODEL_NAME_3 = 'test_model_3'
_TEST_ARTIFACT_NAME_1 = 'test_artifact_1'
_PARAMETER_KEY_1 = 'test_parameter_key_1'
_PARAMETER_KEY_2 = 'test_parameter_key_2'
_PARAMETER_KEY_3 = 'test_parameter_key_3'
_PARAMETER_VALUE_1 = 'test_value_key_1'
_PARAMETER_VALUE_2 = 1.0
_PARAMETER_VALUE_3 = 0.1
_TEST_DATASET_NAME_1 = 'test_dataset_1'
_TEST_DATASET_URI_1 = 'https://test-dataset.foo-website.com'
_TEST_DATASET_ENVIRONMENT = 'Training'
_TEST_DATASET_CONTAINER_FORMAT = 'Text'
_TEST_DATASET_PAYLOAD_FORMAT = 'JSON'
_EXECUTION_NAME = 'test_execution'
_EXECUTION_NAME_2 = 'test_execution_2'
_EXECUTION_DESCRIPTION = 'test execution description'


def _assert_frame_equal_with_sorted_columns(dataframe_1, dataframe_2):
  pd.testing.assert_frame_equal(
      dataframe_1.sort_index(axis=1),
      dataframe_2.sort_index(axis=1),
      check_names=True)


class ClientsTest(unittest.TestCase):

  def setUp(self):
    super().setUp()
    importlib.reload(clients)
    importlib.reload(contexts)
    importlib.reload(executions)
    importlib.reload(artifacts)

  def test_initialization(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    self.assertIsInstance(client._store, metadata_store.MetadataStore)

  def _test_experiment_in_store_and_current_experiment_equal(
      self, experiment_in_store: metadata_store_pb2.Context,
      current_experiment: contexts.ExperimentContext):
    self.assertEqual(experiment_in_store.id, current_experiment.node_id)
    self.assertEqual(experiment_in_store.name, current_experiment.name)
    self.assertEqual(experiment_in_store.type_id, current_experiment.type_id)

  def test_set_experiment(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    current_experiment = client.current_experiment
    self.assertEqual(current_experiment.name, _EXPERIMENT_NAME)
    contexts_in_store = client._store.get_contexts()
    self.assertEqual(len(contexts_in_store), 1)
    experiment_in_store = contexts_in_store[0]
    self._test_experiment_in_store_and_current_experiment_equal(
        experiment_in_store, current_experiment)

  def test_set_two_experiments_and_back(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    first_experiment = client.current_experiment

    client.set_experiment(_OTHER_EXPERIMENT_NAME)
    second_experiment = client.current_experiment
    contexts_in_store = client._store.get_contexts()
    self.assertEqual(len(contexts_in_store), 2)
    second_experiment_in_store = contexts_in_store[1]
    self._test_experiment_in_store_and_current_experiment_equal(
        second_experiment_in_store, second_experiment)

    client.set_experiment(_EXPERIMENT_NAME)
    third_experiment = client.current_experiment
    self.assertEqual(first_experiment, third_experiment)

  def test_experiment_context_manager(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())

    with client.experiment(_EXPERIMENT_NAME):
      current_experiment = client.current_experiment
      self.assertEqual(current_experiment.name, _EXPERIMENT_NAME)

  def test_exit_experiment_context_manager(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    first_experiment = client.current_experiment
    self.assertEqual(first_experiment.name, _EXPERIMENT_NAME)

    with client.experiment(_OTHER_EXPERIMENT_NAME):
      second_experiment = client.current_experiment
      self.assertEqual(second_experiment.name, _OTHER_EXPERIMENT_NAME)

    final_experiment = client.current_experiment
    self.assertEqual(first_experiment, final_experiment)

  def test_experiment_context_manager_raises(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())

    with client.experiment(_EXPERIMENT_NAME):
      with self.assertRaises(ValueError):
        client.set_experiment(_OTHER_EXPERIMENT_NAME)

    with client.experiment(_EXPERIMENT_NAME):
      with self.assertRaises(ValueError):
        with client.experiment(_OTHER_EXPERIMENT_NAME):
          pass

  def test_experiment_context_manager_object(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())

    with client.experiment(_EXPERIMENT_NAME) as my_experiment:
      self.assertEqual(client, my_experiment)
      self.assertEqual(my_experiment.current_experiment.name, _EXPERIMENT_NAME)

  def test_log_metric(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    executions.Execution.add_output = mock.MagicMock()

    client.log_metric(key=_TEST_METRIC_NAME_1, value=1.0)
    first_execution = client._current_execution
    self.assertIsInstance(first_execution, executions.Execution)
    self.assertEqual(first_execution, client.current_execution)

    first_execution.add_output.assert_called_once()
    args = first_execution.add_output.call_args
    # The created output metric has empty name as metric has no uri.
    self.assertEqual(
        len(args[0][0]._node.custom_properties['metric_type'].string_value), 0)
    self.assertEqual(
        args[0][0]._node.custom_properties[_TEST_METRIC_NAME_1].double_value,
        1.0)

  def test_log_metrics(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    executions.Execution.add_output = mock.MagicMock()

    client.log_metrics(test_metric_1=1.0, test_metric_2=0.5)
    first_execution = client.current_execution
    self.assertIsInstance(first_execution, executions.Execution)
    self.assertEqual(first_execution, client.current_execution)

    first_execution.add_output.assert_called_once()
    args = first_execution.add_output.call_args
    passed_in_metric = args[0][0]

    # The created output metric has empty name as metric has no uri.
    self.assertEqual(
        len(passed_in_metric._node.custom_properties['metric_type'].string_value
           ), 0)

    self.assertEqual(
        passed_in_metric._node.custom_properties['test_metric_1'].double_value,
        1.0)
    self.assertEqual(
        passed_in_metric._node.custom_properties['test_metric_2'].double_value,
        0.5)

  def test_log_metric_with_different_experiments_have_different_executions(
      self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)

    client.log_metric(key='t1', value=1.0)
    first_execution = client.current_execution

    client.set_experiment(_EXPERIMENT_NAME + '_2')

    # After change the experiment, current_execution should be None.
    self.assertIsNone(client.current_execution)

    client.log_metric(key='t2', value=0.5)
    # Calling log_metric will create a new Execution
    second_execution = client.current_execution
    self.assertIsNotNone(second_execution)

    client.set_experiment(_EXPERIMENT_NAME + '_3')

    # After change the experiment, current_execution should be None.
    self.assertIsNone(client.current_execution)

    client.log_metrics(test_metric_2=0.5, test_metric_3=0.1)
    # Calling log_metric will create a new Execution
    third_execution = client.current_execution
    self.assertNotEqual(first_execution, second_execution, third_execution)

  def test_log_metric_with_context_manager(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())

    with client.experiment(_EXPERIMENT_NAME):
      executions.Execution.add_output = mock.MagicMock()

      client.log_metrics(test_metric_1=1.0, test_metric_2=0.5)
      first_execution = client._current_execution
      self.assertIsInstance(first_execution, executions.Execution)
      self.assertEqual(first_execution, client.current_execution)

      first_execution.add_output.assert_called_once()
      args = first_execution.add_output.call_args
      passed_in_metric = args[0][0]

    # The created output metric has empty name as metric has no uri.
    self.assertEqual(
        len(passed_in_metric._node.custom_properties['metric_type'].string_value
           ), 0)

    self.assertEqual(
        passed_in_metric._node.custom_properties['test_metric_1'].double_value,
        1.0)
    self.assertEqual(
        passed_in_metric._node.custom_properties['test_metric_2'].double_value,
        0.5)

  def test_log_metrics_with_context_manager(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    executions.Execution.add_output = mock.MagicMock()

    with client.experiment(_EXPERIMENT_NAME):
      client.log_metrics(test_metric_1=1.0, test_metric_2=0.5)
      first_execution = client._current_execution
      self.assertIsInstance(first_execution, executions.Execution)
      self.assertEqual(first_execution, client.current_execution)

      first_execution.add_output.assert_called_once()
      args = first_execution.add_output.call_args
      passed_in_metric = args[0][0]

      # The created output metric has empty name as metric has no uri.
      self.assertEqual(
          len(passed_in_metric._node.custom_properties['metric_type']
              .string_value), 0)

      self.assertEqual(
          passed_in_metric._node.custom_properties['test_metric_1']
          .double_value, 1.0)
      self.assertEqual(
          passed_in_metric._node.custom_properties['test_metric_2']
          .double_value, 0.5)

  def test_reuse_same_experiment_will_not_reuse_execution(self):
    """Tests the following use case.

    with client.experiment('exp-1'):
      client.log_metric(key='key1', value=0.5)

    with client.experiment('exp-2'):
      client.log_metric(key='key1', value=0.5)

    with client.experiment('exp-1'):
      client.log_metric(key='key1', value=0.5)

    # All previous log_metric() methods are running in different executions,
    # and created different metrics.

    """
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())

    with client.experiment(_EXPERIMENT_NAME):
      client.log_metric(key='t1', value=1.0)
      first_execution = client.current_execution
      first_metric = first_execution.get_output_artifacts()[0]

    with client.experiment(_OTHER_EXPERIMENT_NAME):
      self.assertIsNone(client.current_execution)

      client.log_metric(key='t2', value=0.5)
      # Calling log_metric will create a new Execution
      second_execution = client.current_execution
      second_metric = second_execution.get_output_artifacts()[0]

    self.assertNotEqual(first_execution.node_id, second_execution.node_id)

    with client.experiment(_EXPERIMENT_NAME):
      # Reusing the old experiment, this current_execution should not be empty
      self.assertIsNone(client.current_execution)

      client.log_metrics(test_metric_2=0.5, test_metric_3=0.1)
      # Calling log_metric will create a new Execution
      third_execution = client.current_execution
      third_metric = third_execution.get_output_artifacts()[0]

    self.assertNotEqual(first_execution.node_id, second_execution.node_id,
                        third_execution.node_id)
    self.assertNotEqual(first_metric.node_id, second_metric.node_id,
                        third_metric.node_id)

  def test_log_metric_multiple_times_within_same_execution_will_update_metric(
      self):
    """Tests the following use case.

    with client.experiment('exp-1'):
      client.log_metric(key='key1', value=0.5)
      client.log_metric(key='key2', value=0.8)
      # Now, the metric has custom properties: key1:0.5, key2:0.8

      client.log_metrics(key2: 0.1)
      # Now, the metric has custom properties: key1:0.5, key2:0.1
      # And it is the same metric instance.
    """
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())

    with client.experiment(_EXPERIMENT_NAME):
      client.log_metric(key='t1', value=1.0)
      first_execution = client.current_execution
      output_artifact_1 = first_execution.get_output_artifacts()[0]

      client.log_metrics(t1=0.5, t2=0.8)
      output_artifact_2 = first_execution.get_output_artifacts()[0]

      self.assertEqual(output_artifact_1.node_id, output_artifact_2.node_id)
      self.assertEqual(
          output_artifact_1.node.custom_properties['t1'].double_value, 1.0)

      self.assertEqual(
          output_artifact_2.node.custom_properties['t1'].double_value, 0.5)
      self.assertEqual(
          output_artifact_2.node.custom_properties['t2'].double_value, 0.8)

  def test_log_metric_will_update_output_metric_in_execution(self):
    """Tests the following use case.

    with client.experiment('exp-1'):
      client.log_metric(key='key1', value=0.5)
      client.log_metric(key='key2', value=0.8)
      # Now, the metric has custom properties: key1:0.5, key2:0.8
      # Added more output Artifacts to current execution

      client.log_metrics(key2: 0.1)
      # Now, the metric has custom properties: key1:0.5, key2:0.1
      # And it is the same metric instance.
    """
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())

    with client.experiment(_EXPERIMENT_NAME):
      first_metric = client.log_metric(key='t1', value=1.0)
      first_execution = client.current_execution
      first_execution.add_output(
          artifacts.ModelArtifact.create(client._store, 'Test_Model'))
      first_execution.add_output(
          artifacts.DatasetArtifact.create(client._store, 'Test_Dataset'))

      second_metric = client.log_metrics(t1=0.5, t2=0.8)

      self.assertIsInstance(second_metric, artifacts.MetricArtifact)
      self.assertIsInstance(first_metric, artifacts.MetricArtifact)
      self.assertEqual(first_metric.node_id, second_metric.node_id)
      self.assertEqual(first_metric.node.custom_properties['t1'].double_value,
                       1.0)

      self.assertEqual(second_metric.node.custom_properties['t1'].double_value,
                       0.5)
      self.assertEqual(second_metric.node.custom_properties['t2'].double_value,
                       0.8)

  def test_execution_should_be_empty_when_switch_experiment(self):
    """This tests the following scenario.

    client.set_experiment('exp-1')
    client._internal_current_execution #should be an empty execution.
    client._current_execution #should be a new execution.

    with client.experiment('exp-2'):
      client._internal_current_execution #should be an empty execution.
      client._current_execution #should be a new execution.
    """
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment('exp-1')
    self.assertIsNone(client.current_execution)
    first_execution = client._current_execution
    self.assertIsNotNone(first_execution)

    with client.experiment('exp-2'):
      self.assertIsNone(client.current_execution)
      second_execution = client._current_execution
      self.assertIsNotNone(second_execution)

      self.assertNotEqual(first_execution.node_id, second_execution.node_id)

    client.set_experiment('exp-3')
    self.assertIsNone(client.current_execution)
    third_execution = client._current_execution
    self.assertIsNotNone(third_execution)
    self.assertNotEqual(first_execution.node_id, second_execution.node_id,
                        third_execution.node_id)

  def test_log_artifact_assigns_output_to_current_execution(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    mock_artifact = mock.Mock()
    artifact_metadata = client.log_artifact(
        mock_artifact, name=_TEST_ARTIFACT_NAME_1)
    output_artifacts = client.current_execution.get_output_artifacts()

    test_utils.assert_metadata_node_proto_equal(
        self,
        artifact_metadata.node,
        output_artifacts[0].node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

    # TODO(b/157581499) get artifact by experiment context

  def test_experiment_is_none_if_not_set(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    current_experiment = client.current_experiment
    self.assertIsNone(current_experiment)

    client.set_experiment(_EXPERIMENT_NAME)
    current_experiment = client.current_experiment
    self.assertIsNotNone(current_experiment)

  def test_client_creates_default_experiment(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    self.assertIsNone(client.current_experiment)
    client.log_metric('accuracy', 0.9)
    self.assertIsNotNone(client.current_experiment)
    self.assertTrue(
        client.current_experiment.name.startswith('default experiment '))

  def test_log_parameter_adds_custom_property_to_execution(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment('exp-1')
    client.log_parameter(_PARAMETER_KEY_1, _PARAMETER_VALUE_1)

    current_execution = client.current_execution
    self.assertIn(_PARAMETER_KEY_1, current_execution.node.custom_properties)
    self.assertEqual(
        _PARAMETER_VALUE_1,
        current_execution.node.custom_properties[_PARAMETER_KEY_1].string_value)

    execution_in_store = client._store.get_executions()[0]
    self.assertIn(_PARAMETER_KEY_1, execution_in_store.custom_properties)
    self.assertEqual(
        _PARAMETER_VALUE_1,
        execution_in_store.custom_properties[_PARAMETER_KEY_1].string_value)

  def test_log_parameters_adds_custom_properties_to_execution(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment('exp-1')
    client.log_parameters(**{
        _PARAMETER_KEY_1: _PARAMETER_VALUE_1,
        _PARAMETER_KEY_2: _PARAMETER_VALUE_2
    })

    current_execution = client.current_execution
    self.assertIn(_PARAMETER_KEY_1, current_execution.node.custom_properties)
    self.assertEqual(
        _PARAMETER_VALUE_1,
        current_execution.node.custom_properties[_PARAMETER_KEY_1].string_value)

    self.assertIn(_PARAMETER_KEY_2, current_execution.node.custom_properties)
    self.assertEqual(
        _PARAMETER_VALUE_2,
        current_execution.node.custom_properties[_PARAMETER_KEY_2].double_value)

    execution_in_store = client._store.get_executions()[0]
    self.assertIn(_PARAMETER_KEY_1, execution_in_store.custom_properties)
    self.assertEqual(
        _PARAMETER_VALUE_1,
        execution_in_store.custom_properties[_PARAMETER_KEY_1].string_value)
    self.assertIn(_PARAMETER_KEY_2, execution_in_store.custom_properties)
    self.assertEqual(
        _PARAMETER_VALUE_2,
        execution_in_store.custom_properties[_PARAMETER_KEY_2].double_value)

  def test_log_parameter_with_same_key_overwrites_parameter(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment('exp-1')
    client.log_parameter(_PARAMETER_KEY_1, _PARAMETER_VALUE_1)

    current_execution = client.current_execution
    self.assertIn(_PARAMETER_KEY_1, current_execution.node.custom_properties)
    self.assertEqual(
        _PARAMETER_VALUE_1,
        current_execution.node.custom_properties[_PARAMETER_KEY_1].string_value)

    execution_in_store = client._store.get_executions()[0]
    self.assertIn(_PARAMETER_KEY_1, execution_in_store.custom_properties)
    self.assertEqual(
        _PARAMETER_VALUE_1,
        execution_in_store.custom_properties[_PARAMETER_KEY_1].string_value)

    client.log_parameter(_PARAMETER_KEY_1, _PARAMETER_VALUE_2)

    current_execution = client.current_execution
    self.assertIn(_PARAMETER_KEY_1, current_execution.node.custom_properties)
    self.assertEqual(
        _PARAMETER_VALUE_2,
        current_execution.node.custom_properties[_PARAMETER_KEY_1].double_value)

    execution_in_store = client._store.get_executions()[0]
    self.assertIn(_PARAMETER_KEY_1, execution_in_store.custom_properties)
    self.assertEqual(
        _PARAMETER_VALUE_2,
        execution_in_store.custom_properties[_PARAMETER_KEY_1].double_value)

  def test_log_dataset_assigns_output_to_current_execution(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    mock_dataset = mock.Mock()
    dataset_metadata = client.log_dataset(
        mock_dataset,
        name=_TEST_DATASET_NAME_1,
        uri=_TEST_DATASET_URI_1,
        environment=_TEST_DATASET_ENVIRONMENT,
        container_format=_TEST_DATASET_CONTAINER_FORMAT,
        payload_format=_TEST_DATASET_PAYLOAD_FORMAT)
    output_artifacts = client.current_execution.get_output_artifacts()

    test_utils.assert_metadata_node_proto_equal(
        self,
        dataset_metadata.node,
        output_artifacts[0].node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

    # TODO(b/157581499) Dataset attributed to Experiment blocked by cl/311621526

  def test_log_model_assigns_output_to_current_execution(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    mock_model = mock.Mock()
    model_metadata = client.log_model(mock_model, name=_TEST_MODEL_NAME_1)
    output_artifacts = client.current_execution.get_output_artifacts()

    test_utils.assert_metadata_node_proto_equal(
        self,
        model_metadata.node,
        output_artifacts[0].node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

    artifact_from_store = client._store.get_artifacts_by_context(
        client.current_experiment.node_id)[0]

    test_utils.assert_metadata_node_proto_equal(
        self,
        model_metadata.node,
        artifact_from_store,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_execution_decorator_creates_execution(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())

    @client.execution(name=_EXECUTION_NAME, description=_EXECUTION_DESCRIPTION)
    def f():
      pass

    client.set_experiment(_EXPERIMENT_NAME)
    f()

    method_source = (
        '    @client.execution(name=_EXECUTION_NAME, '
        'description=_EXECUTION_DESCRIPTION)\n    def f():\n      pass\n')

    execution_in_store = client._store.get_executions()[0]

    self.assertEqual(execution_in_store.properties['name'].string_value,
                     _EXECUTION_NAME)
    self.assertEqual(execution_in_store.properties['code'].string_value,
                     method_source)
    self.assertEqual(execution_in_store.properties['description'].string_value,
                     _EXECUTION_DESCRIPTION)

  def test_execution_decorator_assigns_model_outputs_to_execution(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())

    @client.execution(name=_EXECUTION_NAME)
    def f():
      mock_model = mock.Mock()
      model_metadata = client.log_model(mock_model, name=_TEST_MODEL_NAME_1)
      return model_metadata

    client.set_experiment(_EXPERIMENT_NAME)
    model_metadata = f()

    execution_in_store = client._store.get_executions()[0]
    execution_metadata = executions.NotebookExecution(client._store,
                                                      execution_in_store)
    output_artifacts = execution_metadata.get_output_artifacts()

    test_utils.assert_metadata_node_proto_equal(
        self,
        model_metadata.node,
        output_artifacts[0].node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_execution_decorator_assigns_model_inputs_to_execution(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())

    @client.execution(name=_EXECUTION_NAME)
    def f(input_model):  # pylint: disable=unused-argument
      pass

    client.set_experiment(_EXPERIMENT_NAME)
    model = mock.Mock()
    model_metadata = client.log_model(model, name=_TEST_MODEL_NAME_1)
    f(model)

    execution_in_store = client._store.get_executions()[-1]
    self.assertEqual(execution_in_store.properties['name'].string_value,
                     _EXECUTION_NAME)

    execution_metadata = executions.NotebookExecution(client._store,
                                                      execution_in_store)
    input_artifacts = execution_metadata.get_input_artifacts()
    test_utils.assert_metadata_node_proto_equal(
        self,
        model_metadata.node,
        input_artifacts[0].node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_execution_decorator_assigns_primitive_inputs_to_custom_properties(
      self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())

    @client.execution(name=_EXECUTION_NAME)
    def f(num_val, str_val):  # pylint: disable=unused-argument
      pass

    client.set_experiment(_EXPERIMENT_NAME)
    f(1, 'hello')

    execution_in_store = client._store.get_executions()[-1]

    self.assertEqual(
        executions.NotebookExecution(
            client._store, execution_in_store).get_custom_properties_as_dict(),
        {
            'num_val': 1,
            'str_val': 'hello',
        })

  def test_execution_decorator_chains(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())

    @client.execution(name=_EXECUTION_NAME)
    def f1(input_model):  # pylint: disable=unused-argument
      output_model = mock.Mock()
      client.log_model(output_model, name=_TEST_MODEL_NAME_2)
      return output_model

    @client.execution(name=_EXECUTION_NAME_2)
    def f2(input_model):  # pylint: disable=unused-argument
      output_model = mock.Mock()
      client.log_model(output_model, name=_TEST_MODEL_NAME_3)
      return output_model

    client.set_experiment(_EXPERIMENT_NAME)
    model_1 = mock.Mock()
    client.log_model(model_1, name=_TEST_MODEL_NAME_1)

    model_2 = f1(model_1)
    model_3 = f2(model_2)

    executions_in_store = client._store.get_executions()
    self.assertEqual(len(executions_in_store), 3)

    main_execution = executions_in_store[0]
    f1_execution = executions_in_store[1]
    f2_execution = executions_in_store[2]
    self.assertEqual(f1_execution.properties['name'].string_value,
                     _EXECUTION_NAME)
    self.assertEqual(f2_execution.properties['name'].string_value,
                     _EXECUTION_NAME_2)

    main_execution_metadata = executions.NotebookExecution(
        client._store, main_execution)
    f1_execution_metadata = executions.NotebookExecution(
        client._store, f1_execution)
    f2_execution_metadata = executions.NotebookExecution(
        client._store, f2_execution)

    main_execution_out_model = main_execution_metadata.get_output_artifacts()[0]
    f1_execution_in_model = f1_execution_metadata.get_input_artifacts()[0]
    f1_execution_out_model = f1_execution_metadata.get_output_artifacts()[0]
    f2_execution_in_model = f2_execution_metadata.get_input_artifacts()[0]
    f2_execution_out_model = f2_execution_metadata.get_output_artifacts()[0]

    test_utils.assert_metadata_node_proto_equal(
        self,
        artifacts.OBJECT_ID_TO_ARTIFACT_MAP[model_1]._node,
        main_execution_out_model._node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

    test_utils.assert_metadata_node_proto_equal(
        self,
        main_execution_out_model._node,
        f1_execution_in_model._node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

    test_utils.assert_metadata_node_proto_equal(
        self,
        f1_execution_out_model._node,
        f2_execution_in_model._node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

    test_utils.assert_metadata_node_proto_equal(
        self,
        f2_execution_out_model._node,
        artifacts.OBJECT_ID_TO_ARTIFACT_MAP[model_3]._node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_execution_decorator_states_running_to_complete(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())

    @client.execution(name=_EXECUTION_NAME)
    def f():
      execution_in_store = client._store.get_executions()[0]
      self.assertEqual(execution_in_store.last_known_state,
                       metadata_store_pb2.Execution.State.RUNNING)

    client.set_experiment(_EXPERIMENT_NAME)
    f()

    execution_in_store = client._store.get_executions()[0]

    self.assertEqual(execution_in_store.last_known_state,
                     metadata_store_pb2.Execution.State.COMPLETE)

  def test_execution_decorator_states_running_to_failed(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())

    @client.execution(name=_EXECUTION_NAME)
    def f():
      execution_in_store = client._store.get_executions()[0]
      self.assertEqual(execution_in_store.last_known_state,
                       metadata_store_pb2.Execution.State.RUNNING)
      raise ValueError

    client.set_experiment(_EXPERIMENT_NAME)

    try:
      f()
    except ValueError:
      pass

    execution_in_store = client._store.get_executions()[0]

    self.assertEqual(execution_in_store.last_known_state,
                     metadata_store_pb2.Execution.State.FAILED)

  def test_get_experiment_df_returns_experiments(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    client.set_experiment(_OTHER_EXPERIMENT_NAME)

    experiments_df_truth = pd.DataFrame([{
        'experiment_name': _OTHER_EXPERIMENT_NAME,
        'experiment_id': 2
    }, {
        'experiment_name': _EXPERIMENT_NAME,
        'experiment_id': 1
    }])

    experiments_df = client.get_experiments_dataframe()

    _assert_frame_equal_with_sorted_columns(experiments_df,
                                            experiments_df_truth)

  def test_get_experiment_df_returns_parameters_and_metrics(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    client.log_parameter(key=_PARAMETER_KEY_1, value=_PARAMETER_VALUE_1)
    client.log_metric(key=_TEST_METRIC_NAME_1, value=_TEST_METRIC_VALUE_1)
    client.set_experiment(_OTHER_EXPERIMENT_NAME)
    client.log_parameter(key=_PARAMETER_KEY_2, value=_PARAMETER_VALUE_2)
    client.log_metric(key=_TEST_METRIC_NAME_2, value=_TEST_METRIC_VALUE_2)

    experiments_df_truth = pd.DataFrame([{
        'experiment_name': _OTHER_EXPERIMENT_NAME,
        'experiment_id': 2,
        'execution_name': '',
        'execution_id': 2,
        'param.%s' % _PARAMETER_KEY_2: _PARAMETER_VALUE_2,
        'metric.%s' % _TEST_METRIC_NAME_2: _TEST_METRIC_VALUE_2
    }, {
        'experiment_name': _EXPERIMENT_NAME,
        'experiment_id': 1,
        'execution_name': '',
        'execution_id': 1,
        'param.%s' % _PARAMETER_KEY_1: _PARAMETER_VALUE_1,
        'metric.%s' % _TEST_METRIC_NAME_1: _TEST_METRIC_VALUE_1
    }])

    experiments_df = client.get_experiments_dataframe()
    _assert_frame_equal_with_sorted_columns(experiments_df,
                                            experiments_df_truth)

  def test_get_experiment_df_returns_multiple_parameters_and_metrics(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    client.log_parameters(**{
        _PARAMETER_KEY_1: _PARAMETER_VALUE_1,
        _PARAMETER_KEY_3: _PARAMETER_VALUE_3
    })
    client.log_metrics(
        **{
            _TEST_METRIC_NAME_1: _TEST_METRIC_VALUE_1,
            _TEST_METRIC_NAME_3: _TEST_METRIC_VALUE_3
        })
    client.set_experiment(_OTHER_EXPERIMENT_NAME)
    client.log_parameters(**{
        _PARAMETER_KEY_2: _PARAMETER_VALUE_2,
        _PARAMETER_KEY_3: _PARAMETER_VALUE_3
    })
    client.log_metrics(
        **{
            _TEST_METRIC_NAME_2: _TEST_METRIC_VALUE_2,
            _TEST_METRIC_NAME_3: _TEST_METRIC_VALUE_3
        })

    experiments_df_truth = pd.DataFrame([{
        'experiment_name': _OTHER_EXPERIMENT_NAME,
        'experiment_id': 2,
        'execution_name': '',
        'execution_id': 2,
        'param.%s' % _PARAMETER_KEY_2: _PARAMETER_VALUE_2,
        'param.%s' % _PARAMETER_KEY_3: _PARAMETER_VALUE_3,
        'metric.%s' % _TEST_METRIC_NAME_2: _TEST_METRIC_VALUE_2,
        'metric.%s' % _TEST_METRIC_NAME_3: _TEST_METRIC_VALUE_3
    }, {
        'experiment_name': _EXPERIMENT_NAME,
        'experiment_id': 1,
        'execution_name': '',
        'execution_id': 1,
        'param.%s' % _PARAMETER_KEY_1: _PARAMETER_VALUE_1,
        'param.%s' % _PARAMETER_KEY_3: _PARAMETER_VALUE_3,
        'metric.%s' % _TEST_METRIC_NAME_1: _TEST_METRIC_VALUE_1,
        'metric.%s' % _TEST_METRIC_NAME_3: _TEST_METRIC_VALUE_3
    }])

    experiments_df = client.get_experiments_dataframe()
    _assert_frame_equal_with_sorted_columns(experiments_df,
                                            experiments_df_truth)

  def test_get_experiment_df_return_multiple_executions(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)

    @client.execution(name='f1')
    def f1():
      client.log_parameters(
          **{
              _PARAMETER_KEY_1: _PARAMETER_VALUE_1,
              _PARAMETER_KEY_3: _PARAMETER_VALUE_3
          })
      client.log_metrics(
          **{
              _TEST_METRIC_NAME_1: _TEST_METRIC_VALUE_1,
              _TEST_METRIC_NAME_3: _TEST_METRIC_VALUE_3
          })

    @client.execution(name='f2')
    def f2():
      client.log_parameters(
          **{
              _PARAMETER_KEY_2: _PARAMETER_VALUE_2,
              _PARAMETER_KEY_3: _PARAMETER_VALUE_3
          })
      client.log_metrics(
          **{
              _TEST_METRIC_NAME_2: _TEST_METRIC_VALUE_2,
              _TEST_METRIC_NAME_3: _TEST_METRIC_VALUE_3
          })

    f1()
    f2()

    experiments_df_truth = pd.DataFrame([{
        'experiment_name': _EXPERIMENT_NAME,
        'experiment_id': 1,
        'execution_name': 'f1',
        'execution_id': 1,
        'param.%s' % _PARAMETER_KEY_1: _PARAMETER_VALUE_1,
        'param.%s' % _PARAMETER_KEY_3: _PARAMETER_VALUE_3,
        'metric.%s' % _TEST_METRIC_NAME_1: _TEST_METRIC_VALUE_1,
        'metric.%s' % _TEST_METRIC_NAME_3: _TEST_METRIC_VALUE_3
    }, {
        'experiment_name': _EXPERIMENT_NAME,
        'experiment_id': 1,
        'execution_name': 'f2',
        'execution_id': 2,
        'param.%s' % _PARAMETER_KEY_2: _PARAMETER_VALUE_2,
        'param.%s' % _PARAMETER_KEY_3: _PARAMETER_VALUE_3,
        'metric.%s' % _TEST_METRIC_NAME_2: _TEST_METRIC_VALUE_2,
        'metric.%s' % _TEST_METRIC_NAME_3: _TEST_METRIC_VALUE_3
    }])

    experiments_df = client.get_experiments_dataframe()
    _assert_frame_equal_with_sorted_columns(experiments_df,
                                            experiments_df_truth)

  def test_get_experiment_df_return_multiple_executions_and_experiments(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)

    @client.execution(name='f1')
    def f1():
      client.log_parameters(
          **{
              _PARAMETER_KEY_1: _PARAMETER_VALUE_1,
              _PARAMETER_KEY_3: _PARAMETER_VALUE_3
          })
      client.log_metrics(
          **{
              _TEST_METRIC_NAME_1: _TEST_METRIC_VALUE_1,
              _TEST_METRIC_NAME_3: _TEST_METRIC_VALUE_3
          })

    @client.execution(name='f2')
    def f2():
      client.log_parameters(
          **{
              _PARAMETER_KEY_2: _PARAMETER_VALUE_2,
              _PARAMETER_KEY_3: _PARAMETER_VALUE_3
          })
      client.log_metrics(
          **{
              _TEST_METRIC_NAME_2: _TEST_METRIC_VALUE_2,
              _TEST_METRIC_NAME_3: _TEST_METRIC_VALUE_3
          })

    with client.experiment(_EXPERIMENT_NAME):
      f1()
      f2()

    with client.experiment(_OTHER_EXPERIMENT_NAME):
      f1()
      f2()

    experiments_df_truth = pd.DataFrame([{
        'experiment_name': _OTHER_EXPERIMENT_NAME,
        'experiment_id': 2,
        'execution_name': 'f1',
        'execution_id': 3,
        'param.%s' % _PARAMETER_KEY_1: _PARAMETER_VALUE_1,
        'param.%s' % _PARAMETER_KEY_3: _PARAMETER_VALUE_3,
        'metric.%s' % _TEST_METRIC_NAME_1: _TEST_METRIC_VALUE_1,
        'metric.%s' % _TEST_METRIC_NAME_3: _TEST_METRIC_VALUE_3
    }, {
        'experiment_name': _OTHER_EXPERIMENT_NAME,
        'experiment_id': 2,
        'execution_name': 'f2',
        'execution_id': 4,
        'param.%s' % _PARAMETER_KEY_2: _PARAMETER_VALUE_2,
        'param.%s' % _PARAMETER_KEY_3: _PARAMETER_VALUE_3,
        'metric.%s' % _TEST_METRIC_NAME_2: _TEST_METRIC_VALUE_2,
        'metric.%s' % _TEST_METRIC_NAME_3: _TEST_METRIC_VALUE_3
    }, {
        'experiment_name': _EXPERIMENT_NAME,
        'experiment_id': 1,
        'execution_name': 'f1',
        'execution_id': 1,
        'param.%s' % _PARAMETER_KEY_1: _PARAMETER_VALUE_1,
        'param.%s' % _PARAMETER_KEY_3: _PARAMETER_VALUE_3,
        'metric.%s' % _TEST_METRIC_NAME_1: _TEST_METRIC_VALUE_1,
        'metric.%s' % _TEST_METRIC_NAME_3: _TEST_METRIC_VALUE_3
    }, {
        'experiment_name': _EXPERIMENT_NAME,
        'experiment_id': 1,
        'execution_name': 'f2',
        'execution_id': 2,
        'param.%s' % _PARAMETER_KEY_2: _PARAMETER_VALUE_2,
        'param.%s' % _PARAMETER_KEY_3: _PARAMETER_VALUE_3,
        'metric.%s' % _TEST_METRIC_NAME_2: _TEST_METRIC_VALUE_2,
        'metric.%s' % _TEST_METRIC_NAME_3: _TEST_METRIC_VALUE_3
    }])
    experiments_df = client.get_experiments_dataframe()
    _assert_frame_equal_with_sorted_columns(experiments_df,
                                            experiments_df_truth)

  def test_get_dataset_returns_dataset_metadata(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    mock_dataset = mock.Mock()

    dataset_metadata = client.log_dataset(
        mock_dataset,
        name=_TEST_DATASET_NAME_1,
        uri=_TEST_DATASET_URI_1,
        environment=_TEST_DATASET_ENVIRONMENT,
        container_format=_TEST_DATASET_CONTAINER_FORMAT,
        payload_format=_TEST_DATASET_PAYLOAD_FORMAT)

    get_dataset_metadata = client.get_dataset(dataset_metadata.node.id)

    test_utils.assert_metadata_node_proto_equal(
        self,
        dataset_metadata.node,
        get_dataset_metadata.node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_get_dataset_returns_dataset_metadata_and_assigns_as_input(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    mock_dataset = mock.Mock()

    dataset_metadata = client.log_dataset(
        mock_dataset,
        name=_TEST_DATASET_NAME_1,
        uri=_TEST_DATASET_URI_1,
        environment=_TEST_DATASET_ENVIRONMENT,
        container_format=_TEST_DATASET_CONTAINER_FORMAT,
        payload_format=_TEST_DATASET_PAYLOAD_FORMAT)

    client.set_experiment(_OTHER_EXPERIMENT_NAME)
    get_dataset_metadata = client.get_dataset(dataset_metadata.node.id,
                                              assign_as_input=True)
    input_artifacts = client.current_execution.get_input_artifacts()

    test_utils.assert_metadata_node_proto_equal(
        self,
        dataset_metadata.node,
        input_artifacts[0].node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

    test_utils.assert_metadata_node_proto_equal(
        self,
        get_dataset_metadata.node,
        input_artifacts[0].node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_get_model_returns_model_metadata(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    mock_model = mock.Mock()

    model_metadata = client.log_model(mock_model, name=_TEST_MODEL_NAME_1)

    get_model_metadata = client.get_model(model_metadata.node.id)

    test_utils.assert_metadata_node_proto_equal(
        self,
        model_metadata.node,
        get_model_metadata.node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_get_model_returns_model_metadata_and_assigns_as_input(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    mock_model = mock.Mock()

    model_metadata = client.log_model(mock_model, name=_TEST_MODEL_NAME_1)

    client.set_experiment(_OTHER_EXPERIMENT_NAME)
    get_model_metadata = client.get_model(model_metadata.node.id,
                                          assign_as_input=True)
    input_artifacts = client.current_execution.get_input_artifacts()

    test_utils.assert_metadata_node_proto_equal(
        self,
        model_metadata.node,
        input_artifacts[0].node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

    test_utils.assert_metadata_node_proto_equal(
        self,
        get_model_metadata.node,
        input_artifacts[0].node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_get_artifact_returns_artifact_metadata(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    mock_artifact = mock.Mock()
    artifact_metadata = client.log_artifact(mock_artifact,
                                            name=_TEST_ARTIFACT_NAME_1)
    get_artifact_metadata = client.get_artifact(artifact_metadata.node.id)

    test_utils.assert_metadata_node_proto_equal(
        self,
        artifact_metadata.node,
        get_artifact_metadata.node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_get_artifact_returns_artifact_metadata_and_assigns_as_input(self):
    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client.set_experiment(_EXPERIMENT_NAME)
    mock_artifact = mock.Mock()
    artifact_metadata = client.log_artifact(mock_artifact,
                                            name=_TEST_ARTIFACT_NAME_1)

    client.set_experiment(_OTHER_EXPERIMENT_NAME)
    get_artifact_metadata = client.get_artifact(artifact_metadata.node.id,
                                                assign_as_input=True)
    input_artifacts = client.current_execution.get_input_artifacts()

    test_utils.assert_metadata_node_proto_equal(
        self,
        artifact_metadata.node,
        input_artifacts[0].node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

    test_utils.assert_metadata_node_proto_equal(
        self,
        get_artifact_metadata.node,
        input_artifacts[0].node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])


if __name__ == '__main__':
  unittest.main()
