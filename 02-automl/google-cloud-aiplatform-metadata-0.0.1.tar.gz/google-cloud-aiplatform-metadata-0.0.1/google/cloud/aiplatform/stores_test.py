"""Tests for Managed Metadata stores."""

import importlib
import unittest
from unittest import mock

from ml_metadata.proto import metadata_store_pb2
from google.cloud.aiplatform import clients
from google.cloud.aiplatform import stores
from google.cloud.aiplatform.types import artifacts
from google.cloud.aiplatform.types import contexts
from google.cloud.aiplatform.types import executions
from google.cloud.aiplatform.utils import type_utils

from google.cloud.aiplatform_v1alpha1.services.metadata_service import MetadataServiceClient
from google.cloud.aiplatform_v1alpha1.types import artifact
from google.cloud.aiplatform_v1alpha1.types import context
from google.cloud.aiplatform_v1alpha1.types import event
from google.cloud.aiplatform_v1alpha1.types import execution
from google.cloud.aiplatform_v1alpha1.types import lineage_subgraph
from google.cloud.aiplatform_v1alpha1.types import metadata_service
from google.cloud.aiplatform_v1alpha1.types import value
from google.protobuf import field_mask_pb2 as field_mask
from google.protobuf import timestamp_pb2 as timestamp

_TEST_PROJECT = 'test-project'
_TEST_LOCATION = 'us-central1'
_TEST_METADATA_STORE_RESOURCE_NAME = 'test_metadata_store_resource_name'
_TEST_STRING_VALUE = 'test_string_value'
_TEST_INT_VALUE = 1
_TEST_DOUBLE_VALUE = 1.0
_TEST_ARTIFACT_RESOURCE_NAME = 'test_artifact_resource_name'
_TEST_CONTEXT_RESOURCE_NAME = 'test_context_resource_name'
_TEST_EXECUTION_RESOURCE_NAME = 'test_execution_resource_name'
_TEST_SCHEMA_TITLE = 'test_schema_title'
_TEST_ARTIFACT_DISPLAY_NAME = 'test_artifact_display_name'
_TEST_CONTEXT_DISPLAY_NAME = 'test_context_display_name'
_TEST_EXECUTION_DISPLAY_NAME = 'test_execution_display_name'
_TEST_URI = 'gs://test_uri'
_TEST_ARTIFACT_RESOURCE_NAME2 = 'test_artifact_resource_name2'
_TEST_EXECUTION_RESOURCE_NAME2 = 'test_execution_resource_name2'


class StoresTest(unittest.TestCase):

  def setUp(self):
    super().setUp()
    importlib.reload(clients)
    importlib.reload(contexts)
    importlib.reload(executions)
    importlib.reload(artifacts)

  def test_init_store_initalizes_type_store(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)
      init_client_mock.return_value = metadata_service_client_mock()
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      self.assertIsInstance(store.type_store,
                            stores.AiPlatformMetadataStore.LocalTypeStore)

  def test_init_store_checks_if_store_exists(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)  # pylint: disable=unused-variable
      metadata_service_client_mock.get_metadata_store.assert_called_once_with(
          name=_TEST_METADATA_STORE_RESOURCE_NAME)

  def test_converts_property_value(self):
    string_value = metadata_store_pb2.Value(string_value=_TEST_STRING_VALUE)
    managed_string_value = stores.convert_property_value_to_managed_property_value(
        string_value)
    self.assertEqual(managed_string_value,
                     value.Value(string_value=_TEST_STRING_VALUE))

    int_value = metadata_store_pb2.Value(int_value=_TEST_INT_VALUE)
    managed_int_value = stores.convert_property_value_to_managed_property_value(
        int_value)
    self.assertEqual(managed_int_value, value.Value(int_value=_TEST_INT_VALUE))

    double_value = metadata_store_pb2.Value(double_value=_TEST_DOUBLE_VALUE)
    managed_double_value = stores.convert_property_value_to_managed_property_value(
        double_value)
    self.assertEqual(managed_double_value,
                     value.Value(double_value=_TEST_DOUBLE_VALUE))

  def test_put_artifact_type_puts_type_in_local_store(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      type_id = store.put_artifact_type(artifacts.ModelArtifact._type)
      self.assertEqual(type_id, hash(artifacts.ModelArtifact._type.name))
      artifacts.ModelArtifact._type_id = type_id
      artifact_node = artifacts.ModelArtifact._create_node(
          name='test_name',
          uri='test_uri',
          framework='test_framework',
          framework_version='test_framework_version')

      artifact_yaml = store.type_store.get_schema(artifact_node)
      true_yaml = """properties:
  framework:
    type: string
  framework_version:
    type: string
  name:
    type: string
title: aiplatform.Model
type: object
"""
      self.assertEqual(artifact_yaml, true_yaml)

  def test_put_context_type_puts_type_in_local_store(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      type_id = store.put_context_type(contexts.ExperimentContext._type)
      self.assertEqual(type_id, hash(contexts.ExperimentContext._type.name))
      contexts.ExperimentContext._type_id = type_id
      context_node = contexts.ExperimentContext._create_node(name='test_name')
      context_yaml = store.type_store.get_schema(context_node)
      true_yaml = """title: aiplatform.Experiment
type: object
"""
      self.assertEqual(context_yaml, true_yaml)

  def test_put_execution_type_puts_type_in_local_store(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      type_id = store.put_execution_type(executions.NotebookExecution._type)
      self.assertEqual(type_id, hash(executions.NotebookExecution._type.name))
      executions.NotebookExecution._type_id = type_id
      execution_node = executions.NotebookExecution._create_node(
          name='test_name')
      execution_yaml = store.type_store.get_schema(execution_node)
      true_yaml = """properties:
  code:
    type: string
  description:
    type: string
  name:
    type: string
title: aiplatform.NotebookExecution
type: object
"""
      self.assertEqual(execution_yaml, true_yaml)

  def test_convert_to_managed_artifact_converts_artifact(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      type_id = store.put_artifact_type(artifacts.ModelArtifact._type)
      artifacts.ModelArtifact._type_id = type_id
      artifact_node = artifacts.ModelArtifact._create_node(
          name='test_name',
          uri='test_uri',
          framework='test_framework',
          framework_version='test_framework_version')
      converted_artifact = store._convert_to_managed_node(
          artifact_node, artifact.Artifact)
      true_artifact = artifact.Artifact()
      true_artifact.display_name = 'test_name'
      true_artifact.uri = 'test_uri'
      true_artifact.properties['name'] = value.Value(string_value='test_name')
      true_artifact.properties['framework'] = value.Value(
          string_value='test_framework')
      true_artifact.properties['framework_version'] = value.Value(
          string_value='test_framework_version')
      true_artifact.instance_schema = type_utils.convert_type_to_yaml(
          artifacts.ModelArtifact._type)
      self.assertEqual(converted_artifact, true_artifact)

  def test_put_artifact_calls_create_artifact(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.create_artifact.return_value = \
          artifact.Artifact(name='test_artifact_resource_name')
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      type_id = store.put_artifact_type(artifacts.ModelArtifact._type)
      artifacts.ModelArtifact._type_id = type_id
      artifact_node = artifacts.ModelArtifact._create_node(
          name='test_name',
          uri='test_uri',
          framework='test_framework',
          framework_version='test_framework_version')
      artifact_resource_name = store._put_artifact(artifact_node)
      self.assertEqual(artifact_resource_name, 'test_artifact_resource_name')
      true_artifact = artifact.Artifact()
      true_artifact.display_name = 'test_name'
      true_artifact.uri = 'test_uri'
      true_artifact.properties['name'] = value.Value(string_value='test_name')
      true_artifact.properties['framework'] = value.Value(
          string_value='test_framework')
      true_artifact.properties['framework_version'] = value.Value(
          string_value='test_framework_version')
      true_artifact.instance_schema = type_utils.convert_type_to_yaml(
          artifacts.ModelArtifact._type)
      true_request = metadata_service.CreateArtifactRequest(
          parent=_TEST_METADATA_STORE_RESOURCE_NAME, artifact=true_artifact)
      metadata_service_client_mock.create_artifact.assert_called_once_with(
          true_request)

  def test_put_managed_artifact_calls_update_artifact(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.update_artifact.return_value = \
          artifact.Artifact(name='test_artifact_resource_name')
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      type_id = store.put_artifact_type(artifacts.ModelArtifact._type)
      artifacts.ModelArtifact._type_id = type_id
      artifact_node = artifacts.ModelArtifact._create_node(
          name='test_name',
          uri='test_uri',
          framework='test_framework',
          framework_version='test_framework_version')
      artifact_node.name = MetadataServiceClient.artifact_path(
          project=_TEST_PROJECT,
          location=_TEST_LOCATION,
          metadata_store=_TEST_METADATA_STORE_RESOURCE_NAME,
          artifact=_TEST_ARTIFACT_RESOURCE_NAME)
      artifact_resource_name = store._put_artifact(artifact_node)
      self.assertEqual(artifact_resource_name, 'test_artifact_resource_name')
      managed_artifact = store._convert_to_managed_node(artifact_node,
                                                        artifact.Artifact)
      update_mask = field_mask.FieldMask(
          paths=['properties', 'custom_properties', 'uri', 'state'])
      metadata_service_client_mock.update_artifact.assert_called_once_with(
          artifact=managed_artifact, update_mask=update_mask)

  def test_put_execution_calls_create_execution(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.create_execution.return_value = \
          execution.Execution(name='test_execution_resource_name')
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      type_id = store.put_execution_type(executions.NotebookExecution._type)
      executions.NotebookExecution._type_id = type_id
      execution_node = executions.NotebookExecution._create_node(
          name='test_name', description='test description', code='test code')
      execution_resource_name, _, _ = store.put_execution(execution_node)
      self.assertEqual(execution_resource_name, 'test_execution_resource_name')
      true_execution = execution.Execution()
      true_execution.display_name = 'test_name'
      true_execution.properties['name'] = value.Value(string_value='test_name')
      true_execution.properties['description'] = value.Value(
          string_value='test description')
      true_execution.properties['code'] = value.Value(string_value='test code')
      true_execution.instance_schema = type_utils.convert_type_to_yaml(
          executions.NotebookExecution._type)
      true_execution.state = execution.Execution.State.RUNNING
      true_request = metadata_service.CreateExecutionRequest(
          parent=_TEST_METADATA_STORE_RESOURCE_NAME, execution=true_execution)
      metadata_service_client_mock.create_execution.assert_called_once_with(
          true_request)

  def test_put_managed_execution_calls_update_execution(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.update_execution.return_value = \
          execution.Execution(name='test_execution_resource_name')
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      type_id = store.put_execution_type(executions.NotebookExecution._type)
      executions.NotebookExecution._type_id = type_id
      execution_node = executions.NotebookExecution._create_node(
          name='test_name', description='test description', code='test code')
      execution_node.name = MetadataServiceClient.execution_path(
          project=_TEST_PROJECT,
          location=_TEST_LOCATION,
          metadata_store=_TEST_METADATA_STORE_RESOURCE_NAME,
          execution=_TEST_EXECUTION_RESOURCE_NAME)
      execution_resource_name, _, _ = store.put_execution(execution_node)
      self.assertEqual(execution_resource_name, execution_node.name)
      managed_execution = store._convert_to_managed_node(
          execution_node, execution.Execution)
      update_mask = field_mask.FieldMask(
          paths=['properties', 'custom_properties', 'state'])
      metadata_service_client_mock.update_execution.assert_called_once_with(
          execution=managed_execution, update_mask=update_mask)

  def test_put_execution_with_context_calls_add_context_and_execution(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.create_execution.return_value = \
          execution.Execution(name='test-execution-resource-name')
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)

      type_id = store.put_execution_type(executions.NotebookExecution._type)
      executions.NotebookExecution._type_id = type_id
      type_id = store.put_context_type(contexts.ExperimentContext._type)
      contexts.ExperimentContext._type_id = type_id

      execution_node = executions.NotebookExecution._create_node(
          name='test_name', description='test description', code='test code')
      context_resource_name = MetadataServiceClient.context_path(
          'test-project', 'test-location', 'test-store', 'test-context')
      context_node = contexts.ExperimentContext._create_node(
          name=context_resource_name)

      execution_resource_name, _, _ = store.put_execution(
          execution=execution_node, contexts=[context_node])
      self.assertEqual(execution_resource_name, 'test-execution-resource-name')
      true_execution = execution.Execution()
      true_execution.display_name = 'test_name'
      true_execution.properties['name'] = value.Value(string_value='test_name')
      true_execution.properties['description'] = value.Value(
          string_value='test description')
      true_execution.properties['code'] = value.Value(string_value='test code')
      true_execution.instance_schema = type_utils.convert_type_to_yaml(
          executions.NotebookExecution._type)
      true_execution.state = execution.Execution.State.RUNNING
      true_request = metadata_service.CreateExecutionRequest(
          parent=_TEST_METADATA_STORE_RESOURCE_NAME, execution=true_execution)
      metadata_service_client_mock.create_execution.assert_called_once_with(
          true_request)

      true_request = metadata_service.AddContextArtifactsAndExecutionsRequest(
          context=context_resource_name, executions=[execution_resource_name])
      metadata_service_client_mock.add_context_artifacts_and_executions.assert_called_once_with(
          true_request)

  def test_put_context_calls_create_context(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.create_context.return_value = \
          context.Context(name='test-name')
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      type_id = store.put_context_type(contexts.ExperimentContext._type)
      contexts.ExperimentContext._type_id = type_id
      context_node = contexts.ExperimentContext._create_node(name='test-name')
      context_resource_names = store.put_contexts([context_node])
      self.assertEqual(context_resource_names[0], 'test-name')
      true_context = context.Context()
      true_context.name = 'test-name'
      true_context.instance_schema = type_utils.convert_type_to_yaml(
          contexts.ExperimentContext._type)
      true_request = metadata_service.CreateContextRequest(
          parent=_TEST_METADATA_STORE_RESOURCE_NAME,
          context=true_context,
          context_id='test-name')
      metadata_service_client_mock.create_context.assert_called_once_with(
          true_request)

  def test_put_managed_context_calls_update_context(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.update_context.return_value = \
          context.Context(name='test-name')
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      type_id = store.put_context_type(contexts.ExperimentContext._type)
      contexts.ExperimentContext._type_id = type_id
      context_node = contexts.ExperimentContext._create_node(
          name=MetadataServiceClient.context_path(
              project=_TEST_PROJECT,
              location=_TEST_LOCATION,
              metadata_store=_TEST_METADATA_STORE_RESOURCE_NAME,
              context=_TEST_CONTEXT_RESOURCE_NAME))
      context_resource_names = store.put_contexts([context_node])
      self.assertEqual(context_resource_names[0], 'test-name')
      managed_context = store._convert_to_managed_node(context_node,
                                                       context.Context)
      update_mask = field_mask.FieldMask(
          paths=['properties', 'custom_properties'])
      metadata_service_client_mock.update_context.assert_called_once_with(
          context=managed_context, update_mask=update_mask)

  def test_put_artifacts_calls_create_artifact(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.create_artifact.return_value = \
          artifact.Artifact(name='test_artifact_resource_name')
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      type_id = store.put_artifact_type(artifacts.ModelArtifact._type)
      artifacts.ModelArtifact._type_id = type_id
      artifact_node = artifacts.ModelArtifact._create_node(
          name='test_name',
          uri='test_uri',
          framework='test_framework',
          framework_version='test_framework_version')
      artifact_resource_names = store.put_artifacts([artifact_node])
      self.assertEqual(len(artifact_resource_names), 1)
      true_artifact = artifact.Artifact()
      true_artifact.display_name = 'test_name'
      true_artifact.uri = 'test_uri'
      true_artifact.properties['name'] = value.Value(string_value='test_name')
      true_artifact.properties['framework'] = value.Value(
          string_value='test_framework')
      true_artifact.properties['framework_version'] = value.Value(
          string_value='test_framework_version')
      true_artifact.instance_schema = type_utils.convert_type_to_yaml(
          artifacts.ModelArtifact._type)
      true_request = metadata_service.CreateArtifactRequest(
          parent=_TEST_METADATA_STORE_RESOURCE_NAME, artifact=true_artifact)
      metadata_service_client_mock.create_artifact.assert_called_once_with(
          true_request)

  def test_get_artifacts_by_id_returns_artifact(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.get_artifact.return_value = \
          artifact.Artifact(
              name=_TEST_ARTIFACT_RESOURCE_NAME,
              create_time=timestamp.Timestamp(),
              update_time=timestamp.Timestamp(),
              instance_schema_title=_TEST_SCHEMA_TITLE,
              state=artifact.Artifact.State.LIVE)
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      returned_artifacts = store.get_artifacts_by_id(
          [_TEST_ARTIFACT_RESOURCE_NAME])
      true_artifact = metadata_store_pb2.Artifact(
          name=_TEST_ARTIFACT_RESOURCE_NAME,
          id=hash(_TEST_ARTIFACT_RESOURCE_NAME),
          create_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          last_update_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          type=_TEST_SCHEMA_TITLE,
          type_id=hash(_TEST_SCHEMA_TITLE),
          state=metadata_store_pb2.Artifact.State.LIVE)
      self.assertEqual(len(returned_artifacts), 1)
      self.assertEqual(returned_artifacts[0], true_artifact)
      metadata_service_client_mock.get_artifact.assert_called_once_with(
          name=_TEST_ARTIFACT_RESOURCE_NAME)

  def test_get_executions_by_id_returns_execution(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.get_execution.return_value = \
          execution.Execution(
              name=_TEST_EXECUTION_RESOURCE_NAME,
              create_time=timestamp.Timestamp(),
              update_time=timestamp.Timestamp(),
              instance_schema_title=_TEST_SCHEMA_TITLE,
              state=execution.Execution.State.COMPLETE)
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      returned_executions = store.get_executions_by_id(
          [_TEST_EXECUTION_RESOURCE_NAME])
      true_execution = metadata_store_pb2.Execution(
          name=_TEST_EXECUTION_RESOURCE_NAME,
          id=hash(_TEST_EXECUTION_RESOURCE_NAME),
          create_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          last_update_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          type=_TEST_SCHEMA_TITLE,
          type_id=hash(_TEST_SCHEMA_TITLE),
          last_known_state=metadata_store_pb2.Execution.State.COMPLETE)
      self.assertEqual(len(returned_executions), 1)
      self.assertEqual(returned_executions[0], true_execution)
      metadata_service_client_mock.get_execution.assert_called_once_with(
          name=_TEST_EXECUTION_RESOURCE_NAME)

  def test_converts_from_managed_artifact(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      managed_artifact = artifact.Artifact(
          name=_TEST_ARTIFACT_RESOURCE_NAME,
          display_name=_TEST_ARTIFACT_DISPLAY_NAME,
          instance_schema_title=_TEST_SCHEMA_TITLE,
          uri=_TEST_URI,
          create_time=timestamp.Timestamp(),
          update_time=timestamp.Timestamp(),
          state=artifact.Artifact.State.LIVE)
      managed_artifact.properties['test_key_1'] = value.Value(
          string_value='test_value_1')
      managed_artifact.custom_properties['test_key_2'] = value.Value(
          int_value=1)
      converted_artifact = store._convert_from_managed_node(
          managed_artifact, metadata_store_pb2.Artifact)
      true_artifact = metadata_store_pb2.Artifact(
          name=_TEST_ARTIFACT_RESOURCE_NAME,
          id=hash(_TEST_ARTIFACT_RESOURCE_NAME),
          create_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          last_update_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          type=_TEST_SCHEMA_TITLE,
          type_id=hash(_TEST_SCHEMA_TITLE),
          uri=_TEST_URI,
          state=metadata_store_pb2.Artifact.State.LIVE)
      true_artifact.properties[
          'name'].string_value = _TEST_ARTIFACT_DISPLAY_NAME
      true_artifact.properties['test_key_1'].string_value = 'test_value_1'
      true_artifact.custom_properties['test_key_2'].int_value = 1

      self.assertEqual(true_artifact, converted_artifact)

  def test_converts_from_managed_context(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      managed_context = context.Context(
          name=_TEST_CONTEXT_RESOURCE_NAME,
          display_name=_TEST_CONTEXT_DISPLAY_NAME,
          instance_schema_title=_TEST_SCHEMA_TITLE,
          create_time=timestamp.Timestamp(),
          update_time=timestamp.Timestamp())
      managed_context.properties['test_key_1'] = value.Value(
          string_value='test_value_1')
      managed_context.custom_properties['test_key_2'] = value.Value(int_value=1)
      converted_context = store._convert_from_managed_node(
          managed_context, metadata_store_pb2.Context)
      true_context = metadata_store_pb2.Context(
          name=_TEST_CONTEXT_RESOURCE_NAME,
          id=hash(_TEST_CONTEXT_RESOURCE_NAME),
          create_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          last_update_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          type=_TEST_SCHEMA_TITLE,
          type_id=hash(_TEST_SCHEMA_TITLE))
      true_context.properties['name'].string_value = _TEST_CONTEXT_DISPLAY_NAME
      true_context.properties['test_key_1'].string_value = 'test_value_1'
      true_context.custom_properties['test_key_2'].int_value = 1
      self.assertEqual(true_context, converted_context)

  def test_converts_from_managed_execution(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      managed_execution = execution.Execution(
          name=_TEST_EXECUTION_RESOURCE_NAME,
          display_name=_TEST_EXECUTION_DISPLAY_NAME,
          instance_schema_title=_TEST_SCHEMA_TITLE,
          create_time=timestamp.Timestamp(),
          update_time=timestamp.Timestamp(),
          state=execution.Execution.State.COMPLETE)
      managed_execution.properties['test_key_1'] = value.Value(
          string_value='test_value_1')
      managed_execution.custom_properties['test_key_2'] = value.Value(
          int_value=1)
      converted_execution = store._convert_from_managed_node(
          managed_execution, metadata_store_pb2.Execution)
      true_execution = metadata_store_pb2.Execution(
          name=_TEST_EXECUTION_RESOURCE_NAME,
          id=hash(_TEST_EXECUTION_RESOURCE_NAME),
          create_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          last_update_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          type=_TEST_SCHEMA_TITLE,
          type_id=hash(_TEST_SCHEMA_TITLE),
          last_known_state=metadata_store_pb2.Execution.State.COMPLETE)
      true_execution.properties[
          'name'].string_value = _TEST_EXECUTION_DISPLAY_NAME
      true_execution.properties['test_key_1'].string_value = 'test_value_1'
      true_execution.custom_properties['test_key_2'].int_value = 1
      self.assertEqual(true_execution, converted_execution)

  def test_get_contexts_by_type_returns_contexts(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.list_contexts.return_value = [
          context.Context(
              name=_TEST_CONTEXT_RESOURCE_NAME,
              create_time=timestamp.Timestamp(),
              update_time=timestamp.Timestamp(),
              instance_schema_title=_TEST_SCHEMA_TITLE)
      ]
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      returned_contexts = store.get_contexts_by_type(_TEST_SCHEMA_TITLE)
      true_context = metadata_store_pb2.Context(
          name=_TEST_CONTEXT_RESOURCE_NAME,
          id=hash(_TEST_CONTEXT_RESOURCE_NAME),
          create_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          last_update_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          type=_TEST_SCHEMA_TITLE,
          type_id=hash(_TEST_SCHEMA_TITLE))
      self.assertEqual(len(returned_contexts), 1)
      self.assertEqual(returned_contexts[0], true_context)

  def test_add_context_artifacts_and_executions_calls_through(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      store.add_context_artifacts_and_executions(
          context_name='999',
          artifact_names=['123', '234'],
          execution_names=['345', '456'])
      metadata_service_client_mock.add_context_artifacts_and_executions.assert_called_once_with(
          context='999', artifacts=['123', '234'], executions=['345', '456'])

  def test_put_events_calls_through(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      managed_event = event.Event(artifact='123', type_=event.Event.Type.INPUT)
      store.put_events(execution_name='234', events=[managed_event])
      metadata_service_client_mock.add_execution_events.assert_called_once_with(
          execution='234', events=[managed_event])

  def test_get_context_by_type_and_name_returns_context(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.get_context.return_value = context.Context(
          name=_TEST_CONTEXT_RESOURCE_NAME,
          create_time=timestamp.Timestamp(),
          update_time=timestamp.Timestamp(),
          instance_schema_title=_TEST_SCHEMA_TITLE)
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      returned_contexts = store.get_context_by_type_and_name(
          _TEST_SCHEMA_TITLE, _TEST_CONTEXT_RESOURCE_NAME)
      true_context = metadata_store_pb2.Context(
          name=_TEST_CONTEXT_RESOURCE_NAME,
          id=hash(_TEST_CONTEXT_RESOURCE_NAME),
          create_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          last_update_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          type=_TEST_SCHEMA_TITLE,
          type_id=hash(_TEST_SCHEMA_TITLE))
      self.assertEqual(returned_contexts, true_context)

  def test_get_context_by_type_and_name_returns_none_when_incorrect_type(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.get_context.return_value = context.Context(
          name=_TEST_CONTEXT_RESOURCE_NAME,
          create_time=timestamp.Timestamp(),
          update_time=timestamp.Timestamp(),
          instance_schema_title=_TEST_SCHEMA_TITLE)
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      returned_contexts = store.get_context_by_type_and_name(
          'differentschematitle', _TEST_CONTEXT_RESOURCE_NAME)
      self.assertIsNone(returned_contexts)

  def test_get_executions_by_context_returns_executions(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.query_context_lineage_subgraph.return_value = lineage_subgraph.LineageSubgraph(
          executions=[
              execution.Execution(
                  name=_TEST_EXECUTION_RESOURCE_NAME,
                  create_time=timestamp.Timestamp(),
                  update_time=timestamp.Timestamp(),
                  instance_schema_title=_TEST_SCHEMA_TITLE,
                  state=execution.Execution.State.COMPLETE)
          ])
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      returned_executions = store.get_executions_by_context(
          _TEST_CONTEXT_RESOURCE_NAME)
      true_execution = metadata_store_pb2.Execution(
          name=_TEST_EXECUTION_RESOURCE_NAME,
          id=hash(_TEST_EXECUTION_RESOURCE_NAME),
          create_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          last_update_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          type=_TEST_SCHEMA_TITLE,
          type_id=hash(_TEST_SCHEMA_TITLE),
          last_known_state=metadata_store_pb2.Execution.State.COMPLETE)
      self.assertEqual(returned_executions, [true_execution])

  def test_get_events_by_execution_ids(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.query_execution_inputs_and_outputs.return_value = lineage_subgraph.LineageSubgraph(
          events=[
              event.Event(
                  artifact=_TEST_ARTIFACT_RESOURCE_NAME,
                  execution=_TEST_EXECUTION_RESOURCE_NAME,
                  type_=event.Event.Type.INPUT),
              event.Event(
                  artifact=_TEST_ARTIFACT_RESOURCE_NAME2,
                  execution=_TEST_EXECUTION_RESOURCE_NAME2,
                  type_=event.Event.Type.OUTPUT)
          ])
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      returned_events = store.get_events_by_execution_ids(
          ['execution_1', 'execution_2'])
      expected_events = [
          event.Event(
              artifact=_TEST_ARTIFACT_RESOURCE_NAME,
              execution=_TEST_EXECUTION_RESOURCE_NAME,
              type_=event.Event.Type.INPUT),
          event.Event(
              artifact=_TEST_ARTIFACT_RESOURCE_NAME2,
              execution=_TEST_EXECUTION_RESOURCE_NAME2,
              type_=event.Event.Type.OUTPUT),
          event.Event(
              artifact=_TEST_ARTIFACT_RESOURCE_NAME,
              execution=_TEST_EXECUTION_RESOURCE_NAME,
              type_=event.Event.Type.INPUT),
          event.Event(
              artifact=_TEST_ARTIFACT_RESOURCE_NAME2,
              execution=_TEST_EXECUTION_RESOURCE_NAME2,
              type_=event.Event.Type.OUTPUT)
      ]
      self.assertEqual(returned_events, expected_events)

  def test_get_context_graph_returns_graph_items(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.query_context_lineage_subgraph.return_value = lineage_subgraph.LineageSubgraph(
          executions=[
              execution.Execution(
                  name=_TEST_EXECUTION_RESOURCE_NAME,
                  create_time=timestamp.Timestamp(),
                  update_time=timestamp.Timestamp(),
                  instance_schema_title=_TEST_SCHEMA_TITLE,
                  state=execution.Execution.State.COMPLETE)
          ],
          artifacts=[
              artifact.Artifact(
                  name=_TEST_ARTIFACT_RESOURCE_NAME,
                  create_time=timestamp.Timestamp(),
                  update_time=timestamp.Timestamp(),
                  instance_schema_title=_TEST_SCHEMA_TITLE,
                  state=artifact.Artifact.State.LIVE)
          ],
          events=[
              event.Event(
                  execution=_TEST_EXECUTION_RESOURCE_NAME,
                  artifact=_TEST_ARTIFACT_RESOURCE_NAME,
                  type_=event.Event.Type.INPUT)
          ])
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      returned_lineage_subgraph = store.get_context_graph(
          _TEST_CONTEXT_RESOURCE_NAME)
      true_execution = metadata_store_pb2.Execution(
          name=_TEST_EXECUTION_RESOURCE_NAME,
          id=hash(_TEST_EXECUTION_RESOURCE_NAME),
          create_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          last_update_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          type=_TEST_SCHEMA_TITLE,
          type_id=hash(_TEST_SCHEMA_TITLE),
          last_known_state=metadata_store_pb2.Execution.State.COMPLETE)
      true_artifact = metadata_store_pb2.Artifact(
          name=_TEST_ARTIFACT_RESOURCE_NAME,
          id=hash(_TEST_ARTIFACT_RESOURCE_NAME),
          create_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          last_update_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          type=_TEST_SCHEMA_TITLE,
          type_id=hash(_TEST_SCHEMA_TITLE),
          state=metadata_store_pb2.Artifact.State.LIVE)
      true_event = metadata_store_pb2.Event(
          artifact_id=hash(_TEST_ARTIFACT_RESOURCE_NAME),
          execution_id=hash(_TEST_EXECUTION_RESOURCE_NAME),
          type=metadata_store_pb2.Event.Type.INPUT)
      self.assertEqual(returned_lineage_subgraph.executions, [true_execution])
      self.assertEqual(returned_lineage_subgraph.artifacts, [true_artifact])
      self.assertEqual(returned_lineage_subgraph.events, [true_event])

  def test_get_context_graph_returns_out_of_context_artifacts(self):
    with mock.patch.object(
        stores, 'initialize_metadata_service_client') as init_client_mock:
      metadata_service_client_mock = mock.Mock(spec=MetadataServiceClient)()
      metadata_service_client_mock.query_context_lineage_subgraph.return_value = lineage_subgraph.LineageSubgraph(
          executions=[
              execution.Execution(
                  name=_TEST_EXECUTION_RESOURCE_NAME,
                  create_time=timestamp.Timestamp(),
                  update_time=timestamp.Timestamp(),
                  instance_schema_title=_TEST_SCHEMA_TITLE,
                  state=execution.Execution.State.COMPLETE)
          ],
          artifacts=[],
          events=[
              event.Event(
                  execution=_TEST_EXECUTION_RESOURCE_NAME,
                  artifact=_TEST_ARTIFACT_RESOURCE_NAME,
                  type_=event.Event.Type.INPUT)
          ])

      metadata_service_client_mock.get_artifact.return_value = artifact.Artifact(
          name=_TEST_ARTIFACT_RESOURCE_NAME,
          create_time=timestamp.Timestamp(),
          update_time=timestamp.Timestamp(),
          instance_schema_title=_TEST_SCHEMA_TITLE,
          state=artifact.Artifact.State.LIVE)
      init_client_mock.return_value = metadata_service_client_mock
      store = stores.AiPlatformMetadataStore(_TEST_METADATA_STORE_RESOURCE_NAME)
      returned_lineage_subgraph = store.get_context_graph(
          _TEST_CONTEXT_RESOURCE_NAME,
          out_of_context_artifacts=True)
      true_execution = metadata_store_pb2.Execution(
          name=_TEST_EXECUTION_RESOURCE_NAME,
          id=hash(_TEST_EXECUTION_RESOURCE_NAME),
          create_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          last_update_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          type=_TEST_SCHEMA_TITLE,
          type_id=hash(_TEST_SCHEMA_TITLE),
          last_known_state=metadata_store_pb2.Execution.State.COMPLETE)
      true_artifact = metadata_store_pb2.Artifact(
          name=_TEST_ARTIFACT_RESOURCE_NAME,
          id=hash(_TEST_ARTIFACT_RESOURCE_NAME),
          create_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          last_update_time_since_epoch=timestamp.Timestamp.ToMilliseconds(
              timestamp.Timestamp()),
          type=_TEST_SCHEMA_TITLE,
          type_id=hash(_TEST_SCHEMA_TITLE),
          state=metadata_store_pb2.Artifact.State.LIVE)
      true_event = metadata_store_pb2.Event(
          artifact_id=hash(_TEST_ARTIFACT_RESOURCE_NAME),
          execution_id=hash(_TEST_EXECUTION_RESOURCE_NAME),
          type=metadata_store_pb2.Event.Type.INPUT)
      self.assertEqual(returned_lineage_subgraph.executions, [true_execution])
      self.assertEqual(returned_lineage_subgraph.artifacts, [true_artifact])
      self.assertEqual(returned_lineage_subgraph.events, [true_event])


if __name__ == '__main__':
  unittest.main()
