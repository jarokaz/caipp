"""Managed Metadata Store."""
import logging
import sys
from typing import Iterable, List, NamedTuple, Optional, Sequence, Tuple, Type, TypeVar

from ml_metadata.proto import metadata_store_pb2

from google import auth as google_auth
from google.api_core import exceptions
from google.auth.transport import grpc as google_auth_transport_grpc
from google.auth.transport import requests as google_auth_transport_requests
from google.cloud.aiplatform.utils import type_utils
from google.cloud.aiplatform_v1alpha1.services.metadata_service import MetadataServiceClient
from google.cloud.aiplatform_v1alpha1.services.metadata_service.transports import grpc as transports_grpc
from google.cloud.aiplatform_v1alpha1.types import artifact as gca_artifact
from google.cloud.aiplatform_v1alpha1.types import context as gca_context
from google.cloud.aiplatform_v1alpha1.types import event as gca_event
from google.cloud.aiplatform_v1alpha1.types import execution as gca_execution
from google.cloud.aiplatform_v1alpha1.types import metadata_service
from google.cloud.aiplatform_v1alpha1.types import metadata_store
from google.cloud.aiplatform_v1alpha1.types import value
from google.protobuf import field_mask_pb2 as field_mask
from google.protobuf import timestamp_pb2 as timestamp

logging.basicConfig(level=logging.INFO, stream=sys.stdout)
_AUTH_SCOPE = 'https://www.googleapis.com/auth/cloud-platform'

_API_URI = 'us-central1-aiplatform.googleapis.com'

ManagedNodeType = TypeVar('ManagedNodeType', gca_execution.Execution,
                          gca_artifact.Artifact, gca_context.Context)

managed_event_type_to_event_type = {
    gca_event.Event.Type.TYPE_UNSPECIFIED:
        metadata_store_pb2.Event.Type.UNKNOWN,
    gca_event.Event.Type.INPUT:
        metadata_store_pb2.Event.Type.INPUT,
    gca_event.Event.Type.OUTPUT:
        metadata_store_pb2.Event.Type.OUTPUT,
}

event_type_to_managed_event_type = {
    value: key for key, value in managed_event_type_to_event_type.items()
}


def initialize_metadata_service_client(
    api_uri=_API_URI) -> MetadataServiceClient:
  scope = _AUTH_SCOPE
  credentials, _ = google_auth.default(scopes=(scope,))
  request = google_auth_transport_requests.Request()
  channel = google_auth_transport_grpc.secure_authorized_channel(
      credentials, request, api_uri)

  return MetadataServiceClient(
      transport=transports_grpc.MetadataServiceGrpcTransport(channel=channel))


def convert_property_value_to_managed_property_value(
    property_value: metadata_store_pb2.Value) -> value.Value:
  value_type = property_value.WhichOneof('value')
  return value.Value(**{value_type: getattr(property_value, value_type)})


class LineageSubgraph(NamedTuple):
  """NamedTuple wrapping Managed Metadata Lineage Subgraph using MLMD Objects."""

  executions: List[metadata_store_pb2.Execution]
  artifacts: List[metadata_store_pb2.Artifact]
  events: List[metadata_store_pb2.Event]


class AiPlatformConfig(object):
  """Class to store AiPlatformStore configuration."""

  def __init__(self,
               metadata_store_resource_name: Optional[str] = None,
               *,
               project: Optional[str] = None,
               location: Optional[str] = None,
               store_name: Optional[str] = 'default'):
    self.metadata_store_resource_name = metadata_store_resource_name
    self.project = project
    self.location = location
    self.store_name = store_name


class AiPlatformMetadataStore:
  """Managed Metadata Store object.

  Implements ml_metadata.ml_metadata.MetadataStore interface necessary for
  the Managed Metadata SDK.
  """

  class LocalTypeStore:
    """Local Type Store used to store any put types.

    ml_metadata Types are converted to YAML and stored.
    Type ids are hashes of the Type names.
    Schemas are looked up based on the node type and type id.
    """

    def __init__(self):
      # Map of Type -> type id (hash of type name) -> yaml schema
      self._type_store = {
          str(metadata_store_pb2.ArtifactType): {},
          str(metadata_store_pb2.ExecutionType): {},
          str(metadata_store_pb2.ContextType): {}
      }

      # helper map for lookups: node type to mlmd type
      self._node_to_type = {
          str(metadata_store_pb2.Artifact):
              str(metadata_store_pb2.ArtifactType),
          str(metadata_store_pb2.Execution):
              str(metadata_store_pb2.ExecutionType),
          str(metadata_store_pb2.Context):
              str(metadata_store_pb2.ContextType)
      }

    def put_type(self, type_to_put: type_utils.MLMDType,
                 type_to_match: Type[type_utils.MLMDType]) -> int:
      """Puts the type in the local store.

      Converts the type to YAML. And stores in the type store based on the
      Type and hash of the type name. Also validates that mlmd type is of
      expected type.

      Args:
        type_to_put: MLMD Type definition
        type_to_match: Expected Type of the MLMD Type definition

      Returns:
        type id which is a hash of the Type name
      Raises:
        RuntimeError: if type_to_put is not of type type_to_match or if type
          name is already in the type store for this given type.
      """
      if not isinstance(type_to_put, type_to_match):
        raise RuntimeError('Expected %s but got %s.' %
                           (type_to_match, type_to_put))
      type_key = str(type_to_match)
      if type_to_put.name in self._type_store[type_key]:
        raise RuntimeError('%s with name %s already exists.' %
                           (type_to_match, type_to_put.name))
      type_id = hash(type_to_put.name)
      self._type_store[type_key][type_id] = type_utils.convert_type_to_yaml(
          type_to_put)
      return type_id

    def get_schema(self, node: type_utils.MLMDNode):
      node_type = self._node_to_type[str(type(node))]
      return self._type_store[node_type][node.type_id]

  def __init__(self,
               metadata_store_resource_name: str,
               api_uri: str = _API_URI):
    """Contructs the Managed Metadata Store.

    Args:
      metadata_store_resource_name: The resource name of the metadata store to
        use.
      api_uri: AI Platform API uri
    """
    self.metadata_store_resource_name = metadata_store_resource_name

    # Local type store. Redirects put type calls here
    # will enrich create calls with these stored types
    self.type_store = self.LocalTypeStore()
    self.api_client = initialize_metadata_service_client(api_uri)
    self._ensure_store_exists()
    self.parsed_metadata_store_path = self.api_client.parse_metadata_store_path(
        self.metadata_store_resource_name)

  @classmethod
  def init_from_config(cls,
                       config: AiPlatformConfig) -> 'AiPlatformMetadataStore':
    """Initializes store from given config.

    If metadata_store_resource_name is set in config, that store is used.

    If only project and location are set in config, 'default' store will be
    used. If 'default' store doesn't exist it will be created.

    If project, location, and store_name are set in config. That store will be
    used. If it doesn't exist it will be created.

    Args:
      config: Instance of AiPlatformConfig

    Returns:
      initalized AiPlatformStore
    """
    if config.metadata_store_resource_name:
      return cls(config.metadata_store_resource_name)

    metadata_store_resource_name = MetadataServiceClient.metadata_store_path(
        config.project, config.location, config.store_name)
    try:
      return cls(metadata_store_resource_name)
    except exceptions.NotFound:
      logging.info('Creating new Metadata store: %s',
                   metadata_store_resource_name)
      store = cls.init_from_new_store(
          project=config.project,
          location=config.location,
          store_name=config.store_name)
      logging.info('Metadata store created: %s',
                   store.metadata_store_resource_name)
      return store

  @classmethod
  def init_from_new_store(cls,
                          project: str,
                          location: str,
                          store_name: str,
                          api_uri=_API_URI) -> 'AiPlatformMetadataStore':
    """Creates a new managed metadata store against the service.

    Instantiates and return an AiPlatformMetadataStore pointing to that store.

    Args:
      project: The project to create the store in.
      location: The location to create the store in.
      store_name: The name to give this store.
      api_uri: AI Platform API uri

    Returns:
      An instantiated AiPlatofrmMetadataStore pointing to the newly created
      store.
    """
    api_client = initialize_metadata_service_client(api_uri)
    managed_store = metadata_store.MetadataStore(name=store_name)
    request = metadata_service.CreateMetadataStoreRequest(
        parent='projects/{project}/locations/{location}'.format(
            project=project, location=location),
        metadata_store=managed_store,
        metadata_store_id=store_name)
    operation = api_client.create_metadata_store(request)

    managed_store = operation.result()
    return cls(managed_store.name)

  def _ensure_store_exists(self):
    """Helper method to ensure the store exists."""
    self.api_client.get_metadata_store(name=self.metadata_store_resource_name)

  def put_artifact_type(self,
                        artifact_type: metadata_store_pb2.ArtifactType) -> int:
    """Puts an artifact type into the type store.

    Args:
      artifact_type: A MLMD artifact type definition.

    Returns:
      A type id for the artifact type.
    """
    return self.type_store.put_type(artifact_type,
                                    metadata_store_pb2.ArtifactType)

  def _convert_to_managed_node(
      self, mlmd_node: type_utils.MLMDNode,
      managed_node_type: Type[ManagedNodeType]) -> ManagedNodeType:
    """Helper method to convert an MLMD node to a managed node.

    Args:
      mlmd_node: The MLMD node to convert.
      managed_node_type: The type of managed node to convert to.

    Returns:
      A managed metadata node converted from the given MLMD node.
    """
    managed_node = managed_node_type()

    # if name is in the properties we will use it as the display name
    if 'name' in mlmd_node.properties:
      managed_node.display_name = mlmd_node.properties['name'].string_value

    # instance schema is placed inline from the type store
    managed_node.instance_schema = self.type_store.get_schema(node=mlmd_node)

    # only for artifacts
    if hasattr(mlmd_node, 'uri') and mlmd_node.uri:
      managed_node.uri = mlmd_node.uri

    if mlmd_node.name:
      managed_node.name = mlmd_node.name

    for key in mlmd_node.properties.keys():
      managed_node.properties[key] = \
          convert_property_value_to_managed_property_value(mlmd_node.properties[key])

    for key in mlmd_node.custom_properties.keys():
      managed_node.custom_properties[key] = \
          convert_property_value_to_managed_property_value(
              mlmd_node.custom_properties[key])

    if hasattr(mlmd_node, 'state'):
      managed_node.state = {
          metadata_store_pb2.Artifact.State.UNKNOWN:
              gca_artifact.Artifact.State.STATE_UNSPECIFIED,
          metadata_store_pb2.Artifact.State.PENDING:
              gca_artifact.Artifact.State.PENDING,
          metadata_store_pb2.Artifact.State.LIVE:
              gca_artifact.Artifact.State.LIVE,
          metadata_store_pb2.Artifact.State.MARKED_FOR_DELETION:
              gca_artifact.Artifact.State.STATE_UNSPECIFIED,
          metadata_store_pb2.Artifact.State.DELETED:
              gca_artifact.Artifact.State.STATE_UNSPECIFIED,
      }[mlmd_node.state]

    if hasattr(mlmd_node, 'last_known_state'):
      managed_node.state = {
          metadata_store_pb2.Execution.State.UNKNOWN:
              gca_execution.Execution.State.STATE_UNSPECIFIED,
          metadata_store_pb2.Execution.State.NEW:
              gca_execution.Execution.State.NEW,
          metadata_store_pb2.Execution.State.RUNNING:
              gca_execution.Execution.State.RUNNING,
          metadata_store_pb2.Execution.State.COMPLETE:
              gca_execution.Execution.State.COMPLETE,
          metadata_store_pb2.Execution.State.FAILED:
              gca_execution.Execution.State.FAILED,
          metadata_store_pb2.Execution.State.CACHED:
              gca_execution.Execution.State.COMPLETE,
          metadata_store_pb2.Execution.State.CANCELED:
              gca_execution.Execution.State.STATE_UNSPECIFIED
      }[mlmd_node.last_known_state]
    return managed_node

  def _convert_from_managed_node(
      self, managed_node: ManagedNodeType,
      mlmd_node_type: Type[type_utils.MLMDNode]) -> type_utils.MLMDNode:
    """Helper method to convert a managed node to an MLMD node.

    Args:
      managed_node: The managed node to convert.
      mlmd_node_type: The type of MLMD node to convert to.

    Returns:
      An MLMD metadata node converted from the given managed node.
    """
    mlmd_node = mlmd_node_type()

    # resource name
    mlmd_node.name = managed_node.name
    mlmd_node.id = hash(managed_node.name)

    if managed_node.display_name:
      mlmd_node.properties['name'].string_value = managed_node.display_name

    mlmd_node.type_id = hash(managed_node.instance_schema_title)
    mlmd_node.type = managed_node.instance_schema_title

    # only for artifacts
    if hasattr(managed_node, 'uri') and managed_node.uri:
      mlmd_node.uri = managed_node.uri

    if managed_node.create_time:
      mlmd_node.create_time_since_epoch = timestamp.Timestamp.ToMilliseconds(
          managed_node.create_time.timestamp_pb())

    if managed_node.update_time:
      mlmd_node.last_update_time_since_epoch = timestamp.Timestamp.ToMilliseconds(
          managed_node.update_time.timestamp_pb())

    for key in managed_node.properties.keys():
      property_value = managed_node.properties[key]
      value_type = property_value._pb.WhichOneof('value')  # pylint: disable=protected-access
      property_value = getattr(managed_node.properties[key], value_type)
      setattr(mlmd_node.properties[key], value_type, property_value)

    for key in managed_node.custom_properties.keys():
      custom_property_value = managed_node.custom_properties[key]
      value_type = custom_property_value._pb.WhichOneof('value')  # pylint: disable=protected-access
      custom_property_value = getattr(managed_node.custom_properties[key],
                                      value_type)
      setattr(mlmd_node.custom_properties[key], value_type,
              custom_property_value)

    if hasattr(managed_node,
               'state') and mlmd_node_type is metadata_store_pb2.Artifact:
      mlmd_node.state = {
          gca_artifact.Artifact.State.STATE_UNSPECIFIED:
              metadata_store_pb2.Artifact.State.UNKNOWN,
          gca_artifact.Artifact.State.PENDING:
              metadata_store_pb2.Artifact.State.PENDING,
          gca_artifact.Artifact.State.LIVE:
              metadata_store_pb2.Artifact.State.LIVE
      }[managed_node.state]

    if hasattr(managed_node,
               'state') and mlmd_node_type is metadata_store_pb2.Execution:
      mlmd_node.last_known_state = {
          gca_execution.Execution.State.STATE_UNSPECIFIED:
              metadata_store_pb2.Execution.State.UNKNOWN,
          gca_execution.Execution.State.NEW:
              metadata_store_pb2.Execution.State.NEW,
          gca_execution.Execution.State.RUNNING:
              metadata_store_pb2.Execution.State.RUNNING,
          gca_execution.Execution.State.COMPLETE:
              metadata_store_pb2.Execution.State.COMPLETE,
          gca_execution.Execution.State.FAILED:
              metadata_store_pb2.Execution.State.FAILED
      }[managed_node.state]

    return mlmd_node

  def _convert_from_managed_event(
      self, managed_event: gca_event.Event) -> metadata_store_pb2.Event:
    """Converts a managed type event into into a MLMD type event.

    Args:
      managed_event: Managed Event to convert.

    Returns:
      Converted MLMD event.
    """
    node = metadata_store_pb2.Event()

    node.artifact_id = hash(managed_event.artifact)
    if managed_event.execution:
      node.execution_id = hash(managed_event.execution)

    if hasattr(managed_event, 'type_'):
      node.type = {
          gca_event.Event.Type.TYPE_UNSPECIFIED:
              metadata_store_pb2.Event.Type.UNKNOWN,
          gca_event.Event.Type.INPUT:
              metadata_store_pb2.Event.Type.INPUT,
          gca_event.Event.Type.OUTPUT:
              metadata_store_pb2.Event.Type.OUTPUT,
      }[managed_event.type_]

    return node

  def _put_artifact(self, artifact_node: metadata_store_pb2.Artifact) -> str:
    """Puts an artifact in the managed metadata store.

    Args:
      artifact_node: Instance of an MLMD Artifact.

    Returns:
      The resource name of the artifact.
    """

    # If the name is a resource name then update instead of create.
    managed_artifact = self._convert_to_managed_node(artifact_node,
                                                     gca_artifact.Artifact)

    if MetadataServiceClient.parse_artifact_path(managed_artifact.name):
      managed_artifact = self.api_client.update_artifact(
          artifact=managed_artifact,
          update_mask=field_mask.FieldMask(
              paths=['properties', 'custom_properties', 'uri', 'state']))
    else:
      request = metadata_service.CreateArtifactRequest(
          parent=self.metadata_store_resource_name, artifact=managed_artifact)

      if artifact_node.name:
        request.artifact_id = artifact_node.name
      managed_artifact = self.api_client.create_artifact(request)

    return managed_artifact.name

  def put_artifacts(
      self, artifacts: Sequence[metadata_store_pb2.Artifact]) -> List[str]:
    """Puts multiple artifacts in the managed metadata store.

    Args:
      artifacts: A sequence of MLMD Artifacts.

    Returns:
      A list of resource name in representing the given MLMD Artifact in the
        same order.
    """
    return [self._put_artifact(node) for node in artifacts]

  def _get_artifact_by_id(self,
                          artifact_id: str) -> metadata_store_pb2.Artifact:
    """Gets an artifact by its resource name.

    Resource name format:
    projects/{project}/locations/{location}/metadataStores/{metadatastore}/artifacts/{artifact}

    Also accepts resource id. ie. {artifact}

    Args:
      artifact_id: Artifact id to get.

    Returns:
      MLMD artifact representing this artifact.
    """
    parsed_artifact = self.api_client.parse_artifact_path(artifact_id)

    if not parsed_artifact:
      artifact_id = self.api_client.artifact_path(
          project=self.parsed_metadata_store_path['project'],
          location=self.parsed_metadata_store_path['location'],
          metadata_store=self.parsed_metadata_store_path['metadata_store'],
          artifact=artifact_id)

    managed_artifact = self.api_client.get_artifact(name=artifact_id)
    return self._convert_from_managed_node(managed_artifact,
                                           metadata_store_pb2.Artifact)

  def get_artifacts_by_id(
      self, artifact_ids: Iterable[str]) -> List[metadata_store_pb2.Artifact]:
    """Gets artifacts by their resource names.

    Resource name format:
    projects/{project}/locations/{location}/metadataStores/{metadatastore}/artifacts/{artifact}
    Also accepts just resource id.

    Args:
      artifact_ids: List of artifact ids to get.

    Returns:
      MLMD artifacts representing these artifacts.
    """
    return [
        self._get_artifact_by_id(artifact_id) for artifact_id in artifact_ids
    ]

  def put_context_type(self,
                       context_type: metadata_store_pb2.ContextType) -> int:
    """Puts a context type into the type store.

    Args:
      context_type: Context type to put.

    Returns:
      The type_id of this context type in the store.
    """
    return self.type_store.put_type(context_type,
                                    metadata_store_pb2.ContextType)

  def get_context_by_type_and_name(
      self, type_name: str,
      context_name: str) -> Optional[metadata_store_pb2.Context]:
    """Gets contexts of a given type.

    Args:
      type_name: The name of the context type for which to get contexts.
      context_name: The resource name of the context.

    Returns:
      MLMD context with the specified context_name of the specified type
      if it exists. None otherwise.
    """

    context = self.api_client.get_context(name=context_name)
    return self._convert_from_managed_node(
        context, metadata_store_pb2.Context
    ) if context.instance_schema_title == type_name else None

  def get_contexts_by_type(self,
                           type_name: str) -> List[metadata_store_pb2.Context]:
    """Gets contexts of a given type.

    Args:
      type_name: The name of the context type for which to get contexts.

    Returns:
      MLMD contexts representing these contexts.
    """
    all_contexts = self.api_client.list_contexts(
        parent=self.metadata_store_resource_name)
    return [
        self._convert_from_managed_node(context, metadata_store_pb2.Context)
        for context in all_contexts
        if context.instance_schema_title == type_name
    ]

  def _get_context(self, context_name: str) -> gca_context.Context:
    """Gets a context from the managed store.

    Args:
      context_name: The context name to get. Can be a resource name.

    Returns:
      A managed context node from the store with that name.
    """
    if MetadataServiceClient.parse_context_path(context_name):
      context_resource_name = context_name
    else:
      context_resource_name = '/'.join(
          [self.metadata_store_resource_name, 'contexts', context_name])
    return self.api_client.get_context(name=context_resource_name)

  def get_contexts_by_id(self, context_ids: str) -> metadata_store_pb2.Context:
    contexts = []
    for context_id in context_ids:
      try:
        contexts.append(self._convert_from_managed_node(
            self._get_context(context_id), metadata_store_pb2.Context))
      except exceptions.NotFound:
        pass
    return contexts

  def _put_context(self,
                   context: metadata_store_pb2.Context) -> gca_context.Context:
    """Puts a context in the store.

    If context already exists with the same name then that one will be returned.

    Args:
      context: Instance of a context node.

    Returns:
      A created managed context node.
    """
    # If the name is a resource name then update instead of create.

    managed_context = self._convert_to_managed_node(context,
                                                    gca_context.Context)

    if MetadataServiceClient.parse_context_path(context.name):
      return self.api_client.update_context(
          context=managed_context,
          update_mask=field_mask.FieldMask(
              paths=['properties', 'custom_properties']))

    request = metadata_service.CreateContextRequest(
        parent=self.metadata_store_resource_name,
        context=managed_context,
        context_id=managed_context.name)

    try:
      return self.api_client.create_context(request)
    except exceptions.AlreadyExists:
      return self._get_context(context.name)

  def put_contexts(self,
                   contexts: Sequence[metadata_store_pb2.Context]) -> List[str]:
    return [self._put_context(context).name for context in contexts]

  def put_attributions_and_associations(
      self, attributions: Sequence[metadata_store_pb2.Attribution],
      associations: Sequence[metadata_store_pb2.Association]) -> None:
    pass

  def add_context_artifacts_and_executions(
      self, context_name: str, artifact_names: Iterable[str],
      execution_names: Iterable[str]) -> None:
    """Creates attributions/associations between the given context and the given artifacts/executions.

    Args:
      context_name: The resource name of the context.
      artifact_names: The resource names of the artifacts that should sttributed
        to the context.
      execution_names: The resource names of the executions that should
        sttributed to the context.
    """
    self.api_client.add_context_artifacts_and_executions(
        context=context_name,
        artifacts=artifact_names,
        executions=execution_names)

  def put_execution_type(
      self, execution_type: metadata_store_pb2.ExecutionType) -> str:
    """Puts an execution type into the type store.

    Args:
      execution_type: Execution type to put.

    Returns:
      The type_id of this execution type in the store.
    """
    return self.type_store.put_type(execution_type,
                                    metadata_store_pb2.ExecutionType)

  def _get_execution_by_id(self,
                           execution_id: str) -> metadata_store_pb2.Execution:
    """Gets an execution by its resource name.

    Resource name format:
    projects/{project}/locations/{location}/metadataStores/{metadatastore}/executions/{execution}

    Args:
      execution_id: Execution id to get.

    Returns:
      MLMD execution representing this execution.
    """
    managed_execution = self.api_client.get_execution(name=execution_id)
    return self._convert_from_managed_node(managed_execution,
                                           metadata_store_pb2.Execution)

  def get_executions_by_id(
      self, execution_ids: Iterable[str]) -> List[metadata_store_pb2.Execution]:
    """Gets executions by their resource names.

    Resource name format:
    projects/{project}/locations/{location}/metadataStores/{metadatastore}/executions/{execution}

    Args:
      execution_ids: List of execution ids to get.

    Returns:
      MLMD executions representing these executions.
    """
    return [
        self._get_execution_by_id(execution_id)
        for execution_id in execution_ids
    ]

  def put_execution(
      self,
      execution: metadata_store_pb2.Execution,
      artifact_and_events: Optional[Sequence[
          Tuple[metadata_store_pb2.Artifact,
                Optional[metadata_store_pb2.Event]]]] = None,
      contexts: Optional[Sequence[metadata_store_pb2.Context]] = None
  ) -> Tuple[str, List[str], List[str]]:
    """Puts execution in managed store.

    artifacts_and_events are not supported.
    Contexts are expected to already be registered.

    Args:
      execution: execution to put in the store
      artifact_and_events: artifacts and events to associate with execution
        (not supported)
      contexts: contexts to attribute execution (not supported)

    Returns:
      A tuple of execution resource name, list of artifact resource names,
        and a list of context resource names corresponding to the inputs nodes.
    Raises:
      NotImplementedError if artifact_and_events or contexts is passed in or if
      contexts have not already been registered against the store.
    """
    if artifact_and_events:
      raise NotImplementedError('artifacts_and_events not supported')

    contexts = contexts or []

    for context in contexts:
      if not MetadataServiceClient.parse_context_path(context.name):
        raise NotImplementedError('Contexts must already exist in store.')

    managed_execution = self._convert_to_managed_node(execution,
                                                      gca_execution.Execution)

    # If the name is a resource name then update instead of create.
    if MetadataServiceClient.parse_execution_path(managed_execution.name):
      self.api_client.update_execution(
          execution=managed_execution,
          update_mask=field_mask.FieldMask(
              paths=['properties', 'custom_properties', 'state']))
    else:
      request = metadata_service.CreateExecutionRequest(
          parent=self.metadata_store_resource_name, execution=managed_execution)
      managed_execution = self.api_client.create_execution(request)

    for context in contexts:
      request = metadata_service.AddContextArtifactsAndExecutionsRequest(
          context=context.name, executions=[managed_execution.name])
      self.api_client.add_context_artifacts_and_executions(request)

    return managed_execution.name, [], []

  def put_events(self, execution_name: str,
                 events: Sequence[gca_event.Event]) -> None:
    """Puts events in managed store.

    Args:
      execution_name: The execution to which all the events pertain.
      events: The (metadataservice) events to put. They should omit 'execution'.
    """
    if events:
      self.api_client.add_execution_events(
          execution=execution_name, events=events)

  def get_events_by_execution_ids(
      self, execution_ids: Iterable[str]) -> List[gca_event.Event]:
    """Gets Events for specified executions.

    Args:
      execution_ids: List of execution Ids.

    Returns:
      MLMD Events associated with the executions.
    """
    events = []
    for execution_id in execution_ids:
      request = metadata_service.QueryExecutionInputsAndOutputsRequest(
          execution=execution_id)
      events.extend(
          self.api_client.query_execution_inputs_and_outputs(request).events)

    return events

  def get_executions_by_context(
      self, context_name: str) -> List[metadata_store_pb2.Execution]:
    """Gets executions within a specified context.

    Args:
      context_name: The name of the context to get executions for.

    Returns:
      MLMD executions associated with the context.
    """
    return [
        self._convert_from_managed_node(execution, metadata_store_pb2.Execution)
        for execution in self.api_client.query_context_lineage_subgraph(
            context=context_name).executions
    ]

  def get_context_graph(
      self,
      context_name: str,
      out_of_context_artifacts: bool = False) -> LineageSubgraph:
    """Gets Lineage Subgraph for the specified context.

    Args:
      context_name: The name of the context whos egraph should be retrieved.
      out_of_context_artifacts: Flag. If True then artifacts that are not in the
        the given context are returned as well.
    Returns:
      An instance of LineageSubgraph. A NamedTuple representing the graph with
      MLMD
      Nodes.
    """
    lineage_subgraph = self.api_client.query_context_lineage_subgraph(
        context=context_name)

    context_artifact_names = set(artifact.name for artifact in
                                 lineage_subgraph.artifacts)

    # enrich artifacts with artifacts that are not in context
    if out_of_context_artifacts:
      for event in lineage_subgraph.events:
        if event.artifact not in context_artifact_names:
          lineage_subgraph.artifacts.append(
              self.api_client.get_artifact(name=event.artifact))

    mlmd_lineage_subgraph = LineageSubgraph(
        executions=[
            self._convert_from_managed_node(execution,
                                            metadata_store_pb2.Execution)
            for execution in lineage_subgraph.executions
        ],
        artifacts=[
            self._convert_from_managed_node(artifact,
                                            metadata_store_pb2.Artifact)
            for artifact in lineage_subgraph.artifacts
        ],
        events=[
            self._convert_from_managed_event(event)
            for event in lineage_subgraph.events
        ])

    return mlmd_lineage_subgraph
