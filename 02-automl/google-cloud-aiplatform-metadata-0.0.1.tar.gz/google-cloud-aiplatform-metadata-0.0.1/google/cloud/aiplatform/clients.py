# Lint as: python3
"""Module to store ML Metadata Experiment tracking client."""
import contextlib
import datetime
import inspect
import logging
import sys
from typing import Any, Callable, Dict, Generator, Optional, TypeVar, Union

from ml_metadata import metadata_store
from ml_metadata.proto import metadata_store_pb2

import pandas as pd
from google.cloud.aiplatform import stores
from google.cloud.aiplatform.types import artifacts
from google.cloud.aiplatform.types import context_lineage_subgraph
from google.cloud.aiplatform.types import contexts
from google.cloud.aiplatform.types import executions

logging.basicConfig(level=logging.INFO, stream=sys.stdout)

T = TypeVar('T')  # TypeVar used for execution decorator type hinting


class InMemoryConfig(object):
  """Database config for in memory database."""

  def __init__(self):
    self.connection_config = metadata_store_pb2.ConnectionConfig()
    self.connection_config.fake_database.SetInParent()


class AiPlatformMetadataClient(object):
  """Client used to expose experiment tracking service APIs.

  Interacts with MLMD.

  Attributes:
    current_experiment: The current Experiment Context of this client.
    current_execution: The current Execution of current Experiment.
    _store: MLMD store used to store experiment tracking metadata.
  """

  def __init__(self, config: Union[InMemoryConfig, stores.AiPlatformConfig]):
    """Initialize the experiment tracking client.

    Overloaded initialization that will change backend MLMD store based on
    parameters. Only one parameter should be passed.

    Args:
      config: Database config.
    """
    if isinstance(config, InMemoryConfig):
      self._store = metadata_store.MetadataStore(config.connection_config)
    else:
      self._store = stores.AiPlatformMetadataStore.init_from_config(config)

    self._register_types_to_store()

    # Attribute to track current Experiment for this client. Experiment and
    # setting methods should use this attribute.
    # Logging methods should rely on the property _current_experiment which will
    # automatically create a default Experiment if one doesn't exist.
    # The user of the client should rely on the property current_experiment.
    self._internal_current_experiment: Optional[
        contexts.ExperimentContext] = None

    # Attribute to track current Execution for this client. Experiment and
    # Execution setting methods should use this attribute.
    # Logging methods should rely on the property _current_execution which will
    # automatically create a default Execution if one doesn't exist.
    # The user of the client should rely on the property current_execution.
    self._internal_current_execution: Optional[executions.Execution] = None

    # A flag to lock the changing of experiment when using the self.experiment
    # context manager.
    self._experiment_lock = False

  def _register_types_to_store(self):
    """Registers all types in store when client is initialized."""
    contexts.ExperimentContext.register_type(self._store)
    executions.NotebookExecution.register_type(self._store)
    artifacts.GenericArtifact.register_type(self._store)
    artifacts.MetricArtifact.register_type(self._store)
    artifacts.DatasetArtifact.register_type(self._store)
    artifacts.ModelArtifact.register_type(self._store)

  def set_experiment(self, name: str):
    """Sets the current Experiment for this client.

    Usage:

    client.set_experiment("My Experiment")

    A client can only have one set Experiment. The Experiment name is unique.

    If an Experiment with the given name does not exist, a new
    Experiment with that name will be created. Otherwise, the Experiment will be
    reused.

    Args:
      name: The name of an Experiment.

    Raises:
      ValueError: If this method is invoked within a self.experiment context.
    """
    # check to see if we are already within an experiment context manager
    if self._experiment_lock:
      raise ValueError(
          'Cannot change the experiment when within another experiment')

    self._internal_current_experiment = contexts.ExperimentContext.get_or_create(
        store=self._store, name=name)
    self._internal_current_execution = None

  @contextlib.contextmanager
  def experiment(
      self, name: str) -> Generator['AiPlatformMetadataClient', None, None]:
    """Sets the experiment using a context manager.

    Sets the experiment with the given name using a context manager. When
    exiting the context manager the experiment is set back to the previously set
    experiment.

    The experiment cannot be set again until after exiting the context.

    Logging can continue against this client or against the yielded client.

    Usage:

    with client.experiment('my_experiment'):
      client.log_metric(...)

    with client.experiment('my_experiment') as my_experiment:
      my_experiment.log_metric(...)

    Raises Exception:
    with client.experiment('my_experiment'):
      with client.experiment('my_other_experiment'):

    with client.experiment('my_experiment') as my_experiment:
      my_experiment.set_experiment('my_other_experiment')

    If an Experiment with the given name does not exist, a new
    Experiment with that name will be created. Otherwise, the Experiment will be
    reused.

    Args:
      name: The name of an Experiment.

    Yields:
      AiPlatformMetadataClient: This client with experiment locked.
    Raises:
      ValueError: If this method is invoked when already within an experiment
      context.
    """
    # check to see if we are already within an experiment context manager
    if self._experiment_lock:
      raise ValueError(
          'Cannot change the experiment when within another experiment')

    previous_experiment = self._internal_current_experiment
    # set to the given experiment and lock the client at this experiment
    try:
      self._experiment_lock = True
      self._internal_current_experiment = contexts.ExperimentContext.get_or_create(
          store=self._store, name=name)
      self._internal_current_execution = None
      yield self
    finally:
      # reset to the experiment before entering the context manager
      # and release the lock so experiment can be set again
      self._internal_current_experiment = previous_experiment
      self._internal_current_execution = None
      self._experiment_lock = False

  def log_metric(self, key: str, value: float) -> artifacts.MetricArtifact:
    """Log a Metric with specified property key and value.

    Calling log_metric multiple times overwrites the value that has same key.

    Args:
      key: Metric's property key.
      value: Metric's property value.

    Returns:
      Logged Metric
    """
    return self.log_metrics(**{key: value})

  def log_metrics(self, **kwargs: float) -> artifacts.MetricArtifact:
    """Log multiple Metrics with specified custom property key and value pairs.

    Args:
      **kwargs: Metric's custom property key value pairs.

    Returns:
      Logged Metric
    """

    output_artifacts = self._current_execution.get_output_artifacts()
    # Filter output metric from the output_artifacts
    output_metrics = [
        artifact for artifact in output_artifacts
        if artifact.type_id == artifacts.MetricArtifact.get_type_id()
    ]

    if output_metrics:
      # If there is output metric, there will only one.
      metric = output_metrics[0]
      metric.put_custom_properties(node=metric.node, properties=dict(kwargs))
      metric.update_node()
    else:
      metric = artifacts.MetricArtifact.create(
          store=self._store,
          # Even though we set this property, it will be empty storing in MLMD.
          metric_type='inline_scalars',
          properties=dict(kwargs))
      self._current_execution.add_output(metric)  # pytype:disable=attribute-error
      self._current_experiment.attribute_artifact(metric)
    return metric  # pytype:disable=bad-return-type

  def log_artifact(self,
                   artifact: Any,
                   name: Optional[str] = None,
                   uri: Optional[str] = None) -> artifacts.GenericArtifact:
    """Logs a generic Artifact to the current Execution.

    Args:
      artifact: Any artifact object to log.
      name (optional): The name of this artifact.
      uri (optional): The uri for this artifact

    Returns:
      A GenericArtifact metadata object representing this artifact.
    """
    artifact_metadata = artifacts.GenericArtifact.create(
        self._store, name=name, uri=uri)
    self._current_experiment.attribute_artifact(artifact_metadata)
    artifacts.OBJECT_ID_TO_ARTIFACT_MAP[artifact] = artifact_metadata
    self._current_execution.add_output(artifact_metadata)
    return artifact_metadata

  def log_parameter(self, key: str, value: Union[float, str, int]):
    """Logs a single parameter to the current Execution.

    This will overwrite parameters in the Execution if given the same key.

    Args:
      key: Parameter name.
      value: Parameter value.
    """
    self.log_parameters(**{key: value})

  def log_parameters(self, **kwargs: Union[float, str, int]):
    """Logs parameters to the current Execution.

    This will overwrite parameters in the Execution if given the same key.

    Args:
      **kwargs: Parameters as key value pairs.
    """
    self._current_execution.add_parameters(kwargs)

  def log_dataset(
      self,
      dataset: Any,
      name: Optional[str] = None,
      uri: Optional[str] = None,
      environment: Optional[str] = None,
      container_format: Optional[str] = None,
      payload_format: Optional[str] = None) -> artifacts.DatasetArtifact:
    """Logs a dataset to the current Experiment.

    Args:
      dataset: A dataset object like a pandas.DataDrame or numpy.ndarray.
      name (Optional): The name of this Dataset, if not set, will be assigned by
        system.
      uri (Optional): The uri of this Dataset.
      environment (Optional): The environment for this dataset. Examples: -
        Training - Serving
      container_format (Optional): Format of the container. Examples: - TFRecord
        - Text - Parquet - NPZ
      payload_format (Optional): Encoding format. Examples:
                                 - proto:tf.Example - JSON - CSV

    Returns:
      A Dataset metadata object representing the given dataset.
    """
    dataset_metadata = artifacts.DatasetArtifact.create(
        self._store,
        name=name,
        uri=uri,
        environment=environment,
        container_format=container_format,
        payload_format=payload_format)
    self._current_experiment.attribute_artifact(dataset_metadata)
    artifacts.OBJECT_ID_TO_ARTIFACT_MAP[dataset] = dataset_metadata
    self._current_execution.add_output(dataset_metadata)
    return dataset_metadata

  def get_dataset(self,
                  dataset_id: Union[str, int],
                  assign_as_input: bool = False) -> artifacts.DatasetArtifact:
    """Gets dataset metadata.

    After getting metadata to track the object through execution bind the object
    instantiated with metadata.

    Example Usage:

    dataset_metadata = client.get_dataset(my_dataset_id, assign_as_input=True)
    dataframe = pd.Dataframe(dataset_metadata.uri)
    dataset_metadata.bind_object(dataframe)

    Args:
      dataset_id: The id of the dataset to get. Can be a resource id or fully
        qualified resource path.
      assign_as_input: If True, will assign this Dataset as input to the current
        Execution.
    Returns:
      Dataset Metadata.
    """
    dataset_artifact = artifacts.DatasetArtifact.get(self._store, dataset_id)

    if assign_as_input:
      self._current_execution.add_input(dataset_artifact)
    return dataset_artifact

  def get_model(self,
                model_id: Union[str, int],
                assign_as_input: bool = False) -> artifacts.ModelArtifact:
    """Gets Model metadata.

    After getting metadata to track the object through execution bind the object
    instantiated with metadata.

    Example Usage:

    model_metadata = client.get_model(my_model_id, assign_as_input=True)
    model = keras.models.load_model(model_metadata.uri)
    model_metadata.bind_object(model)

    Args:
      model_id: The id of the model to get. Can be a resource id or fully
        qualified resource path.
      assign_as_input: If True, will assign this Model as input to the current
        Execution.
    Returns:
      Model Metadata.
    """
    model_artifact = artifacts.ModelArtifact.get(self._store, model_id)

    if assign_as_input:
      self._current_execution.add_input(model_artifact)
    return model_artifact

  def get_artifact(self,
                   artifact_id: Union[str, int],
                   assign_as_input: bool = False) -> artifacts.GenericArtifact:
    """Gets Generic Artifact metadata.

    After getting metadata to track the object through execution bind the object
    instantiated with metadata.

    Example Usage:

    artifact_metadata = client.get_artifact(my_artifact_id,
                                            assign_as_input=True)
    with file_io.FileIO(artifact_metadata.uri, mode='rb') as f:
      artifact = pickle.load(f)

    artifact_metadata.bind_object(artifact)

    Args:
      artifact_id: The id of the artifact to get. Can be a resource id or fully
        qualified resource path.
      assign_as_input: If True, will assign this GenericArtifact as input to the
        current Execution.
    Returns:
      Generic Artifact Metadata.
    """
    generic_artifact = artifacts.GenericArtifact.get(self._store, artifact_id)

    if assign_as_input:
      self._current_execution.add_input(generic_artifact)
    return generic_artifact

  def get_experiments_dataframe(self) -> pd.DataFrame:
    """Returns a Pandas DataFrame of all the Experiments in the store.

    Includes metrics and parameters for all the Experiments.

    Example:

    client.set_experiment('exp-1')
    client.log_parameter(key='learning_rate', value=0.1)
    client.log_metric(key='accuracy', value=0.9)

    client.set_experiment('exp-2')
    client.log_parameter(key='learning_rate', value=0.01)
    client.log_metric(key='accuracy', value=0.95)

    Will result in the following DataFrame
    ___________________________________________________________________________
    | experiment_name | experiment_id | param.learning_rate | metric.accuracy |
    ---------------------------------------------------------------------------
    | exp-1           | 1             | 0.1                 | 0.9             |
    | exp-2           | 2             | 0.01                | 0.95            |
    ---------------------------------------------------------------------------

    The DataFrame will also contain an execution_name and execution_id field
    to support experiments with multiple executions. Example:

    @client.execution(name='my_execution')
    def f(key, value):
      client.log_metric(key=key, value=value)

    client.set_experiment('exp-1')

    f('x', 0.1)
    f('x', 0.2)
    f('x', 0.3)

    Result in the following DataFrame (experiment_id omitted).

    ______________________________________________________________
    | experiment_name | execution_name | execution_id | metric.x |
    --------------------------------------------------------------
    | exp-1           | my_execution   | 1            | 0.1      |
    | exp-1           | my_execution   | 2            | 0.2      |
    | exp-1           | my_execution   | 3            | 0.3      |
    --------------------------------------------------------------

    Returns:
      Pandas Dataframe of Experiments with metrics and parameters.
    """

    def execution_to_column_named_properties(
        property_type: str, node: Union[executions.Execution,
                                        artifacts.Artifact]
    ) -> Dict[str, Union[int, float, str]]:
      """Returns a dict of the Execution properties with column names.

      Args:
        property_type: The type of this execution properties (param, metric).
        node: Either an Execution of and Artifact MLMD node.

      Returns:
        Dict of custom properties with keys mapped to column names
      """
      return {
          '.'.join([property_type, key]): value
          for key, value in node.get_custom_properties_as_dict().items()
      }

    experiments = contexts.ExperimentContext.get_all(self._store)
    # TODO(b/170751417): Filter if experiment_name is provided.
    # TODO(b/170752144): Limit size if max_size is provided.
    experiment_dicts = []
    for experiment in experiments:
      experiment_dict = experiment.as_dict()

      experiment_executions = []
      experiment_lineage_subgraph = None
      # if managed
      if not isinstance(self._store, metadata_store.MetadataStore):
        experiment_dict['experiment_resource_name'] = experiment_dict[
            'experiment_name']
        experiment_dict['experiment_name'] = experiment_dict[
            'experiment_name'].split('/')[-1]
        experiment_dict.pop('experiment_id')
        experiment_lineage_subgraph = context_lineage_subgraph.query_lineage_subgraph(
            self._store, experiment.name)
        experiment_executions = experiment_lineage_subgraph.get_executions()
      else:
        experiment_executions = executions.get_executions_by_context(
            self._store, experiment)

      for execution in experiment_executions:
        execution_dict = {}
        execution_dict.update(experiment_dict)

        output_artifacts = []
        # if not managed
        if isinstance(self._store, metadata_store.MetadataStore):
          execution_dict['execution_id'] = execution.node_id
          execution_dict['execution_name'] = execution.name
          output_artifacts = execution.get_output_artifacts()
        else:
          execution_dict['execution_name'] = execution.name
          execution_dict['execution_resource_name'] = execution.node.name
          output_artifacts = experiment_lineage_subgraph.get_output_artifacts_for_execution(
              execution.node_id)

        execution_dict.update(
            execution_to_column_named_properties('param', execution))

        # Only one inline_scalar metric per run.
        metric_artifact = [
            artifact for artifact in output_artifacts
            if isinstance(artifact, artifacts.MetricArtifact) and
            artifact.metric_type == 'inline_scalars'
        ]
        if metric_artifact:
          execution_dict.update(
              execution_to_column_named_properties('metric',
                                                   metric_artifact[0]))
        experiment_dicts.append(execution_dict)

      # Handle corner case of set experiments but not executing/logging.
      if not experiment_executions:
        experiment_dicts.append(experiment_dict)

    return pd.DataFrame(experiment_dicts)

  @property
  def _current_experiment(self) -> contexts.ExperimentContext:
    """The current Experiment for this client.

    If the current Experiment is None a new one will be created. Logging methods
    should rely on this property.

    Returns:
      The current Experiment for this client.
    """
    if self._internal_current_experiment is None:
      self._internal_current_experiment = contexts.ExperimentContext.get_or_create(
          self._store, name='default experiment %s' % datetime.datetime.now())
    return self._internal_current_experiment

  @property
  def current_experiment(self) -> Optional[contexts.ExperimentContext]:
    """The current Experiment for this client if one has been set."""
    return self._internal_current_experiment

  @property
  def _current_execution(self) -> executions.Execution:
    """The current Execution for the current Experiment.

    If the current Execution is None a new one will be created. Logging methods
    should rely on this property.

    Returns:
      The current Execution for this client.
    """
    # TODO(huozicheng): We should reevaluate if user wants to create new
    #                   Execution when they are reusing experiment.
    if self._internal_current_execution is None:
      self._internal_current_execution = executions.NotebookExecution.create(
          store=self._store, execution_contexts=[self._current_experiment])

    return self._internal_current_execution

  @property
  def current_execution(self) -> Optional[executions.Execution]:
    """The current execution in current experiment context if one exists."""
    return self._internal_current_execution

  def log_model(
      self,
      model: Any,
      name: Optional[str] = None,
      uri: Optional[str] = None,
      framework: Optional[str] = None,
      framework_version: Optional[str] = None) -> artifacts.ModelArtifact:
    """Logs a model to the current Experiment.

    Args:
      model: A ML model object like a keras.Model or sklearn Estimator.
      name (Optional): Descriptive name of the model.
      uri (Optional): Uri where this model is stored.
      framework(Optional): The ML framework of the model like Tensorflow or
        Pytorch.
      framework_version(Optional): The version of the ML framework for the
        Model.

    Returns:
      A Model metadata object representing the given model.
    """
    model_metadata = artifacts.ModelArtifact.create(
        self._store,
        name=name,
        uri=uri,
        framework=framework,
        framework_version=framework_version)
    self._current_experiment.attribute_artifact(model_metadata)
    artifacts.OBJECT_ID_TO_ARTIFACT_MAP[model] = model_metadata
    self._current_execution.add_output(model_metadata)
    return model_metadata

  def execution(
      self,
      name: Optional[str] = None,
      description: Optional[str] = None) -> Callable[[Callable[..., T]], T]:
    """Execution decorator used to decorate and capture methods as Executions.

    When the decorated method is invoked the Execution will be captured. Input
    arguments will be captured in input Artifacts to the Execution if that
    Artifact has been logged by the client. Artifact logged in the method will
    be captured as outputs to that Execution.

    Note: Input Artifacts are only captured if they are logged before
    invocation. (b/156645928)
    Note: Output Artifacts are only captured if they are logged within the
    method. (b/156645928)

    Usage:

    @client.execution(name='Trainer')
    def my_train_method(X, Y):
      model = train_model(X, y)
      model.log_model(model, 'my_model')
      return model

    X, Y = get_data()
    model = my_train_model(X, Y)

    Args:
      name(Optional): The descriptive name for this Execution.
      description(Optional): A short text description of the purpose of this
        execution.

    Returns:
      Wrapped method that captures Execution metadata and invokes method.
    Raises:
      Any Exception raised by the invoked method.
    """

    def wrapper(method: Callable[..., T]) -> Callable[..., T]:
      source = inspect.getsource(method)
      signature = inspect.signature(method)

      def method_with_metadata_logging(*args, **kwargs) -> T:
        bounded_args = signature.bind(*args, **kwargs)

        # If any of the input arguments are logged artifacts, add them as
        # inputs to the Execution.
        input_artifacts = {
            parameter: artifacts.OBJECT_ID_TO_ARTIFACT_MAP[argument]
            for parameter, argument in bounded_args.arguments.items()
            if argument in artifacts.OBJECT_ID_TO_ARTIFACT_MAP
        }

        self._internal_current_execution = executions.NotebookExecution.create(
            self._store,
            name=name,
            description=description,
            code=source,
            custom_properties={
                parameter: argument
                for parameter, argument in bounded_args.arguments.items()
                if type(argument) in (int, float, bool, str)
            },
            execution_contexts=[self._current_experiment])

        # Log id if OSS and resource name is managed
        id_or_resource_name = 'id' if isinstance(
            self._store, metadata_store.MetadataStore) else 'resource_name'

        # TODO(b/170751676) add custom property logging when supported
        logging.info(
            'Logging "%s" execution \n%s: %s%s%s',
            self._internal_current_execution.name,
            id_or_resource_name,
            self._internal_current_execution.node_id,
            '\nInput Artifacts to %s: \n  ' %
            id_or_resource_name if input_artifacts else '',
            '\n  '.join('%s: %s' % (key, artifact.node_id)
                        for key, artifact in input_artifacts.items()))

        if input_artifacts:
          self._current_execution.add_input(input_artifacts)

        try:
          result = method(*args, **kwargs)
        except Exception as e:
          self._current_execution.update_state_failed()
          self._internal_current_execution = None
          raise e

        self._current_execution.update_state_complete()
        self._internal_current_execution = None
        return result

      return method_with_metadata_logging

    return wrapper

  def graph_experiment(self, experiment_name: Optional[str] = None):
    """Visually graph the specified/current Experiment.

    Args:
      experiment_name(Optional): The resource name of the Experiment to graph.
        Defaults to the current Experiment.

    Raises:
      ValueError: If this method is invoked when not within an experiment and
      one isn't specified.
    """
    # pylint: disable=g-import-not-at-top
    try:
      from IPython.display import display
      from IPython.display import Image
    except ImportError as e:
      raise ImportError(
          'graph_experiment is only available when using IPython.') from e
    try:
      import networkx as nx
    except ImportError as e:
      raise ImportError(
          'networkx and pygraphviz must be installed to use graph_experiment.'
      ) from e
    # pylint: enable=g-import-not-at-top

    def _middle_concatenation(value: str) -> str:
      """Concatenates middle of string if longer than 31 characters."""
      return value if len(value) < 32 else '...'.join([value[:14], value[-14:]])

    def _stringify_execution(execution: metadata_store_pb2.Execution) -> str:
      """Produce a string representation of an execution for display.

      Args:
        execution: The execution to represent as a string.

      Returns:
        A string representation of the execution.
      """
      #  Use last token of resource name for managed store, otherwise use id.
      execution_name = execution.name.split('/')[-1] if not isinstance(
          self._store, metadata_store.MetadataStore) else execution.id
      execution_str = ('Execution\n{}\n{}').format(execution.type,
                                                   execution_name)
      return '\n'.join([
          execution_str,
          _stringify_properties(execution.properties),
          _stringify_properties(execution.custom_properties)
      ])

    def _stringify_artifact(artifact: metadata_store_pb2.Artifact) -> str:
      """Produce a string representation of an artifact for display.

      Args:
        artifact: The artifact to represent as a string.

      Returns:
        A string representation of the artifact.
      """
      #  Use last token of resource name for managed store, otherwise use id.
      artifact_name = artifact.name.split('/')[-1] if not isinstance(
          self._store, metadata_store.MetadataStore) else artifact.id
      artifact_str = ('Artifact\n{}\n{}').format(artifact.type, artifact_name)
      return '\n'.join([
          artifact_str,
          'uri: %s' % _middle_concatenation(artifact.uri),
          _stringify_properties(artifact.properties),
          _stringify_properties(artifact.custom_properties)
      ])

    def _stringify_properties(
        properties_map: Dict[str, metadata_store_pb2.Value]) -> str:
      """Produce a string representation of a properties map for display.

      Args:
        properties_map: A map of properties to display.

      Returns:
        A string representation of the properties map.
      """
      properties = []
      key_values = sorted(properties_map.items(), reverse=True)
      for key, value in key_values:
        if key == 'code':
          continue
        key = key.split('.')[-1]
        this_str = '{}: {}'.format(key,
                                   _retrieve_value_from_property_value(value))
        properties.append(this_str)
      return '\n'.join(properties)

    def _retrieve_value_from_property_value(
        property_value: metadata_store_pb2.Value) -> str:
      """Obtain a truncated string value from a general Value field.

      The middle of the string may be collapsed such that no string
      returned from this function exceeds 31 characters in length.

      Args:
        property_value: The Value to produce a truncated string for.

      Returns:
        A string of the Value that is 31 characters long or fewer.
      """
      value = str(getattr(property_value,
                          property_value.WhichOneof('value'))).strip()
      # All values returned as 31 characters or fewer by truncating the middle
      return _middle_concatenation(value)

    if experiment_name is None and self.current_experiment is None:
      raise ValueError(
          'No experiment to graph. Must be within an experiment or one must be specified.'
      )

    mlmd_lineage_subgraph = self._store.get_context_graph(
        experiment_name or self.current_experiment.name,
        out_of_context_artifacts=True
        )
    execution_map = {
        execution.id: _stringify_execution(execution)
        for execution in mlmd_lineage_subgraph.executions
    }
    artifact_map = {
        artifact.id: _stringify_artifact(artifact)
        for artifact in mlmd_lineage_subgraph.artifacts
    }
    digraph = nx.DiGraph()
    digraph.add_nodes_from(
        list(execution_map.values()) + list(artifact_map.values()))
    for event in mlmd_lineage_subgraph.events:
      if event.type == metadata_store_pb2.Event.Type.INPUT:
        digraph.add_edge(artifact_map[event.artifact_id],
                         execution_map[event.execution_id])
      else:
        digraph.add_edge(execution_map[event.execution_id],
                         artifact_map[event.artifact_id])
    nx.nx_agraph.write_dot(digraph, 'test.dot')
    agraph = nx.nx_agraph.to_agraph(digraph)
    agraph.layout(
        'dot',
        args='-Nfontsize=10 -Nwidth=".2" -Nheight=".2" -Nmargin=0 -Gfontsize=8')
    agraph.draw('test.png')
    display(Image('test.png'))
