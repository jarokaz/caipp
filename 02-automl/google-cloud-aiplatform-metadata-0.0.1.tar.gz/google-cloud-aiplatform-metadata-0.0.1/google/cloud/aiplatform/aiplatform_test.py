# Lint as: python3
"""Tests for google3.cloud.aiplatform."""

import unittest

from google.cloud import aiplatform
from google.cloud.aiplatform import clients

_EXPERIMENT_NAME = 'test_experiment'
_OTHER_EXPERIMENT_NAME = 'other_test_experiment'
_TEST_METRIC_NAME_1 = 'test_metric_1'
_TEST_METRIC_NAME_2 = 'test_metric_2'
_TEST_MODEL_NAME_1 = 'test_model_1'
_TEST_MODEL_NAME_2 = 'test_model_2'
_TEST_ARTIFACT_NAME_1 = 'test_artifact_1'
_PARAMETER_KEY_1 = 'test_parameter_key_1'
_PARAMETER_KEY_2 = 'test_parameter_key_2'
_PARAMETER_VALUE_1 = 'test_value_key_1'
_PARAMETER_VALUE_2 = 1.0
_TEST_DATASET_NAME_1 = 'test_dataset_1'
_TEST_DATASET_URI_1 = 'https://test-dataset.foo-website.com'
_TEST_DATASET_ENVIRONMENT = 'Training'
_TEST_DATASET_CONTAINER_FORMAT = 'Text'
_TEST_DATASET_PAYLOAD_FORMAT = 'JSON'


class AiPlatformTest(unittest.TestCase):

  def setUp(self):
    super().setUp()
    aiplatform._reset()

  def test_aiplatform_connects(self):
    self.assertIsNone(aiplatform._client)
    aiplatform.connect()
    self.assertIsNotNone(aiplatform._client)

  def test_aiplatform_throws_error_if_not_connected(self):
    with self.assertRaises(RuntimeError):
      aiplatform.set_experiment(_EXPERIMENT_NAME)

  def test_aiplatform_and_client_set_same_experiment(self):
    aiplatform.connect()
    aiplatform.set_experiment(_EXPERIMENT_NAME)
    aiplatform_experiment = aiplatform.get_current_experiment()

    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    # Must use the same store because the InMemoryConfig creates a new store.
    client._store = aiplatform._client._store
    client.set_experiment(_EXPERIMENT_NAME)
    client_experiment = client.current_experiment
    self.assertEqual(aiplatform_experiment, client_experiment)

  def test_aiplatform_and_client_set_same_experiment_with_context_manager(self):
    aiplatform.connect()
    with aiplatform.experiment(_EXPERIMENT_NAME):
      aiplatform_experiment = aiplatform.get_current_experiment()

    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client._store = aiplatform._client._store
    with client.experiment(_EXPERIMENT_NAME):
      client_experiment = client.current_experiment

    self.assertEqual(aiplatform_experiment, client_experiment)

  def test_aiplatform_and_client_have_unique_executions_with_same_experiments(
      self):
    aiplatform.connect()
    aiplatform.set_experiment(_EXPERIMENT_NAME)
    aiplatform.log_metrics(test_metric_1=1.0, test_metric_2=0.5)

    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client._store = aiplatform._client._store
    client.set_experiment(_EXPERIMENT_NAME)
    client.log_metrics(test_metric_1=1.0, test_metric_2=0.5)

    aiplatform_execution = aiplatform.get_current_execution()
    client_execution = client.current_execution

    self.assertNotEqual(aiplatform_execution.node_id, client_execution.node_id)

  def test_aiplatform_and_client_create_different_default_experiments(self):
    aiplatform.connect()
    aiplatform.log_metrics(test_metric_1=1.0, test_metric_2=0.5)

    client = clients.AiPlatformMetadataClient(clients.InMemoryConfig())
    client._store = aiplatform._client._store
    client.log_metrics(test_metric_1=1.0, test_metric_2=0.5)

    aiplatform_experiment = aiplatform.get_current_experiment()
    client_experiment = client.current_experiment

    self.assertNotEqual(aiplatform_experiment.node_id,
                        client_experiment.node_id)


if __name__ == '__main__':
  unittest.main()
