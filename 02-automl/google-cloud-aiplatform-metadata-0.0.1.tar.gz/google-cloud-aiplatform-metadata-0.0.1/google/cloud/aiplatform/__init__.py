# Lint as: python3
"""SDK APIs for Experiment tracking using Cloud ML Metadata.

Below is the singleton client implementation to expose ML Metadata
logging at the root module level. Usage pattern:

from google.cloud import aiplatform

aiplatform.connect(project='my-project', location='us-central1')

aiplatform.set_experiment('my_experiment')
aiplatform.log_dataset(my_dataset, name='my_dataset')

with aiplatform.experiment('my_training_experiment'):
  aiplatform.log_parameter(key='learning_rate', value=0.01)
  aiplatform.log_model(model, name='my_model')
  aiplatform.log_metric(key='accuracy', value=my_accuracy)

aiplatform.connect must be called to connect to store before invoking other
logging methods.
"""
import functools
import importlib
import sys
from typing import Any, Callable, ContextManager, Optional, Generator, TypeVar, Union
import pandas as pd

from google.cloud.aiplatform import clients
from google.cloud.aiplatform import stores
from google.cloud.aiplatform import types

T = TypeVar('T')

# Singleton AiPlatformMetadata client used for root module logging invocations.
_client: Optional[clients.AiPlatformMetadataClient] = None


def _reset():
  """Reloads all type modules, clearing type_ids and artifacts.OBJECT_ID_TO_ARTIFACT_MAP."""
  global _client
  _client = None
  importlib.reload(types.artifacts)
  importlib.reload(types.executions)
  importlib.reload(types.contexts)


def connect(metadata_store_resource_name: Optional[str] = None,
            *,
            project: Optional[str] = None,
            location: Optional[str] = 'us-central1',
            store_name: Optional[str] = 'default'):
  """Connects to a metadata store.

  aiplatform.connect('projects/my-project/location/us-central1/metadataStores/my-store')
  If metadata_store_resource_name is set in config, that store must exist and
  will be used.


  aiplatform.connect(project='my-project', location='us-central1')
  If only project and location are set in config, 'default' store will be
  used. If 'default' store doesn't exist it will be created.

  aiplatform.connect(project='my-project', location='us-central1',
                   store='my-store')
  If project, location, and store_name are set in config, that store will be
  used. If it doesn't exist it will be created.

  aiplatform.connect()
  If none of the args are provided a temporary local in-memory MLMD store will
  be used.

  Args:
    metadata_store_resource_name: fully qualified metadata resource name
    project: GCP project name or id
    location: GCP region for metadata store
    store_name: name of the metadata store
  """
  global _client
  _reset()
  if metadata_store_resource_name:
    config = stores.AiPlatformConfig(metadata_store_resource_name)
  elif project:
    config = stores.AiPlatformConfig(
        project=project, location=location, store_name=store_name)
  else:
    config = clients.InMemoryConfig()
  _client = clients.AiPlatformMetadataClient(config)


def _assert_client_is_connected(
    method: Callable[..., Any]) -> Callable[..., Any]:
  """Decorator to check the client has been connected before invoking wrapped method.

  Args:
    method: The method to wrap.

  Raises:
    RuntimeError: If the client has not been connected when invoking wrapped
    method.
  Returns:
    Wrapped method that checks to see in the client has been connected.
  """

  @functools.wraps(method)
  def wrapper(*args, **kwargs):
    global _client
    if _client is None:
      raise RuntimeError(
          'Must connect to store with %s.connect before calling %s.%s' %
          (__name__, __name__, method.__name__))
    return method(*args, **kwargs)

  return wrapper


@_assert_client_is_connected
def set_experiment(name: str):
  """Sets the current Experiment.

  Usage:

  aiplatform.set_experiment("My Experiment")

  Only one Experiment can be set at a time. The Experiment name is unique.

  If an Experiment with the given name does not exist, a new
  Experiment with that name will be created. Otherwise, the Experiment will be
  reused.

  Args:
    name: The name of an Experiment.

  Raises:
    ValueError: If this method is invoked within a experiment context.
  """
  _client.set_experiment(name)


@_assert_client_is_connected
def experiment(name: str) -> ContextManager[clients.AiPlatformMetadataClient]:
  """Sets the experiment using a context manager.

  Sets the experiment with the given name using a context manager. When
  exiting the context manager the experiment is set back to the previously set
  experiment.

  The experiment cannot be set again until after exiting the context.

  Logging can continue against this client or against the yielded client.

  Usage:

  with aiplatform.experiment('my_experiment'):
    aiplatform.log_metric(...)

  with aiplatform.experiment('my_experiment') as my_experiment:
    my_experiment.log_metric(...)

  Raises Exception:
  with aiplatform.experiment('my_experiment'):
    with aiplatform.experiment('my_other_experiment'):

  with aiplatform.experiment('my_experiment') as my_experiment:
    my_experiment.set_experiment('my_other_experiment')

  If an Experiment with the given name does not exist, a new
  Experiment with that name will be created. Otherwise, the Experiment will be
  reused.

  Args:
    name: The name of an Experiment.

  Returns:
    Experiment context manager
  """
  return _client.experiment(name)


@_assert_client_is_connected
def log_metric(key: str, value: float) -> types.artifacts.MetricArtifact:
  """Log a Metric with specified property key and value.

  Calling log_metric multiple times overwrites the value that has same key.

  Args:
    key: Metric's property key.
    value: Metric's property value.

  Returns:
    Logged Metric
  """
  return _client.log_metric(key=key, value=value)


@_assert_client_is_connected
def log_metrics(**kwargs: float) -> types.artifacts.MetricArtifact:
  """Log multiple Metrics with specified custom property key and value pairs.

  Args:
    **kwargs: Metric's custom property key value pairs.

  Returns:
    Logged Metric
  """
  return _client.log_metrics(**kwargs)


@_assert_client_is_connected
def log_artifact(artifact: Any,
                 name: Optional[str] = None,
                 uri: Optional[str] = None) -> types.artifacts.GenericArtifact:
  """Logs a generic Artifact to the current Execution.

  Args:
    artifact: Any artifact object to log.
    name (optional): The name of this artifact.
    uri (optional): The uri for this artifact

  Returns:
    A GenericArtifact metadata object representing this artifact.
  """
  return _client.log_artifact(artifact=artifact, name=name, uri=uri)


@_assert_client_is_connected
def log_parameter(key: str, value: Union[float, str, int]):
  """Logs a single parameter to the current Execution.

  This will overwrite parameters in the Execution if given the same key.

  Args:
    key: Parameter name.
    value: Parameter value.
  """
  _client.log_parameter(key, value)


@_assert_client_is_connected
def log_parameters(**kwargs: Union[float, str, int]):
  """Logs parameters to the current Execution.

  This will overwrite parameters in the Execution if given the same key.

  Args:
    **kwargs: Parameters as key value pairs.
  """
  _client.log_parameters(**kwargs)


@_assert_client_is_connected
def log_dataset(
    dataset: Any,
    name: Optional[str] = None,
    uri: Optional[str] = None,
    environment: Optional[str] = None,
    container_format: Optional[str] = None,
    payload_format: Optional[str] = None) -> types.artifacts.DatasetArtifact:
  """Logs a dataset to the current Experiment.

  Args:
    dataset: A dataset object like a pandas.DataDrame or numpy.ndarray.
    name (Optional): The name of this Dataset, if not set, will be assigned by
      system.
    uri (Optional): The uri of this Dataset.
    environment (Optional): The environment for this dataset. Examples: -
      Training - Serving
    container_format (Optional): Format of the container. Examples: - TFRecord -
      Text - Parquet - NPZ
    payload_format (Optional): Encoding format. Examples:
                               - proto:tf.Example - JSON - CSV

  Returns:
    A Dataset metadata object representing the given dataset.
  """
  return _client.log_dataset(
      dataset=dataset,
      name=name,
      uri=uri,
      environment=environment,
      container_format=container_format,
      payload_format=payload_format)


@_assert_client_is_connected
def get_dataset(
    dataset_id: Union[str, int],
    assign_as_input: bool = False) -> types.artifacts.DatasetArtifact:
  """Gets dataset metadata.

  After getting metadata to track the object through execution bind the object
  instantiated with metadata.

  Example Usage:

  dataset_metadata = aiplatform.get_dataset(my_dataset_id, assign_as_input=True)
  dataframe = pd.Dataframe(dataset_metadata.uri)
  dataset_metadata.bind_object(dataset_metadata)

  Args:
    dataset_id: The id of the dataset to get. Can be a resource id or fully
      qualified resource path.
    assign_as_input: If True, will assign this Dataset as input to the current
        Execution.
  Returns:
    Dataset Metadata.
  """
  return _client.get_dataset(dataset_id, assign_as_input=assign_as_input)


@_assert_client_is_connected
def get_model(
    model_id: Union[str, int],
    assign_as_input: bool = False) -> types.artifacts.ModelArtifact:
  """Gets Model metadata.

  After getting metadata to track the object through execution bind the object
  instantiated with metadata.

  Example Usage:

  model_metadata = aiplatform.get_model(my_model_id, assign_as_input=True)
  model = keras.models.load_model(model_metadata.uri)
  model_metadata.bind_object(model)

  Args:
    model_id: The id of the model to get. Can be a resource id or fully
      qualified resource path.
    assign_as_input: If True, will assign this Model as input to the current
      Execution.
  Returns:
    Model Metadata.
  """
  return _client.get_model(model_id, assign_as_input=assign_as_input)


@_assert_client_is_connected
def get_artifact(
    artifact_id: Union[str, int],
    assign_as_input: bool = False) -> types.artifacts.GenericArtifact:
  """Gets Generic Artifact metadata.

  After getting metadata to track the object through execution bind the object
  instantiated with metadata.

  Example Usage:

  artifact_metadata = aiplatform.get_artifact(my_artifact_id,
                                              assign_as_input=True)
  with file_io.FileIO(artifact_metadata.uri, mode='rb') as f:
    artifact = pickle.load(f)

  artifact_metadata.bind_object(artifact)

  Args:
    artifact_id: The id of the artifact to get. Can be a resource id or fully
      qualified resource path.
    assign_as_input: If True, will assign this GenericArtifact as input to the
      current Execution.
  Returns:
    Generic Artifact Metadata.
  """
  return _client.get_artifact(artifact_id, assign_as_input=assign_as_input)


@_assert_client_is_connected
def log_model(
    model: Any,
    name: Optional[str] = None,
    uri: Optional[str] = None,
    framework: Optional[str] = None,
    framework_version: Optional[str] = None) -> types.artifacts.ModelArtifact:
  """Logs a model to the current Experiment.

  Args:
    model: A ML model object like a keras.Model or sklearn Estimator.
    name (Optional): Descriptive name of the model.
    uri (Optional): Uri where this model is stored.
    framework(Optional): The ML framework of the model like Tensorflow or
      Pytorch.
    framework_version(Optional): The version of the ML framework for the Model.

  Returns:
    A Model metadata object representing the given model.
  """
  return _client.log_model(
      model=model,
      name=name,
      uri=uri,
      framework=framework,
      framework_version=framework_version)


@_assert_client_is_connected
def execution(
    name: Optional[str] = None,
    description: Optional[str] = None) -> Callable[[Callable[..., T]], T]:
  """Execution decorator used to decorate and capture methods as Executions.

  When the decorated method is invoked the Execution will be captured. Input
  arguments will be captured in input Artifacts to the Execution if that
  Artifact has been logged by aiplatform. Artifacts logged in the method will
  be captured as outputs to that Execution.

  Usage:

  @aiplatform.execution(name='Trainer')
  def my_train_method(X, Y):
    model = train_model(X, y)
    model.log_model(model, 'my_model')
    return model

  X, Y = get_data()
  model = my_train_model(X, Y)

  Args:
    name(Optional): The descriptive name for this Execution.
    description(Optional): A short text description of the purpose of this
      execution.

  Returns:
    Wrapped method that captures Execution metadata and invokes method.
  Raises:
    Any Exception raised by the invoked method.
  """
  return _client.execution(name=name, description=description)


@_assert_client_is_connected
def get_experiments_dataframe() -> pd.DataFrame:
  """Returns a Pandas Dataframe of all the Experiments in the store.

  Includes metrics and parameters for all the Experiments.

  Example:

  client.set_experiment('exp-1')
  client.log_parameter(key='learning_rate', value=0.1)
  client.log_metric(key='accuracy', value=0.9)

  client.set_experiment('exp-2')
  client.log_parameter(key='learning_rate', value=0.01)
  client.log_metric(key='accuracy', value=0.95)

  Will result in the following DataFrame
  ___________________________________________________________________________
  | experiment_name | experiment_id | param.learning_rate | metric.accuracy |
  ---------------------------------------------------------------------------
  | exp-1           | 1             | 0.1                 | 0.9             |
  | exp-2           | 2             | 0.01                | 0.95            |
  ---------------------------------------------------------------------------

  The DataFrame will also contain an execution_name and execution_id field
  to support experiments with multiple executions. Example:

  @client.execution(name='my_execution')
  def f(key, value):
    client.log_metric(key=key, value=value)

  client.set_experiment('exp-1')

  f('x', 0.1)
  f('x', 0.2)
  f('x', 0.3)

  Result in the following DataFrame (experiment_id omitted).

  ______________________________________________________________
  | experiment_name | execution_name | execution_id | metric.x |
  --------------------------------------------------------------
  | exp-1           | my_execution   | 1            | 0.1      |
  | exp-1           | my_execution   | 2            | 0.2      |
  | exp-1           | my_execution   | 3            | 0.3      |
  --------------------------------------------------------------

  Returns:
    Pandas Dataframe of Experiments with metrics and parameters.
  """
  return _client.get_experiments_dataframe()


@_assert_client_is_connected
def get_current_experiment() -> Optional[types.contexts.ExperimentContext]:
  """Get the current Experiment for this client if one has been set."""
  return _client.current_experiment


@_assert_client_is_connected
def get_current_execution() -> Optional[types.executions.Execution]:
  """Get the current execution in current experiment context if one exists."""
  return _client.current_execution


@_assert_client_is_connected
def graph_experiment(experiment_name: Optional[str] = None):
  """Visually graph the specified/current Experiment.

  Args:
    experiment_name(Optional): The resource name of the Experiment to graph.
      Defaults to the current Experiment.
  """
  _client.graph_experiment(experiment_name)
