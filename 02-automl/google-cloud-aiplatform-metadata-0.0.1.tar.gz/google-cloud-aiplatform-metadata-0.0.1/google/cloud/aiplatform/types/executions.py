# Lint as: python3
"""MLMD Execution types which include the Notebook Execution type."""
import collections
from typing import Mapping, Optional, Sequence, Text, Union, overload

from ml_metadata import metadata_store
from ml_metadata.proto import metadata_store_pb2
from google.cloud.aiplatform import stores
from google.cloud.aiplatform.types import artifacts
from google.cloud.aiplatform.types import base
from google.cloud.aiplatform.types import contexts
from google.cloud.aiplatform.utils import type_utils

from google.cloud.aiplatform_v1alpha1.types import event as gca_event


class Execution(base.NodeAndType):
  """Execution class representing the MLMD Execution Type.

  Attributes:
    type: MLMD type definition.
    node: MLMD node instance.
    type_id: id of type in metadata store.
    node_id: MLMD id for this node in metadata store.
    name: Execution name.
    state: State of current execution.
    contexts: Contexts of current Execution
  """
  _type = type_utils.create_type('aiplatform.Execution',
                                 metadata_store_pb2.ExecutionType)

  def __init__(self,
               store: metadata_store.MetadataStore,
               node: type_utils.MLMDNode,
               execution_contexts: Optional[Sequence[contexts.Context]] = None):
    """Intializes this MLMD type and node.

    Args:
      store: MLMD store for this type and node.
      node: MLMD node definition for the type and node.
      execution_contexts (Optional): The running context for this exeuction.
    """
    super().__init__(store=store, node=node)
    self._execution_contexts = execution_contexts

  @classmethod
  def _put_type(cls, store: metadata_store.MetadataStore) -> int:
    """Puts the execution type into the MLMD store.

    Args:
      store: MLMD store to put this MLMD type

    Returns:
      Type id for this Execution type in given MLMD store.
    """
    return store.put_execution_type(cls._type)

  @classmethod
  def _get_node_by_id(
      cls, store: metadata_store.MetadataStore,
      execution_id: Union[int, str]) -> Optional[metadata_store_pb2.Execution]:
    """Gets the Execution node by the id of this Execution.

    Args:
      store: MLMD store to retrieve Execution node from.
      execution_id: Id of the execution node to retrieve.

    Returns:
      Execution node instance in given MLMD store or None if it does not exist.
    """
    result = store.get_executions_by_id([execution_id])
    return result[0] if result else None

  @classmethod
  def _put_node_proxy(
      cls,
      store: Union[metadata_store.MetadataStore,
                   stores.AiPlatformMetadataStore],
      node: metadata_store_pb2.Execution,
      execution_contexts: Optional[Sequence[contexts.Context]] = None
  ) -> metadata_store_pb2.Execution:
    """Puts this Execution Node instance in given MLMD Store.

    Args:
      store: MLMD store to retrieve Execution node from.
      node: MLMD Execution node definition
      execution_contexts (Optional): Running contexts for this execution.

    Returns:
      Node ID for this MLMD Execution Node in given MLMD Store
    """
    if execution_contexts:
      execution_contexts = [context.node for context in execution_contexts]

    node_id = cls._put_node(store, node, execution_contexts)

    if isinstance(store, metadata_store.MetadataStore):
      node.id = node_id
    else:
      node.name = node_id
      node.id = hash(node_id)
    return node

  @classmethod
  def _put_node(
      cls,
      store: metadata_store.MetadataStore,
      node: metadata_store_pb2.Execution,
      execution_contexts: Optional[Sequence[metadata_store_pb2.Context]] = None
  ) -> int:
    """Puts this Execution Node instance in given MLMD Store.

    Args:
      store: MLMD store to retrieve Execution node from.
      node: MLMD Execution node definition
      execution_contexts (Optional): Running contexts for this execution.

    Returns:
      Node ID for this MLMD Execution Node in given MLMD Store
    """
    execution_contexts = execution_contexts if execution_contexts is not None else []

    return store.put_execution(
        execution=node,
        artifact_and_events=[],
        contexts=execution_contexts)[0]  # pytype:disable=attribute-error

  @classmethod
  def _get_node(cls, store: metadata_store.MetadataStore,
                execution_id: Union[int, str]) -> 'Execution':
    """Gets an Execution from given MLMD store.

    Args:
      store: MLMD store to get Execution from.
      execution_id: MLMD id of the Execution to get.

    Returns:
      Execution representing this instance in MLMD.
    Raises:
      ValueError if Execution is not found in given MLMD store.
    """

    cls.register_type(store)

    node = cls._get_node_by_id(store, execution_id)  # pytype: disable=wrong-arg-types

    if node is None:
      raise ValueError('%s %s not found in store' %
                       (cls._type.name, execution_id))

    return cls(store, node)  # pytype: disable=not-instantiable

  @overload
  def add_input(self, artifact: artifacts.Artifact) -> 'Execution':
    """Adds an Artifact as input artifact.

    Args:
      artifact: Input Artifact.

    Returns:
      NotebookExecution instance.
    """
    pass

  @overload
  def add_input(
      self, artifact_list: Sequence[artifacts.Artifact]
  ) -> 'Execution':  # pylint: disable=function-redefined
    """Adds a list of Artifacts as input artifacts.

    Args:
      artifact_list: Input Artifacts.

    Returns:
      NotebookExecution instance.
    """
    pass

  @overload
  def add_input(
      self, keyed_artifacts: Mapping[str, Union[Sequence[artifacts.Artifact],
                                                artifacts.Artifact]]
  ) -> 'Execution':  # pylint: disable=function-redefined
    """Adds a dictonary of Events as input Events.

     An event represents a relationship between an artifact and an execution.
     There are different kinds of events, relating to input, as
     well as how they are used by the mlmd powered system.
     For example, the INPUT events are part of the
     signature of this function. For example, consider:

     my_execution.add_input({"data":[3,7],"schema":8})

     Where 3, 7, and 8 are artifact_ids, assuming execution_id of my_execution
     is 12, input events are:
      {
         artifact_id:3,
         execution_id: 12,
         type:INPUT,
         path:{step:[{"key":"data"},{"index":0}]}
      }
      {
         artifact_id:7,
         execution_id: 12,
         type:INPUT,
         path:{step:[{"key":"data"},{"index":1}]}
      }
      {
         artifact_id:8,
         execution_id: 12,
         type:INPUT,
         path:{step:[{"key":"schema"}]}
      }

    Args:
      keyed_artifacts: A dictonary of events that keys are the step keys, values
        will be the index of input events.

    Returns:
      NotebookExecution instance.
    """
    pass

  def add_input(
      self,
      input_artifacts: Union[artifacts.Artifact, Sequence[artifacts.Artifact],
                             Mapping[str, Union[artifacts.Artifact,
                                                Sequence[artifacts.Artifact]]]]
  ) -> 'Execution':  # pylint: disable=function-redefined
    """Adds artifacts as input artifacts.

    Args:
      input_artifacts: Input Artifacts.

    Returns:
      NotebookExecution instance.
    """

    events = self._create_events(input_artifacts,
                                 metadata_store_pb2.Event.Type.INPUT)
    if self.is_managed_store():
      self._store.put_events(execution_name=self.node.name, events=events)
    else:
      self._store.put_events(events)
    return self

  @overload
  def add_output(self, artifact: artifacts.Artifact) -> 'Execution':
    """Adds an Artifact as output artifact.

    Args:
      artifact: Output Artifact.

    Returns:
      NotebookExecution instance.
    """
    pass

  @overload
  def add_output(
      self, artifact_list: Sequence[artifacts.Artifact]
  ) -> 'Execution':  # pylint: disable=function-redefined
    """Adds a list of Artifacts as output artifacts.

    Args:
      artifact_list: Output Artifacts.

    Returns:
      NotebookExecution instance.
    """
    pass

  @overload
  def add_output(
      self, keyed_artifacts: Mapping[str, Union[Sequence[artifacts.Artifact],
                                                artifacts.Artifact]]
  ) -> 'Execution':  # pylint: disable=function-redefined
    """Adds a dictonary of Events as output Events.

     An event represents a relationship between an artifact and an execution.
     There are different kinds of events, relating to output, as
     well as how they are used by the mlmd powered system.
     For example, the OUTPUT events are part of the
     signature of this function. For example, consider:

     my_execution.add_output({"data":[3,7],"schema":8})

     Where 3, 7, and 8 are artifact_ids, assuming execution_id of my_execution
     is 12, output events are:
      {
         artifact_id:3,
         execution_id: 12,
         type:OUTPUT,
         path:{step:[{"key":"data"},{"index":0}]}
      }
      {
         artifact_id:7,
         execution_id: 12,
         type:OUTPUT,
         path:{step:[{"key":"data"},{"index":1}]}
      }
      {
         artifact_id:8,
         execution_id: 12,
         type:OUTPUT,
         path:{step:[{"key":"schema"}]}
      }

    Args:
      keyed_artifacts: A dictonary of events that keys are the step keys, values
        will be the index of output events.

    Returns:
      NotebookExecution instance.
    """
    pass

  def add_output(
      self,
      output_artifacts: Union[artifacts.Artifact, Sequence[artifacts.Artifact],
                              Mapping[str, Union[artifacts.Artifact,
                                                 Sequence[artifacts.Artifact]]]]
  ) -> 'Execution':  # pylint: disable=function-redefined
    """Adds artifacts as output artifacts.

    Args:
      output_artifacts: Output Artifacts.

    Returns:
      NotebookExecution instance.
    """
    events = self._create_events(output_artifacts,
                                 metadata_store_pb2.Event.Type.OUTPUT)
    if self.is_managed_store():
      self._store.put_events(execution_name=self.node.name, events=events)
    else:
      self._store.put_events(events)
    return self

  def _update_state(self, state: metadata_store_pb2.Execution.State):
    """Updates execution state.

    Args:
      state: state to update.
    Raise: ValueError
    """

    states = metadata_store_pb2.Execution.State

    valid_state_transition = {
        states.RUNNING: [states.RUNNING, states.COMPLETE, states.FAILED],
        states.COMPLETE: [states.COMPLETE],
        states.FAILED: [states.FAILED]
    }

    if state not in valid_state_transition[self.state]:
      raise ValueError('Unable to transit from state: %s to %s.' %
                       (self.state, state))

    if state == valid_state_transition[self.state]:
      return

    self._node.last_known_state = state
    self._put_node_proxy(self._store, self._node, self._execution_contexts)

  def update_state_complete(self):
    """Updates the execution state to Complete."""
    self._update_state(metadata_store_pb2.Execution.State.COMPLETE)

  def update_state_failed(self):
    """Updates the execution state to Failed."""
    self._update_state(metadata_store_pb2.Execution.State.FAILED)

  def _create_events(
      self,
      artifacts_input: Union[artifacts.Artifact, Sequence[artifacts.Artifact],
                             Mapping[str, Union[artifacts.Artifact,
                                                Sequence[artifacts.Artifact]]]],
      event_type: metadata_store_pb2.Event.Type
  ) -> Union[Sequence[metadata_store_pb2.Event], Sequence[gca_event.Event]]:
    """Creates internal events driving function.

    Args:
      artifacts_input: this param accepts multiple formats: - Artifact -
        Sequence[Artifact] - A dictonary of key value pair, where key is the
        step key, value can be - int, to represent the artifact id -
        Sequence[int], to represent a sequenc of artifact ids.
      event_type: Input or Output Event.

    Returns:
     list of Events created
    """
    events = []

    if isinstance(artifacts_input, collections.abc.Mapping):
      for k, v in artifacts_input.items():
        # k is the key of path step
        # v is either an artifact id or a list of artifacts.
        if isinstance(v, Sequence):
          for index, artifact in enumerate(v):
            events.append(self._create_event(artifact, event_type, k, index))
        else:
          events.append(self._create_event(v, event_type, k))
    else:
      if not isinstance(artifacts_input, Sequence):
        artifacts_input = [artifacts_input]

      for artifact in artifacts_input:
        events.append(self._create_event(artifact, event_type))

    return events

  def _create_event(
      self,
      artifact: artifacts.Artifact,
      event_type: metadata_store_pb2.Event.Type,
      step_key: Optional[Text] = None,
      step_index_value: Optional[int] = None) -> metadata_store_pb2.Event:
    """Creates a event based on artifact id, execution id, event type, and optionally step key and step index.

    Args:
      artifact: artifact
      event_type: Input or Output event
      step_key (optional): Step Key
      step_index_value (optional): Step Index value

    Returns:
      Created event
    """

    if self.is_managed_store():
      event = gca_event.Event(
          artifact=artifact.node.name,
          type_=stores.event_type_to_managed_event_type[event_type])
    else:
      event = metadata_store_pb2.Event()
      event.artifact_id = artifact.node_id
      event.execution_id = self.node_id
      event.type = event_type

      if step_key is not None:
        event.path.steps.add().key = step_key

      if step_index_value is not None:
        event.path.steps.add().index = step_index_value
    return event

  def add_parameter(self, parameter_key: str, parameter_value: Union[float, str,
                                                                     int]):
    """Adds a parameter key value pair to this execution.

    Args:
      parameter_key: Parameter key.
      parameter_value: Parameter value.
    """
    self.add_parameters({parameter_key: parameter_value})

  def add_parameters(self, parameters: Mapping[Text, Union[float, Text, int]]):
    """Adds parameters to this execution.

    Args:
      parameters: A dictionary that contains multiple parameter key and value
        pair.
    """

    self.put_custom_properties(self._node, parameters)
    self._put_node_proxy(self._store, self._node, self._execution_contexts)

  def get_input_artifacts(self) -> Sequence[artifacts.Artifact]:
    """Retrieve all input artifacts associated with this Execution."""
    return self._get_bound_artifacts(
        event_type=metadata_store_pb2.Event.Type.INPUT)

  def get_output_artifacts(self) -> Sequence[artifacts.Artifact]:
    """Retrieve all output artifacts associated with this Execution."""
    return self._get_bound_artifacts(
        event_type=metadata_store_pb2.Event.Type.OUTPUT)

  def _get_bound_artifacts(
      self, event_type: metadata_store_pb2.Event.Type
  ) -> Sequence[artifacts.Artifact]:
    """Get all artifacts bound to this execution with the specified event_type.

    Args:
      event_type: Input or output event type.

    Returns:
      Sequence of artifacts that is in event_type
    """
    if self.is_managed_store():
      node_id = self.node.name
      artifact_id_key = 'artifact'
      event_type_key = 'type_'
      event_type = stores.event_type_to_managed_event_type[event_type]
    else:
      node_id = self.node_id
      event_type_key = 'type'
      artifact_id_key = 'artifact_id'



    events = self._store.get_events_by_execution_ids(
        execution_ids=[node_id])

    artifacts_ids = [
        getattr(event, artifact_id_key)
        for event in events if getattr(event, event_type_key) == event_type
    ]

    typed_artifacts = []

    for artifact in self._store.get_artifacts_by_id(artifact_ids=artifacts_ids):
      artifact_node = artifacts.initialize_artifact_from_node(
          store=self._store, node=artifact)
      if artifact_node is not None:
        typed_artifacts.append(artifact_node)

    return typed_artifacts

  @property
  def state(self):
    """Returns current execution status."""

    return self._node.last_known_state

  @property
  def contexts(self) -> Optional[Sequence[contexts.Context]]:
    """Returns current execution contexts."""
    return self._execution_contexts

  @property
  def name(self) -> str:
    """The name of this Execution assigned by MLMD."""
    return self.node.name


class NotebookExecution(Execution):
  """Notebook Execution Type.

  NotebookExecution represents an ML step that was run from a notebook.

  Attributes:
    type: MLMD type definition.
    node: MLMD node instance.
    type_id: id of type in metadata store.
    node_id: MLMD id for this node in metadata store.
    name: Notebook Execution name.
    state: State of current execution.
  """
  _type = type_utils.create_type(
      'aiplatform.NotebookExecution',
      metadata_store_pb2.ExecutionType,
      name=metadata_store_pb2.STRING,
      description=metadata_store_pb2.STRING,
      code=metadata_store_pb2.STRING)

  @classmethod
  def create(
      cls,
      store: metadata_store.MetadataStore,
      name: Optional[Text] = None,
      description: Optional[Text] = None,
      code: Optional[Text] = None,
      execution_contexts: Optional[Sequence[contexts.Context]] = None,
      custom_properties: Optional[Mapping[str, Union[int, str, float]]] = None
  ) -> 'NotebookExecution':
    """Creates NotebookExecution node object.

    Args:
      store: MLMD store to put this NotebookExecution.
      name (Optional): The name of this NotebookExecution.
      description (Optional): The description of this NotebookExecution.
      code (Optional): Serialized snapshot of the code used by the notebook.
      execution_contexts (Optional): Running context for this execution.

    Returns:
      Created NotebookExecution Node.
    """
    cls.register_type(store)
    node = cls._create_node(name, description, code, custom_properties)
    node = cls._put_node_proxy(
        store=store, node=node, execution_contexts=execution_contexts)

    return NotebookExecution(
        store=store, node=node, execution_contexts=execution_contexts)

  @classmethod
  def get(cls, store: metadata_store.MetadataStore,
          execution_id: int) -> 'NotebookExecution':
    """Get a Model Artifact from given MLMD store.

    Exacltly one of model_id or uri must be given.
    Args:
      store: MLMD store to get Experiment from.
      execution_id: MLMD id of Model to get.

    Returns:
      Model representing this instance in MLMD.
    """
    return cls._get_node(store, execution_id)  # type: ignore

  @classmethod
  def _create_node(
      cls,
      name: Optional[Text] = None,
      description: Optional[Text] = None,
      code: Optional[Text] = None,
      custom_properties: Optional[Mapping[str, Union[int, str, float]]] = None
  ) -> metadata_store_pb2.Execution:
    """Creates NotebookExecution node object.

    Args:
      name (Optional): The name of this NotebookExecution.
      description (Optional): The description of this NotebookExecution.
      code (Optional): Serialized snapshot of the code used by the notebook.

    Returns:
      Created NotebookExecution Node.
    """
    node = metadata_store_pb2.Execution()
    node.type_id = cls._type_id

    if name is not None:
      cls.put_string_property(
          node=node, property_key='name', property_value=name)

    node.last_known_state = metadata_store_pb2.Execution.State.RUNNING

    if description is not None:
      cls.put_string_property(node, 'description', description)

    if code is not None:
      cls.put_string_property(node, 'code', code)

    if custom_properties is not None:
      cls.put_custom_properties(node, custom_properties)
    return node

  @property
  def name(self) -> str:
    """The name assigned to this NotebookExecution."""
    return self.node.properties['name'].string_value


def get_executions_by_context(store: metadata_store.MetadataStore,
                              context: contexts.Context) -> Sequence[Execution]:
  """Gets Executions associated to the given Context.

  Args:
    store: MLMD store to get Executions from.
    context:  Context of interest.

  Returns:
    All the Executions associated with the given Context.
  """

  if isinstance(store, metadata_store.MetadataStore):
    context_id = context.node_id
  else:
    context_id = context.node.name
  return [
      initialize_execution_from_node(store, execution)
      for execution in store.get_executions_by_context(context_id)
  ]


def initialize_execution_from_node(
    store: metadata_store.MetadataStore,
    node: type_utils.MLMDNode) -> Optional[Execution]:
  """Initialize an Execution from MLMD Node.

  This method will use node's type to initiate a corresponding Execution
  type instance.

  Args:
    store: MLMD store.
    node: MLMD node.

  Returns:
    Returns an Execution that match the type node specified.
  """
  type_id_to_class = {cls.get_type_id(): cls for cls in [NotebookExecution]}
  execution_class = type_id_to_class.get(node.type_id)
  if execution_class:
    return execution_class(store, node)
  return execution_class
