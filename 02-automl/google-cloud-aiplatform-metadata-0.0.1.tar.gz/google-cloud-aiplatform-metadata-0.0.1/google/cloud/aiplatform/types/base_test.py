# Lint as: python3
"""Tests for google3.cloud.ai.platform.ml_metadata.client.rosalind.types.base."""

import importlib
import unittest

from ml_metadata import metadata_store
from ml_metadata.proto import metadata_store_pb2
import numpy as np
from google.cloud.aiplatform.types import base

_TEST_PROPERTIES = {
    'epochs': 123,
    'learning_rate': 1.2,
    'split_fraction': 3.40,
    'loss_function': 'mse',
    'numpy_float': np.float32(1.0)
}


class BaseTest(unittest.TestCase):
  """Tests limited methods on NodeAndType Class."""

  def setUp(self):
    super(BaseTest, self).setUp()
    importlib.reload(base)
    connection_config = metadata_store_pb2.ConnectionConfig()
    connection_config.fake_database.SetInParent()
    self.store = metadata_store.MetadataStore(connection_config)
    self.test_node = metadata_store_pb2.Artifact()

  def test_put_custom_properties(self):
    base.NodeAndType.put_custom_properties(
        node=self.test_node, properties=_TEST_PROPERTIES)

    for key, true_value in _TEST_PROPERTIES.items():
      node_value = self.test_node.custom_properties[key]
      node_value = getattr(node_value, node_value.WhichOneof('value'))
      self.assertEqual(node_value, true_value)

  def test_put_custom_properties_throw_error_with_incorrect_value_type(self):
    with self.assertRaises(ValueError):
      base.NodeAndType.put_custom_properties(
          node=self.test_node, properties={'fail_key_1': {
              'obj': True
          }})
    with self.assertRaises(ValueError):
      base.NodeAndType.put_custom_properties(
          node=self.test_node, properties={'fail_key_2': [1, 2, 'abc']})
    with self.assertRaises(ValueError):
      base.NodeAndType.put_custom_properties(
          node=self.test_node, properties={'fail_key_3': self.test_node})

    for key in ['fail_key_1', 'fail_key_2', 'fail_key_3']:
      self.assertFalse(
          self.test_node.custom_properties[key].HasField('int_value'))
      self.assertFalse(
          self.test_node.custom_properties[key].HasField('string_value'))
      self.assertFalse(
          self.test_node.custom_properties[key].HasField('double_value'))


if __name__ == '__main__':
  unittest.main()
