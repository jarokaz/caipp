"""Module to store MLMD types."""
