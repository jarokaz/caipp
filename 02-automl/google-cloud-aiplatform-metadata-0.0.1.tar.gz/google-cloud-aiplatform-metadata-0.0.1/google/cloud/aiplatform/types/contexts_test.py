# Lint as: python3
"""Tests for google3.cloud.ai.platform.ml_metadata.client.rosalind.types.contexts."""

import importlib
import unittest

from ml_metadata import metadata_store
from ml_metadata.proto import metadata_store_pb2
from google.cloud.aiplatform.types import artifacts
from google.cloud.aiplatform.types import contexts
from google.cloud.aiplatform.utils import test_utils

_EXPERIMENT_NAME = 'test_experiment'
_EXPERIMENT_NAME_2 = 'test_experiment_2'


class ExperimentContextTest(unittest.TestCase):

  def setUp(self):
    super().setUp()
    importlib.reload(contexts)
    importlib.reload(artifacts)
    connection_config = metadata_store_pb2.ConnectionConfig()
    connection_config.fake_database.SetInParent()
    self.store = metadata_store.MetadataStore(connection_config)

  def test_check_experiment_type(self):
    self.assertFalse(contexts.ExperimentContext.is_type_registered())
    contexts.ExperimentContext.register_type(self.store)
    experiment_type = contexts.ExperimentContext._type
    self.assertEqual(experiment_type.name, 'aiplatform.Experiment')
    self.assertIsInstance(experiment_type, metadata_store_pb2.ContextType)

  def test_experiment_type_and_type_id(self):
    experiment = contexts.ExperimentContext.get_or_create(
        self.store, 'test_experiment')
    self.assertEqual(experiment.type_id, 1)
    self.assertIsInstance(experiment.type, metadata_store_pb2.ContextType)

  def test_check_consistent_experiment_type_id(self):
    experiment_1 = contexts.ExperimentContext.get_or_create(
        self.store, 'test_experiment_1')
    experiment_2 = contexts.ExperimentContext.get_or_create(
        self.store, 'test_experiment_2')
    self.assertEqual(experiment_1.type_id, experiment_2.type_id)

  def test_create_and_get_experiment_by_name(self):
    experiment = contexts.ExperimentContext.get_or_create(
        self.store, 'test_experiment')
    same_experiment = contexts.ExperimentContext.get_or_create(
        self.store, name=experiment.name)

    self.assertEqual(experiment.name, same_experiment.name)
    self.assertEqual(experiment.type_id, same_experiment.type_id)
    self.assertEqual(experiment.node_id, experiment.node_id)

  def test_create_and_get_experiment_by_id(self):
    experiment = contexts.ExperimentContext.get_or_create(
        self.store, 'test_experiment')
    same_experiment = contexts.ExperimentContext.get_or_create(
        self.store, experiment_id=experiment.node_id)

    self.assertEqual(experiment.name, same_experiment.name)
    self.assertEqual(experiment.type_id, same_experiment.type_id)
    self.assertEqual(experiment.node_id, experiment.node_id)

  def test_experiment_id_not_found_in_store(self):
    with self.assertRaises(ValueError):
      contexts.ExperimentContext.get_or_create(self.store, experiment_id=1)

  def test_fail_get_experiment_with_name_and_id(self):
    with self.assertRaises(ValueError):
      contexts.ExperimentContext.get_or_create(
          self.store, name='test_environment', experiment_id=1)

  def test_fail_get_context_by_id_of_different_type(self):
    other_context_type = metadata_store_pb2.ContextType()
    other_context_type.name = 'other context type'
    other_context_type_id = self.store.put_context_type(other_context_type)

    other_context_node = metadata_store_pb2.Context()
    other_context_node.type_id = other_context_type_id
    other_context_node.name = 'other context name'
    other_context_node_id = self.store.put_contexts([other_context_node])[0]

    with self.assertRaises(ValueError):
      contexts.ExperimentContext.get_or_create(
          self.store, experiment_id=other_context_node_id)

  def test_experiment_context_attributes_artifact(self):
    artifact = artifacts.ModelArtifact.create(self.store)
    experiment = contexts.ExperimentContext.get_or_create(
        self.store, _EXPERIMENT_NAME)
    experiment.attribute_artifact(artifact)
    artifact_from_store = self.store.get_artifacts_by_context(
        experiment.node_id)[0]
    test_utils.assert_metadata_node_proto_equal(
        self,
        artifact.node,
        artifact_from_store,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_get_all_experiments(self):
    experiment_1 = contexts.ExperimentContext.get_or_create(
        self.store, _EXPERIMENT_NAME)
    experiment_2 = contexts.ExperimentContext.get_or_create(
        self.store, _EXPERIMENT_NAME_2)

    experiments_from_store = contexts.ExperimentContext.get_all(self.store)

    self.assertEqual(experiment_1, experiments_from_store[0])
    self.assertEqual(experiment_2, experiments_from_store[1])

  def test_get_as_dict_returns_dict(self):
    experiment_1 = contexts.ExperimentContext.get_or_create(
        self.store, _EXPERIMENT_NAME)
    true_dict = {'experiment_name': _EXPERIMENT_NAME, 'experiment_id': 1}

    self.assertDictEqual(experiment_1.as_dict(), true_dict)


if __name__ == '__main__':
  unittest.main()
