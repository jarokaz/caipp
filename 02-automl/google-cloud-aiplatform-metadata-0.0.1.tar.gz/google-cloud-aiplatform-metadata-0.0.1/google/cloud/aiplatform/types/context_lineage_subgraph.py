# Lint as: python3
"""MLMD Context Lineage Subgraph."""

from typing import List

from ml_metadata import metadata_store
from ml_metadata.proto import metadata_store_pb2
from google.cloud.aiplatform import stores
from google.cloud.aiplatform.types import artifacts
from google.cloud.aiplatform.types import executions


class ContextLineageSubgraph:
  """Class representing a Lineage Subgraph with MLMD type."""

  def __init__(self, store: metadata_store.MetadataStore, context_name,
               mlmd_executions, mlmd_artifacts, mlmd_events):
    self._store = store
    self._context_name = context_name
    self._mlmd_executions = mlmd_executions
    self._mlmd_artifacts = mlmd_artifacts
    self._mlmd_events = mlmd_events

  def get_executions(self) -> List[executions.Execution]:
    """Returns all the executions in Lineage Subgraph as Rosaline Execution objects.

    Returns:
      List of Rosalind Execution instances.
    """

    rosalind_executions = []
    for execution in self._mlmd_executions:
      rosalind_execution = executions.initialize_execution_from_node(
          self._store, execution)
      if rosalind_execution:
        rosalind_executions.append(rosalind_execution)

    return rosalind_executions

  def get_output_artifacts_for_execution(
      self, execution_name: str) -> List[artifacts.Artifact]:
    """Returns output artifacts as Rosalind Artifact for the specified execution in the Lineage Subgraph.

    Args:
      execution_name: Name of the Execution

    Returns:
      List of Rosalind Artifact Objects.
    """
    artifact_map = {}
    for artifact in self._mlmd_artifacts:
      artifact_map[hash(artifact.name)] = artifact

    output_artifacts = []
    for event in self._mlmd_events:
      if (event.execution_id == hash(execution_name) and
          event.type == metadata_store_pb2.Event.Type.OUTPUT):
        output_artifact = artifacts.initialize_artifact_from_node(
            self._store, artifact_map[event.artifact_id])
        if output_artifact:
          output_artifacts.append(output_artifact)

    return output_artifacts


def query_lineage_subgraph(store: stores.AiPlatformMetadataStore,
                           context_name: str) -> ContextLineageSubgraph:
  mlmd_lineage_subgraph = store.get_context_graph(context_name)
  return ContextLineageSubgraph(store, context_name,
                                mlmd_lineage_subgraph.executions,
                                mlmd_lineage_subgraph.artifacts,
                                mlmd_lineage_subgraph.events)
