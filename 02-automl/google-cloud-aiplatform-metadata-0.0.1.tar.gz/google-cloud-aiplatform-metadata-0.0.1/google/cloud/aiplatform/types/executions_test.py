# Lint as: python3
"""Tests for google3.cloud.ai.platform.ml_metadata.client.rosalind.types.executions."""

import importlib
import unittest

from ml_metadata import metadata_store
from ml_metadata.proto import metadata_store_pb2
from google.cloud.aiplatform.types import artifacts
from google.cloud.aiplatform.types import contexts
from google.cloud.aiplatform.types import executions
from google.cloud.aiplatform.utils import test_utils

_TEST_EXECUTION_NAME = 'Test_Execution'
_TEST_EXECUTION_ID = 123456
_TEST_DESCRIPTION = 'Test_Execution_Description'
_TEST_CODE = 'Test_Code'

_TEST_INPUT_MODEL_NAME = 'Test_Input_Model'
_TEST_OUTPUT_MODEL_NAME = 'Test_Output_Model'

_TEST_DATA_KEY = 'data'
_TEST_SCHEMA_KEY = 'schema'

_TEST_PARAMETERS = {
    'epochs': 123,
    'learning_rate': 1.2,
    'split_fraction': 3.40,
    'loss_function': 'mse',
}


class ExecutionsTest(unittest.TestCase):

  def setUp(self):
    super(ExecutionsTest, self).setUp()
    importlib.reload(executions)
    importlib.reload(artifacts)
    importlib.reload(contexts)
    connection_config = metadata_store_pb2.ConnectionConfig()
    connection_config.fake_database.SetInParent()
    self.store = metadata_store.MetadataStore(connection_config)

  def test_execution_with_single_artifact(self):
    input_artifact = artifacts.ModelArtifact.create(self.store,
                                                    _TEST_INPUT_MODEL_NAME)
    output_artifact = artifacts.ModelArtifact.create(self.store,
                                                     _TEST_OUTPUT_MODEL_NAME)

    execution = executions.NotebookExecution.create(self.store,
                                                    _TEST_EXECUTION_NAME,
                                                    _TEST_DESCRIPTION,
                                                    _TEST_CODE)
    self.assertEqual(execution.state,
                     metadata_store_pb2.Execution.State.RUNNING)
    stored_execution = self.store.get_executions_by_id([execution.node_id])[0]
    self.assertEqual(stored_execution.last_known_state,
                     execution.state)

    execution.add_input(input_artifact)
    execution.add_output(output_artifact)
    execution.update_state_complete()

    [input_event, output_event] = self.store.get_events_by_artifact_ids(
        [input_artifact.node_id, output_artifact.node_id])

    self.assertEqual(input_event.type, metadata_store_pb2.Event.Type.INPUT)
    self.assertEqual(input_event.execution_id, execution.node_id)

    self.assertEqual(output_event.type, metadata_store_pb2.Event.Type.OUTPUT)
    self.assertEqual(output_event.execution_id, execution.node_id)

    self.assertEqual(execution.state,
                     metadata_store_pb2.Execution.State.COMPLETE)
    stored_execution = self.store.get_executions_by_id([execution.node_id])[0]
    self.assertEqual(stored_execution.last_known_state,
                     execution.state)
    test_utils.assert_metadata_node_proto_equal(
        self,
        execution._node,
        stored_execution,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_execution_with_multiple_artifacts(self):
    input_artifact_1 = artifacts.ModelArtifact.create(
        self.store, _TEST_INPUT_MODEL_NAME + '1')
    input_artifact_2 = artifacts.ModelArtifact.create(
        self.store, _TEST_INPUT_MODEL_NAME + '2')
    output_artifact_1 = artifacts.ModelArtifact.create(
        self.store, _TEST_OUTPUT_MODEL_NAME + '1')
    output_artifact_2 = artifacts.ModelArtifact.create(
        self.store, _TEST_OUTPUT_MODEL_NAME + '2')

    execution = executions.NotebookExecution.create(self.store,
                                                    _TEST_EXECUTION_NAME,
                                                    _TEST_DESCRIPTION,
                                                    _TEST_CODE)
    self.assertEqual(execution.state,
                     metadata_store_pb2.Execution.State.RUNNING)
    stored_execution = self.store.get_executions_by_id([execution.node_id])[0]
    self.assertEqual(stored_execution.last_known_state,
                     execution.state)

    execution.add_input([input_artifact_1, input_artifact_2])
    execution.add_output([output_artifact_1, output_artifact_2])
    execution.update_state_complete()

    [input_event_1, input_event_2] = self.store.get_events_by_artifact_ids(
        [input_artifact_1.node_id, input_artifact_2.node_id])

    for input_event in [input_event_1, input_event_2]:
      self.assertEqual(input_event.type, metadata_store_pb2.Event.Type.INPUT)
      self.assertEqual(input_event.execution_id, execution.node_id)

    [output_event_1, output_event_2] = self.store.get_events_by_artifact_ids(
        [output_artifact_1.node_id, output_artifact_2.node_id])

    for output_event in [output_event_1, output_event_2]:
      self.assertEqual(output_event.type, metadata_store_pb2.Event.Type.OUTPUT)
      self.assertEqual(output_event.execution_id, execution.node_id)

      self.assertEqual(execution.state,
                       metadata_store_pb2.Execution.State.COMPLETE)

    stored_execution = self.store.get_executions_by_id([execution.node_id])[0]
    self.assertEqual(stored_execution.last_known_state,
                     execution.state)
    test_utils.assert_metadata_node_proto_equal(
        self,
        execution._node,
        stored_execution,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_update_state_complete_method(self):
    """This suite tests the update_state_complete method."""
    execution = executions.NotebookExecution.create(self.store,
                                                    _TEST_EXECUTION_NAME)
    execution.update_state_complete()

    stored_execution = self.store.get_executions_by_id([execution.node_id])[0]
    self.assertEqual(stored_execution.last_known_state,
                     execution.state)
    self.assertEqual(stored_execution.last_known_state,
                     metadata_store_pb2.Execution.State.COMPLETE)

  def test_update_failed_method(self):
    """This suite tests the update_state_failed method."""
    execution = executions.NotebookExecution.create(self.store,
                                                    _TEST_EXECUTION_NAME)

    execution.update_state_failed()
    stored_execution = self.store.get_executions_by_id([execution.node_id])[0]
    self.assertEqual(stored_execution.last_known_state,
                     execution.state)
    self.assertEqual(stored_execution.last_known_state,
                     metadata_store_pb2.Execution.State.FAILED)

  def test_change_state_from_complete_to_failed_throws_failure(self):
    """This suite tests the change execution state from complete to failed."""
    execution = executions.NotebookExecution.create(self.store,
                                                    _TEST_EXECUTION_NAME)

    execution.update_state_complete()

    with self.assertRaises(ValueError):
      execution.update_state_failed()

  def test_change_state_from_failed_to_complete_throws_failure(self):
    """This suite tests the change execution state from complete to failed."""
    execution = executions.NotebookExecution.create(self.store,
                                                    _TEST_EXECUTION_NAME)

    execution.update_state_failed()

    with self.assertRaises(ValueError):
      execution.update_state_complete()

  def test_change_state_from_failed_to_failed(self):
    """This suite tests the change execution state from failed to failed."""
    execution = executions.NotebookExecution.create(self.store,
                                                    _TEST_EXECUTION_NAME)

    execution.update_state_failed()
    execution.update_state_failed()

  def test_change_state_from_complete_to_complete(self):
    """This suite tests the change execution state from complete to complete."""
    execution = executions.NotebookExecution.create(self.store,
                                                    _TEST_EXECUTION_NAME)

    execution.update_state_complete()
    execution.update_state_complete()

  def test_execution_with_steps(self):
    """This method test execution with steps.

     Example:
     my_execution.add_input({"data":[3,7],"schema":8})
     my_execution.add_output({"data":[3,7],"schema":8})

     Where 3, 7, and 8 are artifact_ids, assuming execution_id of my_execution
     is 12, input events are:
      {
         artifact_id:3,
         execution_id: 12,
         type:INPUT,
         path:{step:[{"key":"data"},{"index":0}]}
      }
      {
         artifact_id:7,
         execution_id: 12,
         type:INPUT,
         path:{step:[{"key":"data"},{"index":1}]}
      }
      {
         artifact_id:8,
         execution_id: 12,
         type:INPUT,
         path:{step:[{"key":"schema"}]}
      }
    """
    input_artifact_1 = artifacts.ModelArtifact.create(
        self.store, _TEST_INPUT_MODEL_NAME + '1')
    input_artifact_2 = artifacts.ModelArtifact.create(
        self.store, _TEST_INPUT_MODEL_NAME + '2')
    input_artifact_3 = artifacts.ModelArtifact.create(
        self.store, _TEST_INPUT_MODEL_NAME + '3')
    output_artifact_1 = artifacts.ModelArtifact.create(
        self.store, _TEST_OUTPUT_MODEL_NAME + '1')
    output_artifact_2 = artifacts.ModelArtifact.create(
        self.store, _TEST_OUTPUT_MODEL_NAME + '2')
    output_artifact_3 = artifacts.ModelArtifact.create(
        self.store, _TEST_OUTPUT_MODEL_NAME + '3')

    execution = executions.NotebookExecution.create(self.store,
                                                    _TEST_EXECUTION_NAME,
                                                    _TEST_DESCRIPTION,
                                                    _TEST_CODE)
    self.assertEqual(execution.state,
                     metadata_store_pb2.Execution.State.RUNNING)
    stored_execution = self.store.get_executions_by_id([execution.node_id])[0]
    self.assertEqual(stored_execution.last_known_state,
                     execution.state)

    execution.add_input({
        _TEST_DATA_KEY: [input_artifact_1, input_artifact_2],
        _TEST_SCHEMA_KEY: input_artifact_3
    })
    execution.add_output({
        _TEST_DATA_KEY: output_artifact_1,
        _TEST_SCHEMA_KEY: [output_artifact_2, output_artifact_3]
    })
    execution.update_state_complete()

    [input_event_1, input_event_2,
     input_event_3] = self.store.get_events_by_artifact_ids([
         input_artifact_1.node_id, input_artifact_2.node_id,
         input_artifact_3.node_id
     ])

    for index, input_event in enumerate([input_event_1, input_event_2]):
      self.assertEqual(input_event.type, metadata_store_pb2.Event.Type.INPUT)
      self.assertEqual(input_event.execution_id, execution.node_id)
      self.assertEqual(input_event.path.steps[0].key, _TEST_DATA_KEY)
      self.assertEqual(input_event.path.steps[1].index, index)

    self.assertEqual(input_event_3.path.steps[0].key, _TEST_SCHEMA_KEY)
    self.assertEqual(len(input_event_3.path.steps), 1)

    [output_event_1, output_event_2,
     output_event_3] = self.store.get_events_by_artifact_ids([
         output_artifact_1.node_id, output_artifact_2.node_id,
         output_artifact_3.node_id
     ])

    for index, output_event in enumerate([output_event_2, output_event_3]):
      self.assertEqual(output_event.type, metadata_store_pb2.Event.Type.OUTPUT)
      self.assertEqual(output_event.execution_id, execution.node_id)
      self.assertEqual(output_event.path.steps[0].key, _TEST_SCHEMA_KEY)
      self.assertEqual(output_event.path.steps[1].index, index)

    self.assertEqual(output_event_1.path.steps[0].key, _TEST_DATA_KEY)
    self.assertEqual(len(input_event_3.path.steps), 1)

    self.assertEqual(execution.state,
                     metadata_store_pb2.Execution.State.COMPLETE)

    stored_execution = self.store.get_executions_by_id([execution.node_id])[0]
    self.assertEqual(stored_execution.last_known_state,
                     execution.state)
    test_utils.assert_metadata_node_proto_equal(
        self,
        execution._node,
        stored_execution,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_add_parameters_method(self):
    execution = executions.NotebookExecution.create(self.store,
                                                    _TEST_EXECUTION_NAME)

    execution.add_parameters(_TEST_PARAMETERS)

    stored_execution = executions.NotebookExecution.get(self.store,
                                                        execution.node_id)

    self.assertEqual(
        execution._node.custom_properties['learning_rate'].double_value,
        _TEST_PARAMETERS['learning_rate'])
    self.assertEqual(
        execution._node.custom_properties['split_fraction'].double_value,
        _TEST_PARAMETERS['split_fraction'])
    self.assertEqual(
        execution._node.custom_properties['loss_function'].string_value,
        _TEST_PARAMETERS['loss_function'])

    test_utils.assert_metadata_node_proto_equal(
        self,
        execution._node,
        stored_execution._node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_add_parameter_method(self):
    execution = executions.NotebookExecution.create(self.store,
                                                    _TEST_EXECUTION_NAME)

    execution.add_parameter('test_key_str', 'test_value')
    execution.add_parameter('test_key_int', 123)
    execution.add_parameter('test_key_double', 1.23)

    stored_execution = executions.NotebookExecution.get(self.store,
                                                        execution.node_id)
    self.assertEqual(
        execution._node.custom_properties['test_key_str'].string_value,
        'test_value')
    self.assertEqual(
        execution._node.custom_properties['test_key_int'].int_value, 123)
    self.assertEqual(
        execution._node.custom_properties['test_key_double'].double_value, 1.23)

    test_utils.assert_metadata_node_proto_equal(
        self,
        execution._node,
        stored_execution._node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_add_parameter_method_throws_error_for_invalid_value_type(self):
    execution = executions.NotebookExecution.create(self.store,
                                                    _TEST_EXECUTION_NAME)

    with self.assertRaises(ValueError):
      execution.add_parameter('fail_key_1', {'obj': True})
    with self.assertRaises(ValueError):
      execution.add_parameter('fail_key_2', ['abc', 123])
    with self.assertRaises(ValueError):
      execution.add_parameter('fail_key_3', self.store)

    stored_execution = executions.NotebookExecution.get(self.store,
                                                        execution.node_id)
    test_utils.assert_metadata_node_proto_equal(
        self,
        execution._node,
        stored_execution._node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

    for key in ['fail_key_1', 'fail_key_2', 'fail_key_3']:
      self.assertFalse(
          execution._node.custom_properties[key].HasField('int_value'))
      self.assertFalse(
          execution._node.custom_properties[key].HasField('string_value'))
      self.assertFalse(
          execution._node.custom_properties[key].HasField('double_value'))

  def test_add_parameters_method_throws_error_for_invalid_value_type(self):
    execution = executions.NotebookExecution.create(self.store,
                                                    _TEST_EXECUTION_NAME)

    with self.assertRaises(ValueError):
      execution.add_parameters({'fail_key_1': {'obj': True}})
    with self.assertRaises(ValueError):
      execution.add_parameters({'fail_key_2': ['abc', 123]})
    with self.assertRaises(ValueError):
      execution.add_parameters({'fail_key_3': self.store})

    stored_execution = executions.NotebookExecution.get(self.store,
                                                        execution.node_id)
    test_utils.assert_metadata_node_proto_equal(
        self,
        execution._node,
        stored_execution._node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

    for key in ['fail_key_1', 'fail_key_2', 'fail_key_3']:
      self.assertFalse(
          execution._node.custom_properties[key].HasField('int_value'))
      self.assertFalse(
          execution._node.custom_properties[key].HasField('string_value'))
      self.assertFalse(
          execution._node.custom_properties[key].HasField('double_value'))

  def test_get_input_output_artifacts(self):
    input_artifact_1 = artifacts.MetricArtifact.create(
        self.store, _TEST_INPUT_MODEL_NAME + '1')
    input_artifact_2 = artifacts.ModelArtifact.create(
        self.store, _TEST_INPUT_MODEL_NAME + '2')
    input_artifact_3 = artifacts.DatasetArtifact.create(
        self.store, _TEST_INPUT_MODEL_NAME + '3')
    output_artifact_1 = artifacts.ModelArtifact.create(
        self.store, _TEST_OUTPUT_MODEL_NAME + '1')
    output_artifact_2 = artifacts.MetricArtifact.create(
        self.store, _TEST_OUTPUT_MODEL_NAME + '2')
    output_artifact_3 = artifacts.DatasetArtifact.create(
        self.store, _TEST_OUTPUT_MODEL_NAME + '3')
    execution = executions.NotebookExecution.create(self.store,
                                                    _TEST_EXECUTION_NAME,
                                                    _TEST_DESCRIPTION,
                                                    _TEST_CODE)
    execution.add_input({
        _TEST_DATA_KEY: [input_artifact_1, input_artifact_2],
        _TEST_SCHEMA_KEY: input_artifact_3
    })
    execution.add_output({
        _TEST_DATA_KEY: output_artifact_1,
        _TEST_SCHEMA_KEY: [output_artifact_2, output_artifact_3]
    })
    execution = executions.NotebookExecution.get(
        store=self.store, execution_id=execution.node_id)

    input_artifacts = execution.get_input_artifacts()
    self.assertEqual(len(input_artifacts), 3)
    for artifact in [input_artifact_1, input_artifact_2, input_artifact_3]:
      for input_artifact in input_artifacts:
        if input_artifact.node_id == artifact.node_id:
          stored_artifact = input_artifact
          break

      self.assertIsNotNone(stored_artifact)
      test_utils.assert_metadata_node_proto_equal(
          self,
          artifact._node,
          stored_artifact._node,
          ignored_fields=[
              'uri', 'create_time_since_epoch', 'last_update_time_since_epoch'
          ])

    output_artifacts = execution.get_output_artifacts()
    self.assertEqual(len(output_artifacts), 3)
    for artifact in [output_artifact_1, output_artifact_2, output_artifact_3]:
      stored_artifact = list(
          filter(lambda x: x.node_id == artifact.node_id, output_artifacts))[0]
      self.assertIsNotNone(stored_artifact)
      test_utils.assert_metadata_node_proto_equal(
          self,
          artifact._node,
          stored_artifact._node,
          ignored_fields=[
              'uri', 'create_time_since_epoch', 'last_update_time_since_epoch'
          ])

  def test_execution_with_context_can_be_retrieved_by_context(self):
    experiment = contexts.ExperimentContext.get_or_create(
        self.store, 'test_experiment')

    execution = executions.NotebookExecution.create(
        self.store,
        name=_TEST_EXECUTION_NAME,
        description=_TEST_DESCRIPTION,
        code=_TEST_CODE,
        execution_contexts=[experiment])
    stored_execution = executions.get_executions_by_context(
        self.store, experiment)
    test_utils.assert_metadata_node_proto_equal(
        self,
        execution.node,
        stored_execution[0].node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])


if __name__ == '__main__':
  unittest.main()
