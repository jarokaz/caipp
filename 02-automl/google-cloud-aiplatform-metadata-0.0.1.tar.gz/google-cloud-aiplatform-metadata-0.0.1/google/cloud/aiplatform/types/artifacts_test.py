# Lint as: python3
"""Tests for google3.cloud.ai.platform.ml_metadata.client.rosalind.types.artifacts."""

import importlib
import unittest
from unittest import mock

from ml_metadata import metadata_store
from ml_metadata.proto import metadata_store_pb2
from google.cloud.aiplatform.types import artifacts
from google.cloud.aiplatform.utils import test_utils

# from google3.net.proto2.contrib.pyutil import compare

_TEST_MODEL_NAME = 'Test_Model'
_TEST_MODEL_URI = 'https://test-model.foo-website.com'
_TEST_FRAMEWORK = 'Test_Framework'
_TEST_FRAMEWORK_VERSION = 'Test__TEST_FRAMEWORK_VERSION'
_TEST_METRIC_NAME = 'Test_METRIC'
_TEST_METRIC_URI = _TEST_MODEL_URI
_TEST_METRIC_TYPE = 'TEST_PAYLOAD'
_TEST_ACCURACY = 0.3
_TEST_PRECISION = 0.151
_TEST_RECALL = 0.123
_TEST_ENVIRONMENT = 'Training'
_TEST_CONTAINER_FORMAT = 'TFRecord'
_TEST_PAYLOAD_FORMAT = 'JSON'
_TEST_DATASET_NAME = 'Test_DataSet'
_TEST_DATASET_URI = 'https://test-dataset.foo-website.com'
_TEST_ARTIFACT_NAME = 'Test_Artifact'
_TEST_ARTIFACT_URI = 'https://test-artifact.foo-website.com'


class ArtifactsTest(unittest.TestCase):

  def setUp(self):
    super(ArtifactsTest, self).setUp()
    importlib.reload(artifacts)
    connection_config = metadata_store_pb2.ConnectionConfig()
    connection_config.fake_database.SetInParent()
    self.store = metadata_store.MetadataStore(connection_config)

  def test_consistent_type_id(self):
    model1 = artifacts.ModelArtifact.create(self.store, _TEST_MODEL_NAME,
                                            _TEST_MODEL_URI)
    model2 = artifacts.ModelArtifact.create(self.store, _TEST_MODEL_NAME + '1',
                                            _TEST_MODEL_URI)

    self.assertEqual(model1._type_id, model2._type_id)

  def test_create_new_model_will_update_database(self):
    model = artifacts.ModelArtifact.create(self.store, _TEST_MODEL_NAME,
                                           _TEST_MODEL_URI, _TEST_FRAMEWORK,
                                           _TEST_FRAMEWORK_VERSION)

    self.assertEqual(model.type.name, 'aiplatform.Model')
    self.assertIsInstance(model.type, metadata_store_pb2.ArtifactType)
    stored_artifact = self.store.get_artifacts_by_id([model.node_id])[0]
    self.assertEqual(stored_artifact.type_id, model._type_id)
    self.assertEqual(stored_artifact.uri, _TEST_MODEL_URI)
    self.assertEqual(stored_artifact.properties['framework'].string_value,
                     _TEST_FRAMEWORK)
    self.assertEqual(
        stored_artifact.properties['framework_version'].string_value,
        _TEST_FRAMEWORK_VERSION)

  def test_get_model_by_id(self):
    created_model = artifacts.ModelArtifact.create(self.store, _TEST_MODEL_NAME,
                                                   _TEST_MODEL_URI,
                                                   _TEST_FRAMEWORK,
                                                   _TEST_FRAMEWORK_VERSION)

    model = artifacts.ModelArtifact.get(self.store, created_model.node_id)

    self.assertEqual(model.type.name, 'aiplatform.Model')
    self.assertIsInstance(model.type, metadata_store_pb2.ArtifactType)
    stored_artifact = self.store.get_artifacts_by_id([model._node.id])[0]
    test_utils.assert_metadata_node_proto_equal(self, model._node,
                                                stored_artifact)

  def test_model_id_not_found_in_store(self):
    with self.assertRaises(ValueError):
      artifacts.ModelArtifact.get(self.store, 1)

  def test_fail_get_artifact_by_id_of_different_type(self):
    other_artifact_type = metadata_store_pb2.ArtifactType()
    other_artifact_type.name = 'other artifact type'
    other_artifact_type_id = self.store.put_artifact_type(other_artifact_type)

    other_artifact_node = metadata_store_pb2.Artifact()
    other_artifact_node.type_id = other_artifact_type_id
    other_artifact_node.name = 'other context name'
    other_artifact_node_id = self.store.put_artifacts([other_artifact_node])[0]

    with self.assertRaises(ValueError):
      artifacts.ModelArtifact.get(self.store, other_artifact_node_id)

  def test_create_metric_method(self):
    created_metric = artifacts.MetricArtifact.create(
        self.store,
        name=_TEST_METRIC_NAME,
        uri=_TEST_METRIC_URI,
        metric_type=_TEST_METRIC_TYPE,
        properties={
            'accuracy': _TEST_ACCURACY,
            'precision': _TEST_PRECISION,
            'recall': _TEST_RECALL
        })

    test_utils.assert_metadata_node_proto_equal(
        self,
        created_metric._node,
        artifacts.MetricArtifact.get(self.store, created_metric.node_id)._node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_create_metric_method_with_optional_input(self):
    created_metric = artifacts.MetricArtifact.create(
        self.store, name=_TEST_METRIC_NAME, uri=_TEST_METRIC_URI)

    test_utils.assert_metadata_node_proto_equal(
        self,
        created_metric._node,
        artifacts.MetricArtifact.get(
            self.store, metric_id=created_metric.node_id)._node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_create_metric_method_with_ignore_metric_type_without_uri(self):
    created_metric = artifacts.MetricArtifact.create(
        self.store, name=_TEST_METRIC_NAME, metric_type=_TEST_METRIC_TYPE)

    stored_metric = artifacts.MetricArtifact.get(
        self.store, metric_id=created_metric.node_id)

    self.assertEqual(stored_metric.metric_type, _TEST_METRIC_TYPE)

    test_utils.assert_metadata_node_proto_equal(
        self,
        created_metric.node,
        stored_metric.node,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

    self.assertEqual(len(stored_metric.node.uri), 0)

  def test_create_new_dataset_will_update_database(self):
    dataset = artifacts.DatasetArtifact.create(
        self.store,
        name=_TEST_DATASET_NAME,
        uri=_TEST_DATASET_URI,
        environment=_TEST_ENVIRONMENT,
        payload_format=_TEST_PAYLOAD_FORMAT,
        container_format=_TEST_CONTAINER_FORMAT)

    self.assertEqual(dataset.type.name, 'aiplatform.Dataset')
    self.assertIsInstance(dataset.type, metadata_store_pb2.ArtifactType)
    stored_artifact = self.store.get_artifacts_by_id([dataset.node_id])[0]
    self.assertEqual(stored_artifact.type_id, dataset._type_id)
    self.assertEqual(stored_artifact.uri, _TEST_DATASET_URI)
    self.assertEqual(stored_artifact.properties['environment'].string_value,
                     _TEST_ENVIRONMENT)
    self.assertEqual(stored_artifact.properties['payload_format'].string_value,
                     _TEST_PAYLOAD_FORMAT)
    self.assertEqual(
        stored_artifact.properties['container_format'].string_value,
        _TEST_CONTAINER_FORMAT)
    test_utils.assert_metadata_node_proto_equal(
        self,
        dataset._node,
        stored_artifact,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_get_dataset_by_id(self):
    created_dataset = artifacts.DatasetArtifact.create(
        self.store,
        name=_TEST_DATASET_NAME,
        uri=_TEST_DATASET_URI,
        environment=_TEST_ENVIRONMENT,
        payload_format=_TEST_PAYLOAD_FORMAT,
        container_format=_TEST_CONTAINER_FORMAT)

    dataset = artifacts.DatasetArtifact.get(self.store, created_dataset.node_id)

    self.assertEqual(dataset.type.name, 'aiplatform.Dataset')
    self.assertIsInstance(dataset.type, metadata_store_pb2.ArtifactType)
    stored_artifact = self.store.get_artifacts_by_id([created_dataset._node.id
                                                     ])[0]
    test_utils.assert_metadata_node_proto_equal(self, dataset._node,
                                                stored_artifact)

  def test_dataset_id_not_found_in_store(self):
    with self.assertRaises(ValueError):
      artifacts.DatasetArtifact.get(self.store, 1)

  def test_create_new_artifact_will_update_database(self):
    artifact = artifacts.GenericArtifact.create(
        self.store, name=_TEST_ARTIFACT_NAME, uri=_TEST_ARTIFACT_URI)

    self.assertEqual(artifact.type.name, 'aiplatform.GenericArtifact')
    self.assertIsInstance(artifact.type, metadata_store_pb2.ArtifactType)
    stored_artifact = self.store.get_artifacts_by_id([artifact.node_id])[0]
    self.assertEqual(stored_artifact.type_id, artifact._type_id)
    self.assertEqual(stored_artifact.uri, _TEST_ARTIFACT_URI)

    test_utils.assert_metadata_node_proto_equal(
        self,
        artifact._node,
        stored_artifact,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_get_artifact_by_id(self):
    created_artifact = artifacts.GenericArtifact.create(
        self.store, name=_TEST_ARTIFACT_NAME, uri=_TEST_ARTIFACT_URI)

    artifact = artifacts.GenericArtifact.get(self.store,
                                             created_artifact.node_id)

    self.assertEqual(artifact.type.name, 'aiplatform.GenericArtifact')
    self.assertIsInstance(artifact.type, metadata_store_pb2.ArtifactType)
    stored_artifact = self.store.get_artifacts_by_id(
        [created_artifact._node.id])[0]
    test_utils.assert_metadata_node_proto_equal(
        self,
        created_artifact._node,
        stored_artifact,
        ignored_fields=[
            'create_time_since_epoch', 'last_update_time_since_epoch'
        ])

  def test_artifact_id_not_found_in_store(self):
    with self.assertRaises(ValueError):
      artifacts.GenericArtifact.get(self.store, 1)

  def test_initialize_artifact_from_node(self):
    model = artifacts.ModelArtifact.create(
        self.store,
        name=_TEST_MODEL_NAME,
        uri=_TEST_MODEL_URI,
        framework=_TEST_FRAMEWORK,
        framework_version=_TEST_FRAMEWORK_VERSION)

    metric = artifacts.MetricArtifact.create(
        self.store, name=_TEST_METRIC_NAME, metric_type=_TEST_METRIC_TYPE)

    dataset = artifacts.DatasetArtifact.create(
        self.store,
        name=_TEST_DATASET_NAME,
        uri=_TEST_DATASET_URI,
        environment=_TEST_ENVIRONMENT,
        payload_format=_TEST_PAYLOAD_FORMAT,
        container_format=_TEST_CONTAINER_FORMAT)

    for artifact in [model, metric, dataset]:
      created_artifact = artifacts.initialize_artifact_from_node(
          store=self.store, node=artifact.node)

      self.assertIsInstance(created_artifact, artifact.__class__)
      test_utils.assert_metadata_node_proto_equal(self, artifact.node,
                                                  created_artifact.node)

  def test_dataset_bind_object_updates_object_to_metadata_map(self):
    created_dataset = artifacts.DatasetArtifact.create(
        self.store,
        name=_TEST_DATASET_NAME,
        uri=_TEST_DATASET_URI,
        environment=_TEST_ENVIRONMENT,
        payload_format=_TEST_PAYLOAD_FORMAT,
        container_format=_TEST_CONTAINER_FORMAT)

    mock_dataset = mock.Mock()

    created_dataset.bind_object(mock_dataset)

    self.assertIn(mock_dataset, artifacts.OBJECT_ID_TO_ARTIFACT_MAP)
    test_utils.assert_metadata_node_proto_equal(
        self,
        created_dataset.node,
        artifacts.OBJECT_ID_TO_ARTIFACT_MAP[mock_dataset].node)

  def test_model_bind_object_updates_object_to_metadata_map(self):
    created_model = artifacts.ModelArtifact.create(
        store=self.store, name=_TEST_MODEL_NAME)

    mock_model = mock.Mock()

    created_model.bind_object(mock_model)

    self.assertIn(mock_model, artifacts.OBJECT_ID_TO_ARTIFACT_MAP)
    test_utils.assert_metadata_node_proto_equal(
        self,
        created_model.node,
        artifacts.OBJECT_ID_TO_ARTIFACT_MAP[mock_model].node)

  def test_generic_artifact_bind_object_updates_object_to_metadata_map(self):
    created_artifact = artifacts.GenericArtifact.create(
        self.store, name=_TEST_ARTIFACT_NAME, uri=_TEST_ARTIFACT_URI)

    mock_artifact = mock.Mock()

    created_artifact.bind_object(mock_artifact)

    self.assertIn(mock_artifact, artifacts.OBJECT_ID_TO_ARTIFACT_MAP)
    test_utils.assert_metadata_node_proto_equal(
        self,
        created_artifact.node,
        artifacts.OBJECT_ID_TO_ARTIFACT_MAP[mock_artifact].node)


class ArtifactPythonIdToMetadataMapTest(unittest.TestCase):

  def setUp(self):
    super().setUp()
    importlib.reload(artifacts)
    connection_config = metadata_store_pb2.ConnectionConfig()
    connection_config.fake_database.SetInParent()
    self.store = metadata_store.MetadataStore(connection_config)

  def test_can_get_previously_inserted_artifact(self):
    test_model = mock.Mock()
    test_model_artifact = artifacts.ModelArtifact.create(
        store=self.store, name=_TEST_MODEL_NAME)
    artifacts.OBJECT_ID_TO_ARTIFACT_MAP[test_model] = test_model_artifact

    test_utils.assert_metadata_node_proto_equal(
        self, test_model_artifact._node,
        artifacts.OBJECT_ID_TO_ARTIFACT_MAP[test_model]._node)

  def test_contains_previously_inserted_artifact(self):
    test_model = mock.Mock()
    test_model_artifact = artifacts.ModelArtifact.create(
        store=self.store, name=_TEST_MODEL_NAME)
    artifacts.OBJECT_ID_TO_ARTIFACT_MAP[test_model] = test_model_artifact

    self.assertIn(test_model, artifacts.OBJECT_ID_TO_ARTIFACT_MAP)

  def test_fails_on_no_artifact_metadata_value(self):
    test_model = mock.Mock()
    test_model_artifact = mock.Mock()

    with self.assertRaises(ValueError):
      artifacts.OBJECT_ID_TO_ARTIFACT_MAP[test_model] = test_model_artifact

  def test_fails_on_get_with_uninserted_object(self):
    test_model = mock.Mock()
    with self.assertRaises(KeyError):
      artifacts.OBJECT_ID_TO_ARTIFACT_MAP[test_model]  # pylint: disable=pointless-statement


if __name__ == '__main__':
  unittest.main()
