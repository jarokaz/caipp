# Lint as: python3
"""ABC implementation of MLMD Node and Type.

The NodeAndType class represents an MLMD Type and a Node of that type.
The MLMD Type and Type id are class attributes. Functionality related to the
MLMD Type are captured as class methods. This includes registerting the type,
creating a node of the type, putting a node of the type, and get node of the
type. An instance of the NodeAndType class represents the MLMD Node which is an
instance of the class MLMD Type. Functionality related to the MLMD node are
captured as instance methods. This could include updating the node and building
the graph with respect to the node.

This design was chosen for the following reasons:

One use case is registering the types up front when a user connects to an MLMD
store before they start setting an experiment and logging or getting nodes. This
lets the user know if there are type conflicts against their store before
starting their work and logging.

We also want to separate the initialization of a new node instance from
initialization of an node instance from the store. This is captured in the get
and create methods in the Experiments subclass. If we handled this in the
constructor, the logic to determine if a node is from a store or a node that
should be put in the store is not clear for Execution and Artifact types without
passing in an additional arguments or moving the initialization outside of the
class.

Along those same lines, all logic that's relevant to the type and putting or
getting a node from a store are classmethods. Once the instance is created all
instance methods will relate to updating the node or building the graph with
respect to that node. For example, the Context type will be updated with methods
like "attribute_artifact" and "associate_execution" that will use self._store.

An alternative option is pulling these class methods outside of the class. This
is a design we'll revisit as the library matures.
"""

import abc
import threading
from typing import Mapping, Optional, Union

from ml_metadata import metadata_store
import numpy as np
from google.cloud.aiplatform import stores
from google.cloud.aiplatform.utils import type_utils


class NodeAndType(metaclass=abc.ABCMeta):
  """Abstract class representing MLMD type and node instance.

  MLMD type and type_id are stored as class attributes. It is assumed this
  module will be used against one and only one MLMD store.

  Attributes:
    type: MLMD type definition
    type_id: id of type in metadata store
    node: MLMD node instance
    node_id: MLMD id for this node in metadata store
    name: MLMD node's name
  """
  _type_id: Optional[int] = None
  _register_type_lock = threading.Lock()

  def __init__(self, store: metadata_store.MetadataStore,
               node: type_utils.MLMDNode):
    """Intializes this MLMD type and node.

    Args:
      store: MLMD store for this type and node.
      node: MLMD node definition for the type and node.
    """
    self._store = store
    self._node = node

  def is_managed_store(self) -> bool:
    """Returns True if this node is stored in Ai Platform Metadata."""
    return isinstance(self._store, stores.AiPlatformMetadataStore)

  @classmethod
  def is_type_registered(cls) -> bool:
    """Checks if type has been registered.

    Returns:
      True if this MLMD type has been registered.
    """
    with cls._register_type_lock:
      return cls._type_id is not None

  @classmethod
  def register_type(cls, store: metadata_store.MetadataStore) -> Optional[int]:
    """Registers this type with MLMD store.

    Args:
      store: MLMD store to register this classes MLMD type.

    Returns:
      The MLMD type id for this MLMD type in the given MLMD store.
    """
    with cls._register_type_lock:
      if cls._type_id is None:
        cls._type_id: int = cls._put_type(store)
        return cls._type_id
    return None

  @classmethod
  @abc.abstractmethod
  def _put_node(cls, store: metadata_store.MetadataStore,
                node: type_utils.MLMDNode) -> int:
    """Puts the node of this type in this metadata store.

    Args:
      store: MLMD store to put the MLMD node.
      node: MLMD node definition.

    Returns:
      MLMD node if for this node.
    """
    pass  # pytype:disable=bad-return-type

  @classmethod
  def _put_node_proxy(cls, store: Union[metadata_store.MetadataStore,
                                        stores.AiPlatformMetadataStore],
                      node: type_utils.MLMDNode) -> type_utils.MLMDNode:
    """Put node proxy.

    If managed store puts node and assign returned id to name.

    Args:
      store: A Metadata store.
      node: intance of the node to put.
    Returns:
      Put node with id and name updated.
    """
    if isinstance(store, metadata_store.MetadataStore):
      node.id = cls._put_node(store, node)
    else:
      node.name = cls._put_node(store, node)  # resource name
      node.id = hash(node.name)
    return node

  def update_node(self):
    """Update current node in metadata store."""
    self._put_node(store=self._store, node=self.node)  # pytype:disable=bad-return-type

  @classmethod
  @abc.abstractmethod
  def _put_type(cls, store=metadata_store.MetadataStore) -> int:
    """Puts this type in the metadata store.

    Args:
      store: MLMD store to put this type.

    Returns:
      MLMD type id for this type in the given store.
    """  # pytype: disable=bad-return-type
    pass  # pytype: disable=bad-return-type

  @classmethod
  @abc.abstractmethod
  def _create_node(cls) -> type_utils.MLMDNode:
    """Creates a node definition for this Type.

    Returns:
      MLMD node definition.
    """  # pytype: disable=bad-return-type
    pass  # pytype: disable=bad-return-type

  @classmethod
  @abc.abstractmethod
  def _get_node_by_id(cls, store: metadata_store.MetadataStore,
                      node_id: Union[int, str]) -> type_utils.MLMDNode:
    """Gets the nodeof this type stored in the metadata store by it's id.

    Args:
      store: MLMD store to get node from.
      node_id: id of Node to retrieve.

    Returns:
      Retrieved MLMD Node.
    """  # pytype: disable=bad-return-type
    pass  # pytype: disable=bad-return-type

  @classmethod
  def put_double_property(cls,
                          node: type_utils.MLMDNode,
                          property_key: str,
                          property_value: float):
    """Puts a float value into node property field.

    Args:
      node: MLMD Artifact or Context or Execution node.
      property_key: Property field key
      property_value: Property field value
    """
    node.properties[property_key].double_value = property_value

  @classmethod
  def put_string_property(cls,
                          node: type_utils.MLMDNode,
                          property_key: str,
                          property_value: str):
    """Puts a string value into node property field.

    Args:
      node: MLMD Artifact or Context or Execution node.
      property_key: Property field key
      property_value: Property field value
    """
    node.properties[property_key].string_value = property_value

  @classmethod
  def put_int_property(cls,
                       node: type_utils.MLMDNode,
                       property_key: str,
                       property_value: int):
    """Puts a int value into node property field.

    Args:
      node: MLMD Artifact or Context or Execution node.
      property_key: Property field key
      property_value: Property field value
    """
    node.properties[property_key].int_value = property_value

  @classmethod
  def put_custom_properties(cls, node: type_utils.MLMDNode,
                            properties: Mapping[str, Union[int, str, float]]):
    """Adds properties to node's custom_properties field.

    Args:
      node: MLMD Artifact or Context or Execution node.
      properties: A dictionary that contains multiple property key and value
        pairs.
    Raise:
      ValueError: Throws error if property's value is incorrect type
    """

    for property_key, property_value in properties.items():
      if isinstance(property_value, str):
        node.custom_properties[property_key].string_value = property_value
      elif isinstance(property_value, (float, np.floating)):
        node.custom_properties[property_key].double_value = property_value
      elif isinstance(property_value, int):
        node.custom_properties[property_key].int_value = property_value
      else:
        raise ValueError('Accepts float, Text or int as property_value type.')

  def get_custom_properties_as_dict(
      self) -> Mapping[str, Union[str, int, float]]:
    """Returns a copy of custom properties as dict with values mapped to corresponding python value."""
    return {
        key: getattr(value, value.WhichOneof('value'))
        for key, value in self.node.custom_properties.items()
    }

  @classmethod
  def get_type_id(cls) -> Optional[int]:
    """Get the type_id of this class."""
    return cls._type_id

  @property
  def type(self) -> type_utils.MLMDType:
    """MLMD type definition for this class."""
    return self._type

  @property
  def type_id(self) -> Optional[int]:
    """MLMD Type id for this type in metadata store."""
    return self._type_id

  @property
  def node_id(self) -> Union[int, str]:
    """Node id of this node instance in metadata store."""
    return self._node.name if self.is_managed_store() else self._node.id

  @property
  def node(self) -> type_utils.MLMDNode:
    """Node of this instance in metadata store.

    Returns:
      Return the MLMD node.
    """
    return self._node
