# Lint as: python3
"""MLMD Artifact types which include Models, Datasets, and Metrics."""

import threading
from typing import Any, Mapping, Optional, Text, Union

from ml_metadata import metadata_store
from ml_metadata.proto import metadata_store_pb2
from google.cloud.aiplatform.types import base
from google.cloud.aiplatform.utils import type_utils


class Artifact(base.NodeAndType):
  """Abstract class representing the MLMD Artifact Type.

  Attributes:
    type: MLMD type definition.
    node: MLMD node instance.
    type_id: id of type in metadata store.
    node_id: MLMD id for this node in metadata store.
    name: Artifact node name.
  """
  _type = type_utils.create_type('aiplatform.Artifact',
                                 metadata_store_pb2.ArtifactType)

  @classmethod
  def _put_type(cls, store: metadata_store.MetadataStore) -> int:
    """Puts the artifact type into the MLMD store.

    Args:
      store: MLMD store to put this MLMD type

    Returns:
      Type id for this Artifact type in given MLMD store.
    """
    return store.put_artifact_type(cls._type)

  @classmethod
  def _get_node_by_id(
      cls, store: metadata_store.MetadataStore,
      artifact_id: Union[int, str]) -> Optional[metadata_store_pb2.Artifact]:
    """Gets the Artifact node by the id of this Artifact.

    Args:
      store: MLMD store to retrieve Artifact node from.
      artifact_id: Id of the Artifact node to retrieve.

    Returns:
      Artifact node instance in given MLMD store or None if it does not exist.

    Raises:
      ValueError if Artifact is not found in given MLMD store.
    """
    result = store.get_artifacts_by_id([artifact_id])
    result = result[0] if result else None

    if result and result.type_id != cls._type_id:
      raise ValueError('Artifact with id %d is not of %s type.' %
                       (artifact_id, cls.__name__))

    return result

  @classmethod
  def _put_node(cls, store: metadata_store.MetadataStore,
                node: metadata_store_pb2.Artifact) -> int:
    """Puts this Artifact Node instance in given MLMD Store.

    Args:
      store: MLMD store to retrieve Artifact node from.
      node: MLMD Artifact node definition

    Returns:
      Node ID for this MLMD Artifact Node in given MLMD Store
    """
    return store.put_artifacts([node])[0]

  @classmethod
  def _get_node(cls, store: metadata_store.MetadataStore,
                artifact_id: Union[int, str]) -> 'Artifact':
    """Gets an Artifact from given MLMD store.

    Args:
      store: MLMD store to get Artifact from.
      artifact_id: MLMD id of the Artifact to get.

    Returns:
      Artifact representing this instance in MLMD.
    Raises:
      ValueError if Artifact is not found in given MLMD store.
    """

    cls.register_type(store)

    node: Optional[metadata_store_pb2.Artifact] = cls._get_node_by_id(
        store, artifact_id)

    if node is None:
      raise ValueError('%s %s not found in store' %
                       (cls._type.name, artifact_id))

    return cls(store, node)  # pytype: disable=not-instantiable

  def bind_object(self, obj):
    """Binds in memory Python object to this Metadata for execution tracking.

    Args:
      obj: Object to bind to this Artifact metadata.
    """
    OBJECT_ID_TO_ARTIFACT_MAP[obj] = self

  @property
  def uri(self) -> str:
    """Uri of this artifact."""
    return self.node.uri


class GenericArtifact(Artifact):
  """Generic Artifact Type.

  Artifact represents a generic artifact that is not a Dataset, Model, or
  Metric.

  Attributes:
    type: MLMD type definition.
    node: MLMD node instance.
    type_id: id of type in metadata store.
    node_id: MLMD id for this node in metadata store.
    name: Artifact node name.
  """
  _type = type_utils.create_type(
      'aiplatform.GenericArtifact',
      metadata_store_pb2.ArtifactType,
      name=metadata_store_pb2.STRING)

  @classmethod
  def create(cls,
             store: metadata_store.MetadataStore,
             name: Optional[str] = None,
             uri: Optional[str] = None) -> 'GenericArtifact':
    """Creates a general Artifact.

    Puts it in the given MLMD store.

    Args:
      store: MLMD store to put this Artifact.
      name (Optional): Name of the Artifact.
      uri (Optional): The uri of this Model.

    Returns:
      Artifact object representing this instance in MLMD.
    """
    cls.register_type(store)
    node = cls._create_node(name, uri)
    node = cls._put_node_proxy(store, node)
    return GenericArtifact(store, node)

  @classmethod
  def get(cls, store: metadata_store.MetadataStore,
          artifact_id: Union[int, str]) -> 'GenericArtifact':
    """Gets a Generic Artifact from given MLMD store.

    Args:
      store: MLMD store to get Experiment from.
      artifact_id: MLMD id of Artifact to get.

    Returns:
      Artifact representing this instance in MLMD.
    """
    return cls._get_node(store, artifact_id)  # pytype: disable=bad-return-type

  @classmethod
  def _create_node(cls, name: Optional[str] = None, uri: Optional[str] = None):
    """Creates an Generic Artifact node object.

    Args:
      name (Optional): Name of the Artifact.
      uri (Optional): Uri of the Artifact.

    Returns:
      Created Generic Artifact Node.
    """
    node = metadata_store_pb2.Artifact()
    node.type_id = cls._type_id

    if name is not None:
      cls.put_string_property(
          node=node, property_key='name', property_value=name)

    node.uri = uri if uri is not None else ''
    return node


class ModelArtifact(Artifact):
  """Model Type.

  Model represents a framework-agnostic, machine-learning model.

  Attributes:
    type: MLMD type definition
    node: MLMD node instance
    type_id: id of type in metadata store
    node_id: MLMD id for this node in metadata store
    name: Model node name.
  """

  _type = type_utils.create_type(
      'aiplatform.Model',
      metadata_store_pb2.ArtifactType,
      name=metadata_store_pb2.STRING,
      framework=metadata_store_pb2.STRING,
      framework_version=metadata_store_pb2.STRING)

  @classmethod
  def create(cls,
             store: metadata_store.MetadataStore,
             name: Optional[Text] = None,
             uri: Optional[Text] = None,
             framework: Optional[Text] = None,
             framework_version: Optional[Text] = None) -> 'ModelArtifact':
    """Creates a Model Artifact.

    Puts it in the given MLMD store.

    Args:
      store: MLMD store to put this Model.
      name (Optional): Name of the Model. If not set, will be assigned by
        system.
      uri (Optional): The uri of this Model.
      framework (Optional): framework property
      framework_version (Optional): framework_version property

    Returns:
      Model object representing this instance in MLMD.
    """
    cls.register_type(store)
    node = cls._create_node(name, uri, framework, framework_version)
    node = cls._put_node_proxy(store, node)
    return ModelArtifact(store, node)

  @classmethod
  def get(cls, store: metadata_store.MetadataStore,
          model_id: Union[int, str]) -> 'ModelArtifact':
    """Gets a Model Artifact from given MLMD store.

    Args:
      store: MLMD store to get Experiment from.
      model_id: MLMD id of Model to get.

    Returns:
      Model representing this instance in MLMD.
    """
    return cls._get_node(store, model_id)  # pytype: disable=bad-return-type

  @classmethod
  def _create_node(
      cls,
      name: Optional[Text] = None,
      uri: Optional[Text] = None,
      framework: Optional[Text] = None,
      framework_version: Optional[Text] = None) -> metadata_store_pb2.Artifact:
    """Creates Model node object.

    Args:
      name (Optional): Name of the Model.
      uri (Optional): Uri of the Model.
      framework: Framework Property Value of the Model.
      framework_version: Framework Version Property Value of the Model.

    Returns:
      Created Artifact Node.
    """
    node = metadata_store_pb2.Artifact()
    node.type_id = cls._type_id

    if name is not None:
      cls.put_string_property(
          node=node, property_key='name', property_value=name)

    node.uri = uri if uri else ''  # MLMD treats this as an empty string if None

    if framework is not None:
      cls.put_string_property(node, 'framework', framework)

    if framework_version is not None:
      cls.put_string_property(node, 'framework_version', framework_version)

    return node


class MetricArtifact(Artifact):
  """Metric Type.

  Metrics represent evaluation metrics providing enough information to the
  application on how to load, parse and visualize the payload.

  Attributes:
    type: MLMD type definition.
    node: MLMD node instance.
    type_id: Id of type in metadata store.
    node_id: MLMD id for this node in metadata store.
    name: Metric name.
    metric_type: The type of this metric (TensorflowLog, TFMAEvalConfig, etc...)
  """

  _type = type_utils.create_type(
      'aiplatform.Metric',
      metadata_store_pb2.ArtifactType,
      name=metadata_store_pb2.STRING,
      metric_type=metadata_store_pb2.STRING)

  @classmethod
  def create(
      cls,
      store: metadata_store.MetadataStore,
      name: Optional[Text] = None,
      uri: Optional[Text] = None,
      metric_type: Optional[Text] = None,
      properties: Mapping[str, Union[int, str,
                                     float]] = None) -> 'MetricArtifact':
    """Creates a Metric Artifact.

    Puts it in the given MLMD store.

    Args:
      store: MLMD store to put this Metric.
      name (Optional): The name of this Metric.
      uri (Optional): The uri of this Metric.
      metric_type (Optional): If uri is given, the type of payload in the uri.
        TensorflowLog, TFMAEvalConfig, etc...
      properties: Custom Properties to specify when creating the Metric

    Returns:
      Metric object representing this instance in MLMD.
    """
    cls.register_type(store)
    node = cls._create_node(name, uri, metric_type, properties)
    node = cls._put_node_proxy(store, node)
    return MetricArtifact(store, node)

  @classmethod
  def get(cls, store: metadata_store.MetadataStore,
          metric_id: [int, str]) -> 'MetricArtifact':
    """Gets a Metric Artifact from given MLMD store.

    Args:
      store: MLMD store to get Experiment from.
      metric_id: MLMD id of Metric to get.

    Returns:
      Metric representing this instance in MLMD.
    """
    return cls._get_node(store, metric_id)  # pytype: disable=bad-return-type

  @classmethod
  def _create_node(
      cls,
      name: Optional[Text] = None,
      uri: Optional[Text] = None,
      metric_type: Optional[Text] = None,
      properties: Mapping[str, Union[int, str, float]] = None
  ) -> metadata_store_pb2.Artifact:
    """Creates Metric node object.

    Args:
      name (Optional): The name of this Metric.
      uri (Optional): The uri of this Metric.
      metric_type (Optional): If uri is given, the type of payload in the uri.
        TensorflowLog, TFMAEvalConfig, etc...
      properties: Custom Properties to specify when creating the Metric

    Returns:
      Created Metric Node.
    """
    node = metadata_store_pb2.Artifact()
    node.type_id = cls._type_id

    if name is not None:
      cls.put_string_property(
          node=node, property_key='name', property_value=name)
    if uri is not None:
      node.uri = uri

    if metric_type is not None:
      cls.put_string_property(
          node=node, property_key='metric_type', property_value=metric_type)

    if properties is not None:
      cls.put_custom_properties(node=node, properties=properties)

    return node

  @property
  def metric_type(self) -> str:
    return self.node.properties['metric_type'].string_value


class DatasetArtifact(Artifact):
  """Dataset Type.

  A dataset represents a file/folder containing data, which was either consumed
  or produced by an ML workflow step.


  Attributes:
    type: MLMD type definition.
    node: MLMD node instance.
    type_id: id of type in metadata store.
    node_id: MLMD id for this node in metadata store.
    name: Dataset name.
  """

  _type = type_utils.create_type(
      'aiplatform.Dataset',
      metadata_store_pb2.ArtifactType,
      name=metadata_store_pb2.STRING,
      environment=metadata_store_pb2.STRING,
      container_format=metadata_store_pb2.STRING,
      payload_format=metadata_store_pb2.STRING)

  @classmethod
  def create(cls,
             store: metadata_store.MetadataStore,
             name: Optional[Text] = None,
             uri: Optional[Text] = None,
             environment: Optional[Text] = None,
             container_format: Optional[Text] = None,
             payload_format: Optional[Text] = None) -> 'DatasetArtifact':
    """Creates a Dataset Artifact.

    Puts it in the given MLMD store.

    Args:
      store: MLMD store to put this Dataset.
      name (Optional): The name of this Dataset, if not set, will be assigned by
        system.
      uri (Optional): The uri of this Dataset.
      environment (Optional): The environment for this dataset. Examples: -
        Training - Serving
      container_format (Optional): Format of the container. Examples: - TFRecord
        - Text - Parquet - NPZ
      payload_format (Optional): Encoding format. Examples:
                                 - proto:tf.Example - JSON - CSV

    Returns:
      Dataset object representing this instance in MLMD.
    """
    cls.register_type(store)
    node = cls._create_node(name, uri, environment, container_format,
                            payload_format)
    node = cls._put_node_proxy(store, node)
    return DatasetArtifact(store, node)

  @classmethod
  def get(cls, store: metadata_store.MetadataStore,
          dataset_id: Union[int, str]) -> 'DatasetArtifact':
    """Gets a Dataset Artifact from given MLMD store.

    Args:
      store: MLMD store to get Dataset from.
      dataset_id: MLMD id of Dataset to get.

    Returns:
      Dataset representing this instance in MLMD.
    """
    return cls._get_node(store, dataset_id)  # pytype: disable=bad-return-type

  @classmethod
  def _create_node(
      cls,
      name: Optional[Text] = None,
      uri: Optional[Text] = None,
      environment: Optional[Text] = None,
      container_format: Optional[Text] = None,
      payload_format: Optional[Text] = None) -> metadata_store_pb2.Artifact:
    """Creates Dataset node object.

    Args:
      name (Optional): The name of this Dataset.
      uri (Optional): The uri of this Dataset.
      environment (Optional): The environment for this dataset. Examples: -
        Training - Serving
      container_format (Optional): Format of the container. Examples: - TFRecord
        - Text - Parquet - NPZ
      payload_format (Optional): Encoding format. Examples:
                                 - proto:tf.Example - JSON - CSV

    Returns:
      Created Dataset Node.
    """
    node = metadata_store_pb2.Artifact()
    node.type_id = cls._type_id

    if name is not None:
      cls.put_string_property(
          node=node, property_key='name', property_value=name)

    node.uri = uri if uri is not None else ''

    if payload_format is not None:
      cls.put_string_property(node, 'payload_format', payload_format)

    if environment is not None:
      cls.put_string_property(node, 'environment', environment)

    if container_format is not None:
      cls.put_string_property(node, 'container_format', container_format)

    return node


class _ArtifactIdToMetadataMap:
  """Map to store the Python id of an artifact with it's associated Metadata.

  This map is used to track the usage of a given Artifact during a Python
  session. It is meant to be used to track datasets, models, and other artifacts
  as they are logged and used with this SDK.

  There is a single globally available map in this module,
  artifact_id_to_metadata_map, that should be used by the client when using any
  logging api that accepts objects.

  In this map, the key is the Python id of the object and the value is one of
  the Artifact metadata objects representing that object.

  example_usage:

  def log_model(self, model_artifact, model_name):
    model_metadata = artifacts.Model(model_name)
    artifacts.artifact_id_to_metadata_map[model_artifact] = model_metadata

  This map will be used with the Execution decorators to create Events linking
  the Artifacts to those Executions when the decorated methods are invoked.
  """

  def __init__(self):
    # Dict of Python object id to Metadata Artifact/Dataset/Model/Metric
    # object.
    self._object_id_to_artifact_metadata_map = {}
    self._lock = threading.Lock()

  def __getitem__(self, artifact_object: Any) -> Artifact:
    """Gets Metadata for the given artifact object.

    Args:
      artifact_object: A Python object like a keras.Model or pd.DataFrame.

    Returns:
      Artifact Metadata associated with that object.
    Raises:
      KeyError: If the provided object's id is not in the map.
    """
    if artifact_object not in self:
      raise KeyError('%s does not have associated metadata.' % artifact_object)
    with self._lock:
      return self._object_id_to_artifact_metadata_map[id(artifact_object)]

  def __setitem__(self, artifact_object: Any, artifact_metadata: Artifact):
    """Sets the artifact object with the value of the given Metadata.

    Args:
      artifact_object: A Python object like a keras.Model or pd.DataFrame.
      artifact_metadata: The associated Metadata object for the artifact object.
        One of the metadata classes in this module.

    Raises:
      ValueError: If the given artifact metadata is not one of the metadata
        classes in this artifact module.
    """
    if not isinstance(artifact_metadata, Artifact):
      raise ValueError(
          'Given value of type %s. Only values supported: %s, %s, %s, %s' %
          (type(artifact_metadata).__name__, GenericArtifact.__name__,
           ModelArtifact.__name__, MetricArtifact.__name__,
           DatasetArtifact.__name__))
    with self._lock:
      # TODO(b/156401802) Track objects by ref to avoid object lifetime issues
      self._object_id_to_artifact_metadata_map[id(
          artifact_object)] = artifact_metadata

  def __contains__(self, artifact_object: Any) -> bool:
    """Checks if the given artifact object's id is in the map.

    Args:
      artifact_object: A Python object like a keras.Model or pd.DataFrame.

    Returns:
      True if the artifact object id is in the map, False if not.
    """
    with self._lock:
      return id(artifact_object) in self._object_id_to_artifact_metadata_map


# Global object python id to metadata object map. The client should use this
# to track artifacts in a session. A singleton is used here so lineage
# information of artifacts logged in one client instance can be tracked by
# another client instance.
OBJECT_ID_TO_ARTIFACT_MAP = _ArtifactIdToMetadataMap()


def initialize_artifact_from_node(
    store: metadata_store.MetadataStore,
    node: type_utils.MLMDNode) -> Optional[Artifact]:
  """Initialize an Artifact from MLMD Node.

  This method will use node's type to initiate a corresponding Artifact
  type instance.

  Args:
    store: MLMD store.
    node: MLMD node.

  Returns:
    Returns an Artifact that match the type node specified.
  """

  artifact_class = {
      GenericArtifact.get_type_id(): GenericArtifact,
      MetricArtifact.get_type_id(): MetricArtifact,
      DatasetArtifact.get_type_id(): DatasetArtifact,
      ModelArtifact.get_type_id(): ModelArtifact
  }.get(node.type_id)

  if artifact_class:
    return artifact_class(store, node)
  return artifact_class
