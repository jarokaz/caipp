# Lint as: python3
"""MLMD Context Types including Experiment, Run, and Tag.
"""

from typing import Dict, Optional, Sequence, Text, Union

from ml_metadata import metadata_store
from ml_metadata.proto import metadata_store_pb2
from google.cloud.aiplatform.types import artifacts
from google.cloud.aiplatform.types import base
from google.cloud.aiplatform.utils import type_utils


class Context(base.NodeAndType):
  """Abstract class representing the MLMD Context Type.

  Attributes:
    name: name of the MLMD node instance
    node: MLMD node instance
    node_id: MLMD id for this node in metadata store
    type: MLMD type definition
    type_id: id of type in metadata store
  """
  _type: metadata_store_pb2.ContextType = type_utils.create_type(
      'aiplatform.Context', metadata_store_pb2.ContextType)

  def __eq__(self, other: 'Context') -> bool:
    """Tests equivalence based on identity attributes of node and type.

    Args:
      other: Another instance of this same Context type.
    Returns:
      True if the attribute identities match and False if not.
    """
    return type(self) is type(other) and \
        self.name == other.name and \
        self.node_id == other.node_id and \
        self.type_id == other.type_id

  @classmethod
  def _put_type(cls, store: metadata_store.MetadataStore) -> int:
    """Puts the context type into the MLMD store.

    Args:
      store: MLMD store to put this MLMD type
    Returns:
      Type id for this Context type in given MLMD store.
    """
    # TODO(asobran) consider setting optional flags
    return store.put_context_type(cls._type)

  @classmethod
  def _get_node_by_name(cls,
                        store: metadata_store.MetadataStore,
                        name: Text) -> Optional[metadata_store_pb2.Context]:
    """Gets the Context node by the name of this Context.

    Args:
      store: MLMD store to retrieve Context node from.
      name: Name of the Context node to retrieve.
    Returns:
      Context node instance in given MLMD store or None if it does not exist.
    """
    return store.get_context_by_type_and_name(cls._type.name, name)

  @classmethod
  def _get_node_by_id(cls,
                      store: metadata_store.MetadataStore,
                      context_id: Union[int, str]
                      ) -> Optional[metadata_store_pb2.Context]:
    """Get this Context node by id.

    Args:
      store: MLMD store to retrieve Context node from.
      context_id: ID of the Context node to retrieve.
    Returns:
      Context node instance in given MLMD store or None if it does not exist.
    """
    result: Sequence[metadata_store_pb2.Context] = store.get_contexts_by_id(
        [context_id])
    result = result[0] if result else None  # pytype: disable=annotation-type-mismatch

    if result and result.type_id != cls._type_id:
      raise ValueError('Context with id %d is not of %s type.' %
                       (context_id, cls.__name__))
    return result

  @classmethod
  def _put_node(cls, store: metadata_store.MetadataStore,
                node: metadata_store_pb2.Context) -> int:
    """Puts this Context node instance in given MLMD store.

    Args:
      store: MLMD store to retrieve Context node from.
      node: MLMD Context node definition
    Returns:
      Node ID for this MLMD Context node in given MLMD store.
    """
    return store.put_contexts([node])[0]

  @classmethod
  def _get_node(cls, store: metadata_store.MetadataStore,
                name: Optional[Text] = None,
                context_id: Optional[Union[int, str]] = None):
    """Gets a Context from given MLMD store.

    Exacltly one of name or context_id must be given.
    Args:
      store: MLMD store to get Context from.
      name (Optional): Name of the Context to get.
      context_id (Optional): MLMD id of Context to get.
    Returns:
      Context representing this instance in MLMD.
    Raises:
      ValueError if Context is not found in given MLMD store.
    """

    cls.register_type(store)

    if name is not None:
      if isinstance(store, metadata_store.MetadataStore):
        node = cls._get_node_by_name(store, name)
      else:
        node = cls._get_node_by_id(store, name)
    else:
      node: Optional[metadata_store_pb2.Context] = cls._get_node_by_id(
          store, context_id)

    if node is None:
      if name is not None:
        raise ValueError('%s %s not found in store' % (cls._type.name, name))
      else:
        raise ValueError('%s %d not found in store' % (cls._type.name,
                                                       context_id))
    return cls(store, node)  # pytype: disable=not-instantiable

  def attribute_artifact(self, artifact: artifacts.Artifact):
    """Attributes given artifact to this Context.

    Args:
      artifact: Artifact to attribute to this Context.
    """

    if isinstance(self._store, metadata_store.MetadataStore):
      attribution = metadata_store_pb2.Attribution()
      attribution.artifact_id = artifact.node_id
      attribution.context_id = self.node_id
      self._store.put_attributions_and_associations([attribution], [])
    else:
      self._store.add_context_artifacts_and_executions(
          self.name, [artifact.node.name], [])

  @property
  def name(self) -> Text:
    """Name of the node."""
    return self._node.name

  @classmethod
  def get_all(
      cls, store: metadata_store.MetadataStore
  ) -> Sequence['Context']:
    """Gets all the Contexts of this type from the Store.

    Args:
      store: Store to retrieve the Contexts from.

    Returns:
      A list of all the returned Contexts.
    """
    return [cls(store, context_node) for context_node in  # pytype: disable=not-instantiable
            store.get_contexts_by_type(cls._type.name)]

  def as_dict(self) -> Dict[str, Union[int, str]]:
    """Returns the Context information as a dict."""
    return {'context_id': self.node_id, 'context_name': self.name}


class ExperimentContext(Context):
  """Experiment type.

  Experiments are a high-level grouping concept of Executions and Artifacts. All
  SDK Logging commands are scoped to an experiment.

  Attributes:
    type: MLMD type definition
    node: MLMD node instance
    type_id: id of type in metadata store
    node_id: MLMD id for this node in metadata store
  """
  _type = type_utils.create_type('aiplatform.Experiment',
                                 metadata_store_pb2.ContextType)

  @classmethod
  def get_or_create(cls,
                    store: metadata_store.MetadataStore,
                    name: Optional[Text] = None,
                    experiment_id: Optional[Union[int, str]] = None
                    ) -> 'ExperimentContext':
    """Gets an Experiment Context from given MLMD store.

    Exactly one of name or experiment_id must be given.
    Args:
      store: MLMD store to get Experiment from.
      name (Optional): Name of the Experiment Context to get.
      experiment_id (Optional): MLMD id of Experiment to get.
    Returns:
      Experiment representing this instance in MLMD.
    Raise:
      ValueError if given both name and experiment_id or neither experiment_id
      of name.
    """
    if (name is None) == (experiment_id is None):
      raise ValueError(
          'get_or_create accepts exactly one of name or experiment_id.')
    try:
      # try to get the experiment if it exists
      return cls._get_node(store, name, experiment_id)
    except ValueError:
      # if it is not found and they specified experiment_id we cannot create a
      # new experiment without a name so raise
      if experiment_id is not None:
        raise

      # create a new experiment with name
      node = cls._create_node(name)
      node = cls._put_node_proxy(store, node)

      return cls(store, node)

  @classmethod
  def _create_node(cls, name: Text) -> metadata_store_pb2.Context:
    """Creates an Experiment node object.

    Args:
      name: Name of the Experiment.
    Returns:
      MLMD Experiment Context instance.
    """
    node = metadata_store_pb2.Context()
    node.name = name
    node.type_id = cls._type_id
    return node

  def as_dict(self) -> Dict[str, Union[int, float, str]]:
    """Returns the Experiment information as a dict."""
    return {'experiment_id': self.node_id, 'experiment_name': self.name}
