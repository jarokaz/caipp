# Lint as: python3
"""Tests for google3.cloud.ai.platform.ml_metadata.client.rosalind.utils.type_utils."""
import unittest

from ml_metadata.proto import metadata_store_pb2
from google.cloud.aiplatform.utils import type_utils



class TypeUtilsTest(unittest.TestCase):

  def test_valid_create_type(self):
    test_type = type_utils.create_type('Test',
                                       metadata_store_pb2.ArtifactType,
                                       field_1=metadata_store_pb2.STRING,
                                       field_2=metadata_store_pb2.INT)
    self.assertEqual(test_type.name, 'Test')
    self.assertIsInstance(test_type, metadata_store_pb2.ArtifactType)
    self.assertCountEqual(list(test_type.properties), ['field_1', 'field_2'])
    self.assertEqual(test_type.properties['field_1'], metadata_store_pb2.STRING)
    self.assertEqual(test_type.properties['field_2'], metadata_store_pb2.INT)

  def test_invalid_kwarg_create_type(self):
    with self.assertRaises(ValueError):
      type_utils.create_type(
          'Test', metadata_store_pb2.ArtifactType, field_1=20)

  def test_convert_type_to_yaml(self):
    test_type = type_utils.create_type('Test',
                                       metadata_store_pb2.ArtifactType,
                                       field_1=metadata_store_pb2.STRING,
                                       field_2=metadata_store_pb2.INT)

    converted_yaml = type_utils.convert_type_to_yaml(test_type)

    true_yaml = \
"""properties:
  field_1:
    type: string
  field_2:
    type: integer
title: Test
type: object
"""

    self.assertEqual(converted_yaml, true_yaml)


if __name__ == '__main__':
  unittest.main()
