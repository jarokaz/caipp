# Lint as: python3
"""Utilities for MLMD Types.

Relies on and is influenced by third_party.ml_metadata.metadata_store.types.
"""

from typing import FrozenSet, Text, Type, TypeVar, Union

from ml_metadata.proto import metadata_store_pb2
import yaml

_appropriate_values: FrozenSet[int] = frozenset(
    metadata_store_pb2.PropertyType.values())

MLMDType = TypeVar('MLMDType', metadata_store_pb2.ArtifactType,
                   metadata_store_pb2.ContextType,
                   metadata_store_pb2.ExecutionType)

MLMDNode = Union[metadata_store_pb2.Artifact, metadata_store_pb2.Context,
                 metadata_store_pb2.Execution]


def create_type(type_name: Text, mlmd_type: Type[MLMDType],
                **kwargs: int) -> MLMDType:
  """Generic method to create an MLMD Type.

  Usage:
    create_type('Run', metadata_store_pb2.ContextType,
                field_name_1=metadata_store.pb2.INT,
                field_name_2=metadata_store.pb2.STRING
                )
    Returns this MLMD Type:
    Context Type {
      type_name = 'Run',
      properties['field_name_1'] = metadata_store.pb2.INT,
      properties['field_name_2'] = metadata_store.pb2.STRING
    }

  Args:
    type_name: name of the MLMD Type
    mlmd_type: One of MLMD types
    **kwargs: Accepts enum value of PropertyType. Used to define properties.

  Returns:
    MLMD Type instance with defined properties.
  Raises:
    ValueError if a kwargs argument not in MLMD enum range.
  """
  result = mlmd_type()
  result.name = type_name
  for k, v in kwargs.items():
    if v not in _appropriate_values:
      raise ValueError(
          'The value for %s is %d but must be one of %s' %
          (k, v, ', '.join(str(value) for value in _appropriate_values)))
    result.properties[k] = v
  return result


def convert_type_to_yaml(mlmd_type: MLMDType) -> str:
  """Converts a MLMD Type to YAML representation suitable for Managed Metadata.

  Args:
    mlmd_type: The MLMD Type to convert.
  Returns:
    YAML representation of given MLMD Type as string.
  """
  property_type_to_yaml_type_map = {
      metadata_store_pb2.STRING: 'string',
      metadata_store_pb2.INT: 'integer',
      metadata_store_pb2.DOUBLE: 'double'
  }

  yaml_data = {}
  yaml_data['title'] = mlmd_type.name
  yaml_data['type'] = 'object'
  properties = {}
  for key in mlmd_type.properties.keys():
    properties[key] = {
        'type': property_type_to_yaml_type_map[mlmd_type.properties[key]],
    }
  if properties:
    yaml_data['properties'] = properties
  return yaml.dump(yaml_data, default_flow_style=False)
