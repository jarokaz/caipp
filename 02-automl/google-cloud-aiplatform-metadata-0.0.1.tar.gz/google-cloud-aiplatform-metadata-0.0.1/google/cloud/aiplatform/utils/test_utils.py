"""Utilities for testing."""


def assert_metadata_node_proto_equal(test_case,
                                     first_node,
                                     second_node,
                                     ignored_fields=None):
  """Asserts to Metadata Nodes have equality on provided fields."""
  def get_value(value):
    return getattr(value, value.WhichOneof('value'))

  ignored_fields = ignored_fields if ignored_fields else []

  fields = set(first_node.DESCRIPTOR.fields_by_name.keys() +
               second_node.DESCRIPTOR.fields_by_name.keys())
  fields = fields - set(['properties', 'custom_properties'] + ignored_fields)

  for key in fields:
    test_case.assertEqual(getattr(first_node, key), getattr(second_node, key))

  for key in set(
      list(first_node.properties.keys()) + list(second_node.properties.keys())):
    test_case.assertEqual(
        get_value(first_node.properties[key]),
        get_value(second_node.properties[key]))

  for key in set(list(first_node.custom_properties.keys()) +
                 list(second_node.custom_properties.keys())):
    test_case.assertEqual(
        get_value(first_node.custom_properties[key]),
        get_value(second_node.custom_properties[key]))
