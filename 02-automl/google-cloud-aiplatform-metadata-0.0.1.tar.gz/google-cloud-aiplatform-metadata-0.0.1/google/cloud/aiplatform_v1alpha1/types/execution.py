# -*- coding: utf-8 -*-

# Copyright 2020 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import proto  # type: ignore


from google.cloud.aiplatform_v1alpha1.types import value as gca_value
from google.protobuf import timestamp_pb2 as timestamp  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.aiplatform.v1alpha1',
    manifest={
        'Execution',
    },
)


class Execution(proto.Message):
    r"""Instance of a general execution.

    Attributes:
        name (str):
            Output only. The resource name of the
            Execution.
        display_name (str):
            User provided display name of the Execution.
            May be up to 128 Unicode characters.
        instance_schema_title (str):
            The title of the schema this Execution adheres to.

            Schema is expected to be registered in earlier input calls
            for Executions of this type by specifying the schema through
            [Execution.instance_schema][google.cloud.aiplatform.v1alpha1.Execution.instance_schema]
            or
            [Execution.instance_schema_uri][google.cloud.aiplatform.v1alpha1.Execution.instance_schema_uri]
            fields.

            On input this,
            [Execution.instance_schema][google.cloud.aiplatform.v1alpha1.Execution.instance_schema],
            or
            [Execution.instance_schema_uri][google.cloud.aiplatform.v1alpha1.Execution.instance_schema_uri]
            may be populated, but not more than one.

            Output for
            [MetadataService.ListExecutions][google.cloud.aiplatform.v1alpha1.MetadataService.ListExecutions]
            by default will not populate this field and will only
            populate
            [Execution.instance_schema_uri][google.cloud.aiplatform.v1alpha1.Execution.instance_schema_uri].
            Output for other methods that return an Execution will
            populate this,
            [Execution.instance_schema][google.cloud.aiplatform.v1alpha1.Execution.instance_schema],
            and
            [Execution.instance_schema_uri][google.cloud.aiplatform.v1alpha1.Execution.instance_schema_uri],
            and all three will match.
        instance_schema_uri (str):
            The uri of a YAML file stored on Google Cloud Storage
            describing the format of this Execution's
            [properties][google.cloud.aiplatform.v1alpha1.Execution.properties].
            Note: The URI given on output will be immutable and probably
            different than the one given on input. The output URI will
            point to a location where the user only has a read access.

            On input this,
            [Execution.instance_schema_title][google.cloud.aiplatform.v1alpha1.Execution.instance_schema_title],
            or
            [Execution.instance_schema][google.cloud.aiplatform.v1alpha1.Execution.instance_schema]
            may be populated, but not more than one.

            Output for
            [MetadataService.ListExecutions][google.cloud.aiplatform.v1alpha1.MetadataService.ListExecutions]
            will by default only populate this field. Output for other
            methods that return an Execution will populate this,
            [Execution.instance_schema][google.cloud.aiplatform.v1alpha1.Execution.instance_schema],
            and
            [Execution.instance_schema_title][google.cloud.aiplatform.v1alpha1.Execution.instance_schema_title],
            and all three will match.

            The schema is defined as an OpenAPI 3.0.2 [Schema Object](

            https: //github.com/OAI/OpenAPI-Specification/b //
            lob/master/versions/3.0.2.md#schemaObject) However, only
            int, double, and string types are supported as Values. The
            title of the schema must be 4-127 characters in length.
            Valid characters are /[a-zA-Z][0-9]_./.
        instance_schema (str):
            A raw YAML string, describing the format of this Execution's
            [properties][google.cloud.aiplatform.v1alpha1.Execution.properties].

            On input this,
            [Execution.instance_schema_title][google.cloud.aiplatform.v1alpha1.Execution.instance_schema_title],
            or
            [Execution.instance_schema_uri][google.cloud.aiplatform.v1alpha1.Execution.instance_schema_uri]
            may be populated, but not more than one.

            Output for
            [MetadataService.ListExecutions][google.cloud.aiplatform.v1alpha1.MetadataService.ListExecutions]
            will by default not populate this field and will only
            populate
            [Execution.instance_schema_uri][google.cloud.aiplatform.v1alpha1.Execution.instance_schema_uri].
            Output for other methods that return an Execution will
            populate this,
            [Execution.instance_schema_title][google.cloud.aiplatform.v1alpha1.Execution.instance_schema_title],
            and
            [Execution.instance_schema_uri][google.cloud.aiplatform.v1alpha1.Execution.instance_schema_uri],
            and all three will match.

            The schema is defined as an OpenAPI 3.0.2 [Schema Object](

            https: //github.com/OAI/OpenAPI-Specification/b //
            lob/master/versions/3.0.2.md#schemaObject) However, only
            int, double, and string types are supported as Values. The
            title of the schema must be 4-127 characters in length.
            Valid characters are /[a-zA-Z][0-9]_./.
        state (~.execution.Execution.State):
            The state of this Execution. This is a
            property of the Execution, and does not imply or
            capture any ongoing process. This property is
            managed by clients (such as AI Platform
            Pipelines) and the system does not prescribe or
            check the validity of state transitions.
        properties (Sequence[~.execution.Execution.PropertiesEntry]):
            Properties of the Execution. The schema they are represented
            in can be found in either of
            [Execution.instance_schema_uri][google.cloud.aiplatform.v1alpha1.Execution.instance_schema_uri]
            or
            [Execution.instance_schema][google.cloud.aiplatform.v1alpha1.Execution.instance_schema]
            (they will match).
        custom_properties (Sequence[~.execution.Execution.CustomPropertiesEntry]):
            Arbitrary user-provided properties that do
            not correspond to fields in the schema for the
            Execution type and are therefore not type-
            checked. Only int, double, and string types are
            supported as Values.
        etag (str):
            An eTag used to perform consistent read-
            odify-write updates. If not set, a blind
            "overwrite" update happens.
        labels (Sequence[~.execution.Execution.LabelsEntry]):
            The labels with user-defined metadata to organize your
            Executions.

            Label keys and values can be no longer than 64 characters
            (Unicode codepoints), can only contain lowercase letters,
            numeric characters, underscores and dashes. International
            characters are allowed. No more than 64 user labels can be
            associated with one Execution (System labels are excluded).

            See https://goo.gl/xmQnxf for more information and examples
            of labels. System reserved label keys are prefixed with
            "aiplatform.googleapis.com/" and are immutable. Following
            system labels exist for each Execution:

            -  "aiplatform.googleapis.com/schema_title":

               -  output only, its value is the title of the Execution
                  schema provided either by
                  [instance_schema_uri][google.cloud.aiplatform.v1alpha1.Execution.instance_schema_uri]
                  or
                  [instance_schema][google.cloud.aiplatform.v1alpha1.Execution.instance_schema].

            -  "aiplatform.googleapis.com/schema_version":

               -  output only, its value is the schema version of the
                  Execution schema provided either by
                  [instance_schema_uri][google.cloud.aiplatform.v1alpha1.Execution.instance_schema_uri]
                  or
                  [instance_schema][google.cloud.aiplatform.v1alpha1.Execution.instance_schema].
        create_time (~.timestamp.Timestamp):
            Output only. Timestamp when this Execution
            was created.
        update_time (~.timestamp.Timestamp):
            Output only. Timestamp when this Execution
            was last updated.
    """
    class State(proto.Enum):
        r"""Describes the state of the Execution."""
        STATE_UNSPECIFIED = 0
        NEW = 1
        RUNNING = 2
        COMPLETE = 3
        FAILED = 4

    name = proto.Field(proto.STRING, number=1)

    display_name = proto.Field(proto.STRING, number=2)

    instance_schema_title = proto.Field(proto.STRING, number=3)

    instance_schema_uri = proto.Field(proto.STRING, number=4)

    instance_schema = proto.Field(proto.STRING, number=5)

    state = proto.Field(proto.ENUM, number=6,
        enum=State,
    )

    properties = proto.MapField(proto.STRING, proto.MESSAGE, number=7,
        message=gca_value.Value,
    )

    custom_properties = proto.MapField(proto.STRING, proto.MESSAGE, number=8,
        message=gca_value.Value,
    )

    etag = proto.Field(proto.STRING, number=9)

    labels = proto.MapField(proto.STRING, proto.STRING, number=10)

    create_time = proto.Field(proto.MESSAGE, number=11,
        message=timestamp.Timestamp,
    )

    update_time = proto.Field(proto.MESSAGE, number=12,
        message=timestamp.Timestamp,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
